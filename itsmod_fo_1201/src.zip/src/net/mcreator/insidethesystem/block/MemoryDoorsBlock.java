package net.mcreator.insidethesystem.block;

import java.util.List;
import net.mcreator.insidethesystem.procedures.DoorActivateProcedure;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.phys.BlockHitResult;

public class MemoryDoorsBlock extends DoorBlock {
   public MemoryDoorsBlock() {
      super(
         Properties.m_284310_()
            .m_60918_(SoundType.f_56736_)
            .m_60913_(-1.0F, 10.0F)
            .m_60953_(s -> 10)
            .m_60955_()
            .m_60924_((bs, br, bp) -> false)
            .m_60988_()
            .m_222994_(),
         BlockSetType.f_271479_
      );
   }

   public void m_5871_(ItemStack itemstack, BlockGetter world, List<Component> list, TooltipFlag flag) {
      super.m_5871_(itemstack, world, list, flag);
      list.add(Component.m_237113_("???"));
   }

   public int m_7753_(BlockState state, BlockGetter worldIn, BlockPos pos) {
      return 0;
   }

   public InteractionResult m_6227_(BlockState blockstate, Level world, BlockPos pos, Player entity, InteractionHand hand, BlockHitResult hit) {
      super.m_6227_(blockstate, world, pos, entity, hand, hit);
      int x = pos.m_123341_();
      int y = pos.m_123342_();
      int z = pos.m_123343_();
      double hitX = hit.m_82450_().f_82479_;
      double hitY = hit.m_82450_().f_82480_;
      double hitZ = hit.m_82450_().f_82481_;
      Direction direction = hit.m_82434_();
      DoorActivateProcedure.execute(world, x, y, z, entity);
      return InteractionResult.SUCCESS;
   }
}
