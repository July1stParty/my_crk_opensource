package net.mcreator.insidethesystem.network;

import java.util.function.Supplier;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerChangedDimensionEvent;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.NetworkEvent.Context;

@EventBusSubscriber(bus = Bus.MOD)
public class InsideTheSystemModVariables {
   @SubscribeEvent
   public static void init(FMLCommonSetupEvent event) {
      InsideTheSystemMod.addNetworkMessage(
         InsideTheSystemModVariables.SavedDataSyncMessage.class,
         InsideTheSystemModVariables.SavedDataSyncMessage::buffer,
         InsideTheSystemModVariables.SavedDataSyncMessage::new,
         InsideTheSystemModVariables.SavedDataSyncMessage::handler
      );
   }

   @EventBusSubscriber
   public static class EventBusVariableHandlers {
      @SubscribeEvent
      public static void onPlayerLoggedIn(PlayerLoggedInEvent event) {
         if (!event.getEntity().m_9236_().m_5776_()) {
            SavedData mapdata = InsideTheSystemModVariables.MapVariables.get(event.getEntity().m_9236_());
            SavedData worlddata = InsideTheSystemModVariables.WorldVariables.get(event.getEntity().m_9236_());
            if (mapdata != null) {
               InsideTheSystemMod.PACKET_HANDLER
                  .send(PacketDistributor.PLAYER.with(() -> (ServerPlayer)event.getEntity()), new InsideTheSystemModVariables.SavedDataSyncMessage(0, mapdata));
            }

            if (worlddata != null) {
               InsideTheSystemMod.PACKET_HANDLER
                  .send(
                     PacketDistributor.PLAYER.with(() -> (ServerPlayer)event.getEntity()), new InsideTheSystemModVariables.SavedDataSyncMessage(1, worlddata)
                  );
            }
         }
      }

      @SubscribeEvent
      public static void onPlayerChangedDimension(PlayerChangedDimensionEvent event) {
         if (!event.getEntity().m_9236_().m_5776_()) {
            SavedData worlddata = InsideTheSystemModVariables.WorldVariables.get(event.getEntity().m_9236_());
            if (worlddata != null) {
               InsideTheSystemMod.PACKET_HANDLER
                  .send(
                     PacketDistributor.PLAYER.with(() -> (ServerPlayer)event.getEntity()), new InsideTheSystemModVariables.SavedDataSyncMessage(1, worlddata)
                  );
            }
         }
      }
   }

   public static class MapVariables extends SavedData {
      public static final String DATA_NAME = "inside_the_system_mapvars";
      public boolean Angry = false;
      public double Angrybuild = 0.0;
      public boolean AngryPlayerSpawned = false;
      public boolean build = true;
      public boolean builderLook = false;
      public double builderSpawnTimer = 1200.0;
      public double builderX = 0.0;
      public double builderY = 0.0;
      public double builderZ = 0.0;
      public boolean Colljoin = false;
      public boolean delete = false;
      public double Dialogue = 1000.0;
      public boolean DialogueBool = false;
      public boolean Died = false;
      public boolean DiedPayloadExecuted = false;
      public boolean Disc = true;
      public boolean dox = false;
      public boolean eventfollover = false;
      public boolean First = false;
      public boolean FirstJoin = false;
      public boolean Fiveth = false;
      public boolean follow = true;
      public double followerdied = 0.0;
      public boolean Fourth = false;
      public boolean GameStarted = false;
      public boolean Inworld = false;
      public boolean isBlockEmpty = false;
      public double kickDelayTicks = 0.0;
      public double PlayerAngry = 50.0;
      public double PlayerX = 0.0;
      public double PlayerY = 0.0;
      public double PlayerZ = 0.0;
      public boolean safeip = false;
      public boolean Screamer1 = false;
      public double ScreamerTimer = 0.0;
      public boolean Second = false;
      public boolean Seventh = false;
      public boolean Sixth = false;
      public boolean spawn = false;
      public boolean summon = false;
      public boolean Third = false;
      public double TimerBuild = 600.0;
      public boolean TimerEnd = false;
      public double TimerJoin = 4000.0;
      public boolean window = false;
      public double WorldDied = 72000.0;
      public double worldDiedTemp = 0.0;
      public boolean timer = false;
      public double Gates = 0.0;
      public boolean shard1 = false;
      public boolean shard2 = false;
      public boolean shard3 = false;
      public boolean shard4 = false;
      public boolean filesCreated = false;
      public boolean GameFinished = false;
      public double currentSkinIndex = 0.0;
      public String CoolPlayer303Skin = "default";
      public String coolPlayerName = "\t\"CoolPlayer303\"";
      public boolean firstSpawnDone = false;
      public boolean timerStarted = false;
      public String coolPlayerUUID = "\"\"";
      public boolean showInTab = false;
      public double messageDelay = 0.0;
      public boolean screamer2 = false;
      public boolean AllItems = false;
      public double x = 0.0;
      public double y = 0.0;
      public double z = 0.0;
      public boolean generated = false;
      public boolean AllItemsMessagesStarted = false;
      public boolean HasPlayedDialog = false;
      public boolean chatTriggered = false;
      public double errors = 4.0;
      public boolean breakb = false;
      public boolean aikoDialogueStarted = false;
      public boolean dimens = false;
      public boolean dimens2 = false;
      public boolean screamer3 = false;
      public boolean buildblock = true;
      public boolean Spawnlost = false;
      public double DialogueNum = 0.0;
      public boolean DialogueUsed = false;
      public boolean EndingD = false;
      public boolean EndingF = false;
      public boolean site = false;
      public boolean Scr1 = false;
      public boolean Scr2 = false;
      public boolean Scr3 = false;
      public double Tunnel = 0.0;
      public boolean Endingf = false;
      public boolean kick = false;
      public boolean story1 = false;
      public boolean story0 = false;
      public boolean story2 = false;
      public boolean story3 = false;
      public boolean KiilEnd = false;
      public boolean endinga = false;
      public boolean quest1 = false;
      public boolean quest2 = false;
      public boolean quest3 = false;
      public boolean level1 = false;
      public boolean level2 = false;
      public boolean level3 = false;
      public boolean Task1 = false;
      public double WorldLife = 600000.0;
      public double WorldLifeTemp = 0.0;
      public boolean Task = false;
      public boolean Task1SEC = false;
      public boolean Task2 = false;
      public boolean OBS = false;
      public boolean Task3 = false;
      public boolean TaskEnd1 = false;
      public boolean TaskEnd2 = false;
      public boolean TaskEnd3 = false;
      public boolean Family = false;
      public boolean Taskk = false;
      public boolean Taskkk = false;
      public boolean BlockCommands = false;
      public boolean Note = false;
      public String CrashedPlayers = "\"\"";
      public boolean TaskDialogue = false;
      public boolean Tips = false;
      public boolean Tips1 = false;
      public boolean Tips2 = false;
      public boolean Tips3 = false;
      public boolean Steam = false;
      public boolean BlockDialogue = false;
      public boolean Change = false;
      public boolean Task1T = false;
      public boolean Task2T = false;
      public boolean Task3T = false;
      public boolean Survey = false;
      public double NumberOpen = 0.0;
      public double TimerN = 0.0;
      public boolean Times = false;
      public boolean EndingDtext = false;
      public boolean ActIIICompleted = false;
      public boolean FatherKill = true;
      static InsideTheSystemModVariables.MapVariables clientSide = new InsideTheSystemModVariables.MapVariables();

      public static InsideTheSystemModVariables.MapVariables load(CompoundTag tag) {
         InsideTheSystemModVariables.MapVariables data = new InsideTheSystemModVariables.MapVariables();
         data.read(tag);
         return data;
      }

      public void read(CompoundTag nbt) {
         this.Angry = nbt.m_128471_("Angry");
         this.Angrybuild = nbt.m_128459_("Angrybuild");
         this.AngryPlayerSpawned = nbt.m_128471_("AngryPlayerSpawned");
         this.build = nbt.m_128471_("build");
         this.builderLook = nbt.m_128471_("builderLook");
         this.builderSpawnTimer = nbt.m_128459_("builderSpawnTimer");
         this.builderX = nbt.m_128459_("builderX");
         this.builderY = nbt.m_128459_("builderY");
         this.builderZ = nbt.m_128459_("builderZ");
         this.Colljoin = nbt.m_128471_("Colljoin");
         this.delete = nbt.m_128471_("delete");
         this.Dialogue = nbt.m_128459_("Dialogue");
         this.DialogueBool = nbt.m_128471_("DialogueBool");
         this.Died = nbt.m_128471_("Died");
         this.DiedPayloadExecuted = nbt.m_128471_("DiedPayloadExecuted");
         this.Disc = nbt.m_128471_("Disc");
         this.dox = nbt.m_128471_("dox");
         this.eventfollover = nbt.m_128471_("eventfollover");
         this.First = nbt.m_128471_("First");
         this.FirstJoin = nbt.m_128471_("FirstJoin");
         this.Fiveth = nbt.m_128471_("Fiveth");
         this.follow = nbt.m_128471_("follow");
         this.followerdied = nbt.m_128459_("followerdied");
         this.Fourth = nbt.m_128471_("Fourth");
         this.GameStarted = nbt.m_128471_("GameStarted");
         this.Inworld = nbt.m_128471_("Inworld");
         this.isBlockEmpty = nbt.m_128471_("isBlockEmpty");
         this.kickDelayTicks = nbt.m_128459_("kickDelayTicks");
         this.PlayerAngry = nbt.m_128459_("PlayerAngry");
         this.PlayerX = nbt.m_128459_("PlayerX");
         this.PlayerY = nbt.m_128459_("PlayerY");
         this.PlayerZ = nbt.m_128459_("PlayerZ");
         this.safeip = nbt.m_128471_("safeip");
         this.Screamer1 = nbt.m_128471_("Screamer1");
         this.ScreamerTimer = nbt.m_128459_("ScreamerTimer");
         this.Second = nbt.m_128471_("Second");
         this.Seventh = nbt.m_128471_("Seventh");
         this.Sixth = nbt.m_128471_("Sixth");
         this.spawn = nbt.m_128471_("spawn");
         this.summon = nbt.m_128471_("summon");
         this.Third = nbt.m_128471_("Third");
         this.TimerBuild = nbt.m_128459_("TimerBuild");
         this.TimerEnd = nbt.m_128471_("TimerEnd");
         this.TimerJoin = nbt.m_128459_("TimerJoin");
         this.window = nbt.m_128471_("window");
         this.WorldDied = nbt.m_128459_("WorldDied");
         this.worldDiedTemp = nbt.m_128459_("worldDiedTemp");
         this.timer = nbt.m_128471_("timer");
         this.Gates = nbt.m_128459_("Gates");
         this.shard1 = nbt.m_128471_("shard1");
         this.shard2 = nbt.m_128471_("shard2");
         this.shard3 = nbt.m_128471_("shard3");
         this.shard4 = nbt.m_128471_("shard4");
         this.filesCreated = nbt.m_128471_("filesCreated");
         this.GameFinished = nbt.m_128471_("GameFinished");
         this.currentSkinIndex = nbt.m_128459_("currentSkinIndex");
         this.CoolPlayer303Skin = nbt.m_128461_("CoolPlayer303Skin");
         this.coolPlayerName = nbt.m_128461_("coolPlayerName");
         this.firstSpawnDone = nbt.m_128471_("firstSpawnDone");
         this.timerStarted = nbt.m_128471_("timerStarted");
         this.coolPlayerUUID = nbt.m_128461_("coolPlayerUUID");
         this.showInTab = nbt.m_128471_("showInTab");
         this.messageDelay = nbt.m_128459_("messageDelay");
         this.screamer2 = nbt.m_128471_("screamer2");
         this.AllItems = nbt.m_128471_("AllItems");
         this.x = nbt.m_128459_("x");
         this.y = nbt.m_128459_("y");
         this.z = nbt.m_128459_("z");
         this.generated = nbt.m_128471_("generated");
         this.AllItemsMessagesStarted = nbt.m_128471_("AllItemsMessagesStarted");
         this.HasPlayedDialog = nbt.m_128471_("HasPlayedDialog");
         this.chatTriggered = nbt.m_128471_("chatTriggered");
         this.errors = nbt.m_128459_("errors");
         this.breakb = nbt.m_128471_("breakb");
         this.aikoDialogueStarted = nbt.m_128471_("aikoDialogueStarted");
         this.dimens = nbt.m_128471_("dimens");
         this.dimens2 = nbt.m_128471_("dimens2");
         this.screamer3 = nbt.m_128471_("screamer3");
         this.buildblock = nbt.m_128471_("buildblock");
         this.Spawnlost = nbt.m_128471_("Spawnlost");
         this.DialogueNum = nbt.m_128459_("DialogueNum");
         this.DialogueUsed = nbt.m_128471_("DialogueUsed");
         this.EndingD = nbt.m_128471_("EndingD");
         this.EndingF = nbt.m_128471_("EndingF");
         this.site = nbt.m_128471_("site");
         this.Scr1 = nbt.m_128471_("Scr1");
         this.Scr2 = nbt.m_128471_("Scr2");
         this.Scr3 = nbt.m_128471_("Scr3");
         this.Tunnel = nbt.m_128459_("Tunnel");
         this.Endingf = nbt.m_128471_("Endingf");
         this.kick = nbt.m_128471_("kick");
         this.story1 = nbt.m_128471_("story1");
         this.story0 = nbt.m_128471_("story0");
         this.story2 = nbt.m_128471_("story2");
         this.story3 = nbt.m_128471_("story3");
         this.KiilEnd = nbt.m_128471_("KiilEnd");
         this.endinga = nbt.m_128471_("endinga");
         this.quest1 = nbt.m_128471_("quest1");
         this.quest2 = nbt.m_128471_("quest2");
         this.quest3 = nbt.m_128471_("quest3");
         this.level1 = nbt.m_128471_("level1");
         this.level2 = nbt.m_128471_("level2");
         this.level3 = nbt.m_128471_("level3");
         this.Task1 = nbt.m_128471_("Task1");
         this.WorldLife = nbt.m_128459_("WorldLife");
         this.WorldLifeTemp = nbt.m_128459_("WorldLifeTemp");
         this.Task = nbt.m_128471_("Task");
         this.Task1SEC = nbt.m_128471_("Task1SEC");
         this.Task2 = nbt.m_128471_("Task2");
         this.OBS = nbt.m_128471_("OBS");
         this.Task3 = nbt.m_128471_("Task3");
         this.TaskEnd1 = nbt.m_128471_("TaskEnd1");
         this.TaskEnd2 = nbt.m_128471_("TaskEnd2");
         this.TaskEnd3 = nbt.m_128471_("TaskEnd3");
         this.Family = nbt.m_128471_("Family");
         this.Taskk = nbt.m_128471_("Taskk");
         this.Taskkk = nbt.m_128471_("Taskkk");
         this.BlockCommands = nbt.m_128471_("BlockCommands");
         this.Note = nbt.m_128471_("Note");
         this.CrashedPlayers = nbt.m_128461_("CrashedPlayers");
         this.TaskDialogue = nbt.m_128471_("TaskDialogue");
         this.Tips = nbt.m_128471_("Tips");
         this.Tips1 = nbt.m_128471_("Tips1");
         this.Tips2 = nbt.m_128471_("Tips2");
         this.Tips3 = nbt.m_128471_("Tips3");
         this.Steam = nbt.m_128471_("Steam");
         this.BlockDialogue = nbt.m_128471_("BlockDialogue");
         this.Change = nbt.m_128471_("Change");
         this.Task1T = nbt.m_128471_("Task1T");
         this.Task2T = nbt.m_128471_("Task2T");
         this.Task3T = nbt.m_128471_("Task3T");
         this.Survey = nbt.m_128471_("Survey");
         this.NumberOpen = nbt.m_128459_("NumberOpen");
         this.TimerN = nbt.m_128459_("TimerN");
         this.Times = nbt.m_128471_("Times");
         this.EndingDtext = nbt.m_128471_("EndingDtext");
         this.ActIIICompleted = nbt.m_128471_("ActIIICompleted");
         this.FatherKill = nbt.m_128471_("FatherKill");
      }

      public CompoundTag m_7176_(CompoundTag nbt) {
         nbt.m_128379_("Angry", this.Angry);
         nbt.m_128347_("Angrybuild", this.Angrybuild);
         nbt.m_128379_("AngryPlayerSpawned", this.AngryPlayerSpawned);
         nbt.m_128379_("build", this.build);
         nbt.m_128379_("builderLook", this.builderLook);
         nbt.m_128347_("builderSpawnTimer", this.builderSpawnTimer);
         nbt.m_128347_("builderX", this.builderX);
         nbt.m_128347_("builderY", this.builderY);
         nbt.m_128347_("builderZ", this.builderZ);
         nbt.m_128379_("Colljoin", this.Colljoin);
         nbt.m_128379_("delete", this.delete);
         nbt.m_128347_("Dialogue", this.Dialogue);
         nbt.m_128379_("DialogueBool", this.DialogueBool);
         nbt.m_128379_("Died", this.Died);
         nbt.m_128379_("DiedPayloadExecuted", this.DiedPayloadExecuted);
         nbt.m_128379_("Disc", this.Disc);
         nbt.m_128379_("dox", this.dox);
         nbt.m_128379_("eventfollover", this.eventfollover);
         nbt.m_128379_("First", this.First);
         nbt.m_128379_("FirstJoin", this.FirstJoin);
         nbt.m_128379_("Fiveth", this.Fiveth);
         nbt.m_128379_("follow", this.follow);
         nbt.m_128347_("followerdied", this.followerdied);
         nbt.m_128379_("Fourth", this.Fourth);
         nbt.m_128379_("GameStarted", this.GameStarted);
         nbt.m_128379_("Inworld", this.Inworld);
         nbt.m_128379_("isBlockEmpty", this.isBlockEmpty);
         nbt.m_128347_("kickDelayTicks", this.kickDelayTicks);
         nbt.m_128347_("PlayerAngry", this.PlayerAngry);
         nbt.m_128347_("PlayerX", this.PlayerX);
         nbt.m_128347_("PlayerY", this.PlayerY);
         nbt.m_128347_("PlayerZ", this.PlayerZ);
         nbt.m_128379_("safeip", this.safeip);
         nbt.m_128379_("Screamer1", this.Screamer1);
         nbt.m_128347_("ScreamerTimer", this.ScreamerTimer);
         nbt.m_128379_("Second", this.Second);
         nbt.m_128379_("Seventh", this.Seventh);
         nbt.m_128379_("Sixth", this.Sixth);
         nbt.m_128379_("spawn", this.spawn);
         nbt.m_128379_("summon", this.summon);
         nbt.m_128379_("Third", this.Third);
         nbt.m_128347_("TimerBuild", this.TimerBuild);
         nbt.m_128379_("TimerEnd", this.TimerEnd);
         nbt.m_128347_("TimerJoin", this.TimerJoin);
         nbt.m_128379_("window", this.window);
         nbt.m_128347_("WorldDied", this.WorldDied);
         nbt.m_128347_("worldDiedTemp", this.worldDiedTemp);
         nbt.m_128379_("timer", this.timer);
         nbt.m_128347_("Gates", this.Gates);
         nbt.m_128379_("shard1", this.shard1);
         nbt.m_128379_("shard2", this.shard2);
         nbt.m_128379_("shard3", this.shard3);
         nbt.m_128379_("shard4", this.shard4);
         nbt.m_128379_("filesCreated", this.filesCreated);
         nbt.m_128379_("GameFinished", this.GameFinished);
         nbt.m_128347_("currentSkinIndex", this.currentSkinIndex);
         nbt.m_128359_("CoolPlayer303Skin", this.CoolPlayer303Skin);
         nbt.m_128359_("coolPlayerName", this.coolPlayerName);
         nbt.m_128379_("firstSpawnDone", this.firstSpawnDone);
         nbt.m_128379_("timerStarted", this.timerStarted);
         nbt.m_128359_("coolPlayerUUID", this.coolPlayerUUID);
         nbt.m_128379_("showInTab", this.showInTab);
         nbt.m_128347_("messageDelay", this.messageDelay);
         nbt.m_128379_("screamer2", this.screamer2);
         nbt.m_128379_("AllItems", this.AllItems);
         nbt.m_128347_("x", this.x);
         nbt.m_128347_("y", this.y);
         nbt.m_128347_("z", this.z);
         nbt.m_128379_("generated", this.generated);
         nbt.m_128379_("AllItemsMessagesStarted", this.AllItemsMessagesStarted);
         nbt.m_128379_("HasPlayedDialog", this.HasPlayedDialog);
         nbt.m_128379_("chatTriggered", this.chatTriggered);
         nbt.m_128347_("errors", this.errors);
         nbt.m_128379_("breakb", this.breakb);
         nbt.m_128379_("aikoDialogueStarted", this.aikoDialogueStarted);
         nbt.m_128379_("dimens", this.dimens);
         nbt.m_128379_("dimens2", this.dimens2);
         nbt.m_128379_("screamer3", this.screamer3);
         nbt.m_128379_("buildblock", this.buildblock);
         nbt.m_128379_("Spawnlost", this.Spawnlost);
         nbt.m_128347_("DialogueNum", this.DialogueNum);
         nbt.m_128379_("DialogueUsed", this.DialogueUsed);
         nbt.m_128379_("EndingD", this.EndingD);
         nbt.m_128379_("EndingF", this.EndingF);
         nbt.m_128379_("site", this.site);
         nbt.m_128379_("Scr1", this.Scr1);
         nbt.m_128379_("Scr2", this.Scr2);
         nbt.m_128379_("Scr3", this.Scr3);
         nbt.m_128347_("Tunnel", this.Tunnel);
         nbt.m_128379_("Endingf", this.Endingf);
         nbt.m_128379_("kick", this.kick);
         nbt.m_128379_("story1", this.story1);
         nbt.m_128379_("story0", this.story0);
         nbt.m_128379_("story2", this.story2);
         nbt.m_128379_("story3", this.story3);
         nbt.m_128379_("KiilEnd", this.KiilEnd);
         nbt.m_128379_("endinga", this.endinga);
         nbt.m_128379_("quest1", this.quest1);
         nbt.m_128379_("quest2", this.quest2);
         nbt.m_128379_("quest3", this.quest3);
         nbt.m_128379_("level1", this.level1);
         nbt.m_128379_("level2", this.level2);
         nbt.m_128379_("level3", this.level3);
         nbt.m_128379_("Task1", this.Task1);
         nbt.m_128347_("WorldLife", this.WorldLife);
         nbt.m_128347_("WorldLifeTemp", this.WorldLifeTemp);
         nbt.m_128379_("Task", this.Task);
         nbt.m_128379_("Task1SEC", this.Task1SEC);
         nbt.m_128379_("Task2", this.Task2);
         nbt.m_128379_("OBS", this.OBS);
         nbt.m_128379_("Task3", this.Task3);
         nbt.m_128379_("TaskEnd1", this.TaskEnd1);
         nbt.m_128379_("TaskEnd2", this.TaskEnd2);
         nbt.m_128379_("TaskEnd3", this.TaskEnd3);
         nbt.m_128379_("Family", this.Family);
         nbt.m_128379_("Taskk", this.Taskk);
         nbt.m_128379_("Taskkk", this.Taskkk);
         nbt.m_128379_("BlockCommands", this.BlockCommands);
         nbt.m_128379_("Note", this.Note);
         nbt.m_128359_("CrashedPlayers", this.CrashedPlayers);
         nbt.m_128379_("TaskDialogue", this.TaskDialogue);
         nbt.m_128379_("Tips", this.Tips);
         nbt.m_128379_("Tips1", this.Tips1);
         nbt.m_128379_("Tips2", this.Tips2);
         nbt.m_128379_("Tips3", this.Tips3);
         nbt.m_128379_("Steam", this.Steam);
         nbt.m_128379_("BlockDialogue", this.BlockDialogue);
         nbt.m_128379_("Change", this.Change);
         nbt.m_128379_("Task1T", this.Task1T);
         nbt.m_128379_("Task2T", this.Task2T);
         nbt.m_128379_("Task3T", this.Task3T);
         nbt.m_128379_("Survey", this.Survey);
         nbt.m_128347_("NumberOpen", this.NumberOpen);
         nbt.m_128347_("TimerN", this.TimerN);
         nbt.m_128379_("Times", this.Times);
         nbt.m_128379_("EndingDtext", this.EndingDtext);
         nbt.m_128379_("ActIIICompleted", this.ActIIICompleted);
         nbt.m_128379_("FatherKill", this.FatherKill);
         return nbt;
      }

      public void syncData(LevelAccessor world) {
         this.m_77762_();
         if (world instanceof Level && !world.m_5776_()) {
            InsideTheSystemMod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), new InsideTheSystemModVariables.SavedDataSyncMessage(0, this));
         }
      }

      public static InsideTheSystemModVariables.MapVariables get(LevelAccessor world) {
         return world instanceof ServerLevelAccessor serverLevelAcc
            ? (InsideTheSystemModVariables.MapVariables)serverLevelAcc.m_6018_()
               .m_7654_()
               .m_129880_(Level.f_46428_)
               .m_8895_()
               .m_164861_(e -> load(e), InsideTheSystemModVariables.MapVariables::new, "inside_the_system_mapvars")
            : clientSide;
      }
   }

   public static class SavedDataSyncMessage {
      public int type;
      public SavedData data;

      public SavedDataSyncMessage(FriendlyByteBuf buffer) {
         this.type = buffer.readInt();
         this.data = (SavedData)(this.type == 0 ? new InsideTheSystemModVariables.MapVariables() : new InsideTheSystemModVariables.WorldVariables());
         if (this.data instanceof InsideTheSystemModVariables.MapVariables _mapvars) {
            _mapvars.read(buffer.m_130260_());
         } else if (this.data instanceof InsideTheSystemModVariables.WorldVariables _worldvars) {
            _worldvars.read(buffer.m_130260_());
         }
      }

      public SavedDataSyncMessage(int type, SavedData data) {
         this.type = type;
         this.data = data;
      }

      public static void buffer(InsideTheSystemModVariables.SavedDataSyncMessage message, FriendlyByteBuf buffer) {
         buffer.writeInt(message.type);
         buffer.m_130079_(message.data.m_7176_(new CompoundTag()));
      }

      public static void handler(InsideTheSystemModVariables.SavedDataSyncMessage message, Supplier<Context> contextSupplier) {
         Context context = contextSupplier.get();
         context.enqueueWork(() -> {
            if (!context.getDirection().getReceptionSide().isServer()) {
               if (message.type == 0) {
                  InsideTheSystemModVariables.MapVariables.clientSide = (InsideTheSystemModVariables.MapVariables)message.data;
               } else {
                  InsideTheSystemModVariables.WorldVariables.clientSide = (InsideTheSystemModVariables.WorldVariables)message.data;
               }
            }
         });
         context.setPacketHandled(true);
      }
   }

   public static class WorldVariables extends SavedData {
      public static final String DATA_NAME = "inside_the_system_worldvars";
      static InsideTheSystemModVariables.WorldVariables clientSide = new InsideTheSystemModVariables.WorldVariables();

      public static InsideTheSystemModVariables.WorldVariables load(CompoundTag tag) {
         InsideTheSystemModVariables.WorldVariables data = new InsideTheSystemModVariables.WorldVariables();
         data.read(tag);
         return data;
      }

      public void read(CompoundTag nbt) {
      }

      public CompoundTag m_7176_(CompoundTag nbt) {
         return nbt;
      }

      public void syncData(LevelAccessor world) {
         this.m_77762_();
         if (world instanceof Level level && !level.m_5776_()) {
            InsideTheSystemMod.PACKET_HANDLER
               .send(PacketDistributor.DIMENSION.with(level::m_46472_), new InsideTheSystemModVariables.SavedDataSyncMessage(1, this));
         }
      }

      public static InsideTheSystemModVariables.WorldVariables get(LevelAccessor world) {
         return world instanceof ServerLevel level
            ? (InsideTheSystemModVariables.WorldVariables)level.m_8895_()
               .m_164861_(e -> load(e), InsideTheSystemModVariables.WorldVariables::new, "inside_the_system_worldvars")
            : clientSide;
      }
   }
}
