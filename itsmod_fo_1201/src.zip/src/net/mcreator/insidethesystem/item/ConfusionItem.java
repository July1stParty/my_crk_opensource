package net.mcreator.insidethesystem.item;

import java.util.List;
import net.mcreator.insidethesystem.procedures.ActivateProcedure;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public class ConfusionItem extends Item {
   public ConfusionItem() {
      super(new Properties().m_41487_(1).m_41497_(Rarity.RARE));
   }

   public void m_7373_(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
      super.m_7373_(itemstack, world, list, flag);
      list.add(Component.m_237113_("§oIt was making me feel lost§r"));
   }

   public InteractionResult m_6225_(UseOnContext context) {
      super.m_6225_(context);
      ActivateProcedure.execute(
         context.m_43725_(), context.m_8083_().m_123341_(), context.m_8083_().m_123342_(), context.m_8083_().m_123343_(), context.m_43723_()
      );
      return InteractionResult.SUCCESS;
   }
}
