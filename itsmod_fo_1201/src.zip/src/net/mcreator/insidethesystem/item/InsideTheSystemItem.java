package net.mcreator.insidethesystem.item;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.RecordItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;

public class InsideTheSystemItem extends RecordItem {
   public InsideTheSystemItem() {
      super(
         0,
         () -> (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:mainost")),
         new Properties().m_41487_(1).m_41497_(Rarity.RARE),
         5450
      );
   }

   public void m_7373_(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
      super.m_7373_(itemstack, world, list, flag);
      list.add(Component.m_237113_("I don't know if anything worthwhile will come of this. I've put a lot of effort and time into it"));
      list.add(Component.m_237113_("and if nothing comes of it"));
      list.add(Component.m_237113_("I don't know what I'll do"));
   }
}
