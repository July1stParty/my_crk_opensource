package net.mcreator.insidethesystem.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.mcreator.insidethesystem.procedures.SkipProcedure;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class SkipintrCommand {
   @SubscribeEvent
   public static void registerCommand(RegisterCommandsEvent event) {
      event.getDispatcher().register((LiteralArgumentBuilder)Commands.m_82127_("skip").executes(arguments -> {
         ServerLevel world = ((CommandSourceStack)arguments.getSource()).m_81372_();
         double x = ((CommandSourceStack)arguments.getSource()).m_81371_().m_7096_();
         double y = ((CommandSourceStack)arguments.getSource()).m_81371_().m_7098_();
         double z = ((CommandSourceStack)arguments.getSource()).m_81371_().m_7094_();
         Entity entity = ((CommandSourceStack)arguments.getSource()).m_81373_();
         if (entity == null) {
            entity = FakePlayerFactory.getMinecraft(world);
         }

         Direction direction = entity.m_6350_();
         SkipProcedure.execute(world, x, y, z);
         return 0;
      }));
   }
}
