package net.mcreator.insidethesystem.init;

import net.mcreator.insidethesystem.entity.AngryBuilderEntity;
import net.mcreator.insidethesystem.entity.AngryCoolPlayer303Entity;
import net.mcreator.insidethesystem.entity.AyanamiAikoEntity;
import net.mcreator.insidethesystem.entity.CoolPlayer303Entity;
import net.mcreator.insidethesystem.entity.Father2Entity;
import net.mcreator.insidethesystem.entity.FatherEndEntity;
import net.mcreator.insidethesystem.entity.FatherEntity;
import net.mcreator.insidethesystem.entity.LostEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType.Builder;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@EventBusSubscriber(bus = Bus.MOD)
public class InsideTheSystemModEntities {
   public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, "inside_the_system");
   public static final RegistryObject<EntityType<AngryCoolPlayer303Entity>> ANGRY_COOL_PLAYER_303 = register(
      "angry_cool_player_303",
      Builder.m_20704_(AngryCoolPlayer303Entity::new, MobCategory.MONSTER)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .setCustomClientFactory(AngryCoolPlayer303Entity::new)
         .m_20719_()
         .m_20699_(0.6F, 1.8F)
   );
   public static final RegistryObject<EntityType<CoolPlayer303Entity>> COOL_PLAYER_303 = register(
      "cool_player_303",
      Builder.m_20704_(CoolPlayer303Entity::new, MobCategory.MONSTER)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .setCustomClientFactory(CoolPlayer303Entity::new)
         .m_20699_(0.6F, 1.8F)
   );
   public static final RegistryObject<EntityType<AngryBuilderEntity>> ANGRY_BUILDER = register(
      "angry_builder",
      Builder.m_20704_(AngryBuilderEntity::new, MobCategory.MONSTER)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .setCustomClientFactory(AngryBuilderEntity::new)
         .m_20719_()
         .m_20699_(0.6F, 1.8F)
   );
   public static final RegistryObject<EntityType<AyanamiAikoEntity>> AYANAMI_AIKO = register(
      "ayanami_aiko",
      Builder.m_20704_(AyanamiAikoEntity::new, MobCategory.MONSTER)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .setCustomClientFactory(AyanamiAikoEntity::new)
         .m_20719_()
         .m_20699_(0.6F, 1.8F)
   );
   public static final RegistryObject<EntityType<LostEntity>> LOST = register(
      "lost",
      Builder.m_20704_(LostEntity::new, MobCategory.MONSTER)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .setCustomClientFactory(LostEntity::new)
         .m_20719_()
         .m_20699_(0.6F, 1.8F)
   );
   public static final RegistryObject<EntityType<FatherEntity>> FATHER = register(
      "father",
      Builder.m_20704_(FatherEntity::new, MobCategory.MONSTER)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .setCustomClientFactory(FatherEntity::new)
         .m_20719_()
         .m_20699_(0.6F, 1.8F)
   );
   public static final RegistryObject<EntityType<Father2Entity>> FATHER_2 = register(
      "father_2",
      Builder.m_20704_(Father2Entity::new, MobCategory.MONSTER)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .setCustomClientFactory(Father2Entity::new)
         .m_20719_()
         .m_20699_(0.6F, 1.8F)
   );
   public static final RegistryObject<EntityType<FatherEndEntity>> FATHER_END = register(
      "father_end",
      Builder.m_20704_(FatherEndEntity::new, MobCategory.MONSTER)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .setCustomClientFactory(FatherEndEntity::new)
         .m_20699_(0.6F, 1.8F)
   );

   private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, Builder<T> entityTypeBuilder) {
      return REGISTRY.register(registryname, () -> entityTypeBuilder.m_20712_(registryname));
   }

   @SubscribeEvent
   public static void init(FMLCommonSetupEvent event) {
      event.enqueueWork(() -> {
         AngryCoolPlayer303Entity.init();
         CoolPlayer303Entity.init();
         AngryBuilderEntity.init();
         AyanamiAikoEntity.init();
         LostEntity.init();
         FatherEntity.init();
         Father2Entity.init();
         FatherEndEntity.init();
      });
   }

   @SubscribeEvent
   public static void registerAttributes(EntityAttributeCreationEvent event) {
      event.put((EntityType)ANGRY_COOL_PLAYER_303.get(), AngryCoolPlayer303Entity.createAttributes().m_22265_());
      event.put((EntityType)COOL_PLAYER_303.get(), CoolPlayer303Entity.createAttributes().m_22265_());
      event.put((EntityType)ANGRY_BUILDER.get(), AngryBuilderEntity.createAttributes().m_22265_());
      event.put((EntityType)AYANAMI_AIKO.get(), AyanamiAikoEntity.createAttributes().m_22265_());
      event.put((EntityType)LOST.get(), LostEntity.createAttributes().m_22265_());
      event.put((EntityType)FATHER.get(), FatherEntity.createAttributes().m_22265_());
      event.put((EntityType)FATHER_2.get(), Father2Entity.createAttributes().m_22265_());
      event.put((EntityType)FATHER_END.get(), FatherEndEntity.createAttributes().m_22265_());
   }
}
