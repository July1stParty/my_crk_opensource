package net.mcreator.insidethesystem.init;

import net.mcreator.insidethesystem.client.gui.PasswordWriteScreen;
import net.mcreator.insidethesystem.client.gui.Survey1Screen;
import net.mcreator.insidethesystem.client.gui.Survey2Screen;
import net.mcreator.insidethesystem.client.gui.Survey3Screen;
import net.mcreator.insidethesystem.client.gui.Survey4Screen;
import net.mcreator.insidethesystem.client.gui.Survey5Screen;
import net.mcreator.insidethesystem.client.gui.TipsOpen1Screen;
import net.mcreator.insidethesystem.client.gui.TipsOpen2Screen;
import net.mcreator.insidethesystem.client.gui.TipsOpen3Screen;
import net.mcreator.insidethesystem.client.gui.TipsOpenScreen;
import net.mcreator.insidethesystem.client.gui.WarningScreen;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@EventBusSubscriber(bus = Bus.MOD, value = Dist.CLIENT)
public class InsideTheSystemModScreens {
   @SubscribeEvent
   public static void clientLoad(FMLClientSetupEvent event) {
      event.enqueueWork(() -> {
         MenuScreens.m_96206_((MenuType)InsideTheSystemModMenus.WARNING.get(), WarningScreen::new);
         MenuScreens.m_96206_((MenuType)InsideTheSystemModMenus.PASSWORD_WRITE.get(), PasswordWriteScreen::new);
         MenuScreens.m_96206_((MenuType)InsideTheSystemModMenus.TIPS_OPEN.get(), TipsOpenScreen::new);
         MenuScreens.m_96206_((MenuType)InsideTheSystemModMenus.TIPS_OPEN_2.get(), TipsOpen2Screen::new);
         MenuScreens.m_96206_((MenuType)InsideTheSystemModMenus.TIPS_OPEN_3.get(), TipsOpen3Screen::new);
         MenuScreens.m_96206_((MenuType)InsideTheSystemModMenus.TIPS_OPEN_1.get(), TipsOpen1Screen::new);
         MenuScreens.m_96206_((MenuType)InsideTheSystemModMenus.SURVEY_1.get(), Survey1Screen::new);
         MenuScreens.m_96206_((MenuType)InsideTheSystemModMenus.SURVEY_2.get(), Survey2Screen::new);
         MenuScreens.m_96206_((MenuType)InsideTheSystemModMenus.SURVEY_3.get(), Survey3Screen::new);
         MenuScreens.m_96206_((MenuType)InsideTheSystemModMenus.SURVEY_4.get(), Survey4Screen::new);
         MenuScreens.m_96206_((MenuType)InsideTheSystemModMenus.SURVEY_5.get(), Survey5Screen::new);
      });
   }
}
