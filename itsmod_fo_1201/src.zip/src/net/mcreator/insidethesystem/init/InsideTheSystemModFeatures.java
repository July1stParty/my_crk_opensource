package net.mcreator.insidethesystem.init;

import net.mcreator.insidethesystem.world.features.AltarFeature;
import net.mcreator.insidethesystem.world.features.CampFeature;
import net.mcreator.insidethesystem.world.features.GerdStruFeature;
import net.mcreator.insidethesystem.world.features.MemoryFeature;
import net.mcreator.insidethesystem.world.features.MessageFeature;
import net.mcreator.insidethesystem.world.features.PortalFeature;
import net.mcreator.insidethesystem.world.features.SpawnStruFeature;
import net.mcreator.insidethesystem.world.features.StartHouseFeature;
import net.mcreator.insidethesystem.world.features.StonehouseFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@EventBusSubscriber
public class InsideTheSystemModFeatures {
   public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, "inside_the_system");
   public static final RegistryObject<Feature<?>> STONEHOUSE = REGISTRY.register("stonehouse", StonehouseFeature::new);
   public static final RegistryObject<Feature<?>> MEMORY = REGISTRY.register("memory", MemoryFeature::new);
   public static final RegistryObject<Feature<?>> GERD_STRU = REGISTRY.register("gerd_stru", GerdStruFeature::new);
   public static final RegistryObject<Feature<?>> ALTAR = REGISTRY.register("altar", AltarFeature::new);
   public static final RegistryObject<Feature<?>> CAMP = REGISTRY.register("camp", CampFeature::new);
   public static final RegistryObject<Feature<?>> MESSAGE = REGISTRY.register("message", MessageFeature::new);
   public static final RegistryObject<Feature<?>> START_HOUSE = REGISTRY.register("start_house", StartHouseFeature::new);
   public static final RegistryObject<Feature<?>> SPAWN_STRU = REGISTRY.register("spawn_stru", SpawnStruFeature::new);
   public static final RegistryObject<Feature<?>> PORTAL = REGISTRY.register("portal", PortalFeature::new);
}
