package net.mcreator.insidethesystem.init;

import net.mcreator.insidethesystem.item.AcceptanceItem;
import net.mcreator.insidethesystem.item.AikoItem;
import net.mcreator.insidethesystem.item.BetrayalItem;
import net.mcreator.insidethesystem.item.BloodyknifeItem;
import net.mcreator.insidethesystem.item.ConfusionItem;
import net.mcreator.insidethesystem.item.GerdItem;
import net.mcreator.insidethesystem.item.InsideTheSystemItem;
import net.mcreator.insidethesystem.item.KnifeItem;
import net.mcreator.insidethesystem.item.PictureItem;
import net.mcreator.insidethesystem.item.ShellnecklaceItem;
import net.mcreator.insidethesystem.item.StarofMemoriesItem;
import net.mcreator.insidethesystem.item.TipsItem;
import net.mcreator.insidethesystem.item.ViolenceItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class InsideTheSystemModItems {
   public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, "inside_the_system");
   public static final RegistryObject<Item> ANGRY_COOL_PLAYER_303_SPAWN_EGG = REGISTRY.register(
      "angry_cool_player_303_spawn_egg", () -> new ForgeSpawnEggItem(InsideTheSystemModEntities.ANGRY_COOL_PLAYER_303, -1, -1, new Properties())
   );
   public static final RegistryObject<Item> COOL_PLAYER_303_SPAWN_EGG = REGISTRY.register(
      "cool_player_303_spawn_egg", () -> new ForgeSpawnEggItem(InsideTheSystemModEntities.COOL_PLAYER_303, -1, -1, new Properties())
   );
   public static final RegistryObject<Item> ANGRY_BUILDER_SPAWN_EGG = REGISTRY.register(
      "angry_builder_spawn_egg", () -> new ForgeSpawnEggItem(InsideTheSystemModEntities.ANGRY_BUILDER, -1, -1, new Properties())
   );
   public static final RegistryObject<Item> GATE = block(InsideTheSystemModBlocks.GATE);
   public static final RegistryObject<Item> STAROF_MEMORIES = REGISTRY.register("starof_memories", () -> new StarofMemoriesItem());
   public static final RegistryObject<Item> BETRAYAL = REGISTRY.register("betrayal", () -> new BetrayalItem());
   public static final RegistryObject<Item> VIOLENCE = REGISTRY.register("violence", () -> new ViolenceItem());
   public static final RegistryObject<Item> CONFUSION = REGISTRY.register("confusion", () -> new ConfusionItem());
   public static final RegistryObject<Item> ACCEPTANCE = REGISTRY.register("acceptance", () -> new AcceptanceItem());
   public static final RegistryObject<Item> BASE = block(InsideTheSystemModBlocks.BASE);
   public static final RegistryObject<Item> ACTIVATE_GATE = block(InsideTheSystemModBlocks.ACTIVATE_GATE);
   public static final RegistryObject<Item> KNIFE = REGISTRY.register("knife", () -> new KnifeItem());
   public static final RegistryObject<Item> BLOODYKNIFE = REGISTRY.register("bloodyknife", () -> new BloodyknifeItem());
   public static final RegistryObject<Item> SHELLNECKLACE_CHESTPLATE = REGISTRY.register("shellnecklace_chestplate", () -> new ShellnecklaceItem.Chestplate());
   public static final RegistryObject<Item> GERD = REGISTRY.register("gerd", () -> new GerdItem());
   public static final RegistryObject<Item> AIKO = REGISTRY.register("aiko", () -> new AikoItem());
   public static final RegistryObject<Item> BLOODY_JUKEBOX = block(InsideTheSystemModBlocks.BLOODY_JUKEBOX);
   public static final RegistryObject<Item> PASSWORD_BLOCK = block(InsideTheSystemModBlocks.PASSWORD_BLOCK);
   public static final RegistryObject<Item> INSIDE_THE_SYSTEM = REGISTRY.register("inside_the_system", () -> new InsideTheSystemItem());
   public static final RegistryObject<Item> MEMORY_DOORS = doubleBlock(InsideTheSystemModBlocks.MEMORY_DOORS);
   public static final RegistryObject<Item> PICTURE = REGISTRY.register("picture", () -> new PictureItem());
   public static final RegistryObject<Item> TIPS = REGISTRY.register("tips", () -> new TipsItem());

   private static RegistryObject<Item> block(RegistryObject<Block> block) {
      return REGISTRY.register(block.getId().m_135815_(), () -> new BlockItem((Block)block.get(), new Properties()));
   }

   private static RegistryObject<Item> doubleBlock(RegistryObject<Block> block) {
      return REGISTRY.register(block.getId().m_135815_(), () -> new DoubleHighBlockItem((Block)block.get(), new Properties()));
   }
}
