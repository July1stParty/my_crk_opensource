package net.mcreator.insidethesystem.init;

import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.GameRules.Category;
import net.minecraft.world.level.GameRules.IntegerValue;
import net.minecraft.world.level.GameRules.Key;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;

@EventBusSubscriber(bus = Bus.MOD)
public class InsideTheSystemModGameRules {
   public static final Key<IntegerValue> PLAYER_ANGRY = GameRules.m_46189_("playerAngry", Category.PLAYER, IntegerValue.m_46312_(50));
}
