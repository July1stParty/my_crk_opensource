package net.mcreator.insidethesystem.init;

import net.mcreator.insidethesystem.block.ActivateGateBlock;
import net.mcreator.insidethesystem.block.BaseBlock;
import net.mcreator.insidethesystem.block.BloodyJukeboxBlock;
import net.mcreator.insidethesystem.block.GateBlock;
import net.mcreator.insidethesystem.block.MemoryDoorsBlock;
import net.mcreator.insidethesystem.block.PasswordBlockBlock;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class InsideTheSystemModBlocks {
   public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, "inside_the_system");
   public static final RegistryObject<Block> GATE = REGISTRY.register("gate", () -> new GateBlock());
   public static final RegistryObject<Block> BASE = REGISTRY.register("base", () -> new BaseBlock());
   public static final RegistryObject<Block> ACTIVATE_GATE = REGISTRY.register("activate_gate", () -> new ActivateGateBlock());
   public static final RegistryObject<Block> BLOODY_JUKEBOX = REGISTRY.register("bloody_jukebox", () -> new BloodyJukeboxBlock());
   public static final RegistryObject<Block> PASSWORD_BLOCK = REGISTRY.register("password_block", () -> new PasswordBlockBlock());
   public static final RegistryObject<Block> MEMORY_DOORS = REGISTRY.register("memory_doors", () -> new MemoryDoorsBlock());
}
