package net.mcreator.insidethesystem.init;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.ItemLike;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.registries.DeferredRegister;

@EventBusSubscriber(bus = Bus.MOD)
public class InsideTheSystemModTabs {
   public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.f_279569_, "inside_the_system");

   @SubscribeEvent
   public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
      if (tabData.getTabKey() == CreativeModeTabs.f_256731_) {
         tabData.m_246326_((ItemLike)InsideTheSystemModItems.ANGRY_COOL_PLAYER_303_SPAWN_EGG.get());
         tabData.m_246326_((ItemLike)InsideTheSystemModItems.COOL_PLAYER_303_SPAWN_EGG.get());
         tabData.m_246326_((ItemLike)InsideTheSystemModItems.ANGRY_BUILDER_SPAWN_EGG.get());
      }
   }
}
