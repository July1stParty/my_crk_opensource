package net.mcreator.insidethesystem.init;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class InsideTheSystemModSounds {
   public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, "inside_the_system");
   public static final RegistryObject<SoundEvent> SCREAMER1 = REGISTRY.register(
      "screamer1", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "screamer1"))
   );
   public static final RegistryObject<SoundEvent> BUILDERSPAWN = REGISTRY.register(
      "builderspawn", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "builderspawn"))
   );
   public static final RegistryObject<SoundEvent> MUSICBOX = REGISTRY.register(
      "musicbox", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "musicbox"))
   );
   public static final RegistryObject<SoundEvent> END = REGISTRY.register("end", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "end")));
   public static final RegistryObject<SoundEvent> BEGINING = REGISTRY.register(
      "begining", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "begining"))
   );
   public static final RegistryObject<SoundEvent> ACTIVATE = REGISTRY.register(
      "activate", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "activate"))
   );
   public static final RegistryObject<SoundEvent> SHARDS = REGISTRY.register(
      "shards", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "shards"))
   );
   public static final RegistryObject<SoundEvent> BOOD = REGISTRY.register(
      "bood", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "bood"))
   );
   public static final RegistryObject<SoundEvent> MEMORIES = REGISTRY.register(
      "memories", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "memories"))
   );
   public static final RegistryObject<SoundEvent> ERROR = REGISTRY.register(
      "error", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "error"))
   );
   public static final RegistryObject<SoundEvent> ACCEPT = REGISTRY.register(
      "accept", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "accept"))
   );
   public static final RegistryObject<SoundEvent> MAINOST = REGISTRY.register(
      "mainost", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "mainost"))
   );
   public static final RegistryObject<SoundEvent> PSWSCREAMER = REGISTRY.register(
      "pswscreamer", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "pswscreamer"))
   );
   public static final RegistryObject<SoundEvent> SPAWNFOLLOWER = REGISTRY.register(
      "spawnfollower", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "spawnfollower"))
   );
   public static final RegistryObject<SoundEvent> AIKO = REGISTRY.register(
      "aiko", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "aiko"))
   );
   public static final RegistryObject<SoundEvent> AMBIENTGOODDIMENS = REGISTRY.register(
      "ambientgooddimens", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "ambientgooddimens"))
   );
   public static final RegistryObject<SoundEvent> AMBIENT2 = REGISTRY.register(
      "ambient2", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "ambient2"))
   );
   public static final RegistryObject<SoundEvent> ENDINGD = REGISTRY.register(
      "endingd", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "endingd"))
   );
   public static final RegistryObject<SoundEvent> BROKENBOX = REGISTRY.register(
      "brokenbox", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "brokenbox"))
   );
   public static final RegistryObject<SoundEvent> ENDINGFSCREAMERS = REGISTRY.register(
      "endingfscreamers", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "endingfscreamers"))
   );
   public static final RegistryObject<SoundEvent> TUNNELSOUND = REGISTRY.register(
      "tunnelsound", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "tunnelsound"))
   );
   public static final RegistryObject<SoundEvent> OPENMEMORY = REGISTRY.register(
      "openmemory", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "openmemory"))
   );
   public static final RegistryObject<SoundEvent> RAVEN = REGISTRY.register(
      "raven", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "raven"))
   );
   public static final RegistryObject<SoundEvent> ENDINGAAMBIENT = REGISTRY.register(
      "endingaambient", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "endingaambient"))
   );
   public static final RegistryObject<SoundEvent> LIGHT = REGISTRY.register(
      "light", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "light"))
   );
   public static final RegistryObject<SoundEvent> FATHERSPAWN = REGISTRY.register(
      "fatherspawn", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "fatherspawn"))
   );
   public static final RegistryObject<SoundEvent> RISESOUND = REGISTRY.register(
      "risesound", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "risesound"))
   );
   public static final RegistryObject<SoundEvent> WOOSH = REGISTRY.register(
      "woosh", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "woosh"))
   );
   public static final RegistryObject<SoundEvent> MUSICBOXATTAC = REGISTRY.register(
      "musicboxattac", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "musicboxattac"))
   );
   public static final RegistryObject<SoundEvent> ENDINGC = REGISTRY.register(
      "endingc", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "endingc"))
   );
   public static final RegistryObject<SoundEvent> TITLES = REGISTRY.register(
      "titles", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "titles"))
   );
   public static final RegistryObject<SoundEvent> BEHIND = REGISTRY.register(
      "behind", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "behind"))
   );
   public static final RegistryObject<SoundEvent> BEHINDSCREAMER = REGISTRY.register(
      "behindscreamer", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "behindscreamer"))
   );
   public static final RegistryObject<SoundEvent> PHOTO = REGISTRY.register(
      "photo", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "photo"))
   );
   public static final RegistryObject<SoundEvent> THESUN = REGISTRY.register(
      "thesun", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "thesun"))
   );
   public static final RegistryObject<SoundEvent> SPAWNPLAYER = REGISTRY.register(
      "spawnplayer", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "spawnplayer"))
   );
   public static final RegistryObject<SoundEvent> CHANGE = REGISTRY.register(
      "change", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "change"))
   );
   public static final RegistryObject<SoundEvent> WRITE = REGISTRY.register(
      "write", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "write"))
   );
   public static final RegistryObject<SoundEvent> SMILE = REGISTRY.register(
      "smile", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "smile"))
   );
   public static final RegistryObject<SoundEvent> GLITCH = REGISTRY.register(
      "glitch", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "glitch"))
   );
   public static final RegistryObject<SoundEvent> SHAGI = REGISTRY.register(
      "shagi", () -> SoundEvent.m_262824_(new ResourceLocation("inside_the_system", "shagi"))
   );
}
