package net.mcreator.insidethesystem.init;

import net.mcreator.insidethesystem.world.inventory.PasswordWriteMenu;
import net.mcreator.insidethesystem.world.inventory.Survey1Menu;
import net.mcreator.insidethesystem.world.inventory.Survey2Menu;
import net.mcreator.insidethesystem.world.inventory.Survey3Menu;
import net.mcreator.insidethesystem.world.inventory.Survey4Menu;
import net.mcreator.insidethesystem.world.inventory.Survey5Menu;
import net.mcreator.insidethesystem.world.inventory.TipsOpen1Menu;
import net.mcreator.insidethesystem.world.inventory.TipsOpen2Menu;
import net.mcreator.insidethesystem.world.inventory.TipsOpen3Menu;
import net.mcreator.insidethesystem.world.inventory.TipsOpenMenu;
import net.mcreator.insidethesystem.world.inventory.WarningMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class InsideTheSystemModMenus {
   public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, "inside_the_system");
   public static final RegistryObject<MenuType<WarningMenu>> WARNING = REGISTRY.register("warning", () -> IForgeMenuType.create(WarningMenu::new));
   public static final RegistryObject<MenuType<PasswordWriteMenu>> PASSWORD_WRITE = REGISTRY.register(
      "password_write", () -> IForgeMenuType.create(PasswordWriteMenu::new)
   );
   public static final RegistryObject<MenuType<TipsOpenMenu>> TIPS_OPEN = REGISTRY.register("tips_open", () -> IForgeMenuType.create(TipsOpenMenu::new));
   public static final RegistryObject<MenuType<TipsOpen2Menu>> TIPS_OPEN_2 = REGISTRY.register("tips_open_2", () -> IForgeMenuType.create(TipsOpen2Menu::new));
   public static final RegistryObject<MenuType<TipsOpen3Menu>> TIPS_OPEN_3 = REGISTRY.register("tips_open_3", () -> IForgeMenuType.create(TipsOpen3Menu::new));
   public static final RegistryObject<MenuType<TipsOpen1Menu>> TIPS_OPEN_1 = REGISTRY.register("tips_open_1", () -> IForgeMenuType.create(TipsOpen1Menu::new));
   public static final RegistryObject<MenuType<Survey1Menu>> SURVEY_1 = REGISTRY.register("survey_1", () -> IForgeMenuType.create(Survey1Menu::new));
   public static final RegistryObject<MenuType<Survey2Menu>> SURVEY_2 = REGISTRY.register("survey_2", () -> IForgeMenuType.create(Survey2Menu::new));
   public static final RegistryObject<MenuType<Survey3Menu>> SURVEY_3 = REGISTRY.register("survey_3", () -> IForgeMenuType.create(Survey3Menu::new));
   public static final RegistryObject<MenuType<Survey4Menu>> SURVEY_4 = REGISTRY.register("survey_4", () -> IForgeMenuType.create(Survey4Menu::new));
   public static final RegistryObject<MenuType<Survey5Menu>> SURVEY_5 = REGISTRY.register("survey_5", () -> IForgeMenuType.create(Survey5Menu::new));
}
