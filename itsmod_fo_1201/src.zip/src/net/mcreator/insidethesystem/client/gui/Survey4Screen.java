package net.mcreator.insidethesystem.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.HashMap;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.Survey4ButtonMessage;
import net.mcreator.insidethesystem.world.inventory.Survey4Menu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class Survey4Screen extends AbstractContainerScreen<Survey4Menu> {
   private static final HashMap<String, Object> guistate = Survey4Menu.guistate;
   private final Level world;
   private final int x;
   private final int y;
   private final int z;
   private final Player entity;
   Button button_yes;
   Button button_no;
   private static final ResourceLocation texture = new ResourceLocation("inside_the_system:textures/screens/survey_4.png");

   public Survey4Screen(Survey4Menu container, Inventory inventory, Component text) {
      super(container, inventory, text);
      this.world = container.world;
      this.x = container.x;
      this.y = container.y;
      this.z = container.z;
      this.entity = container.entity;
      this.f_97726_ = 176;
      this.f_97727_ = 166;
   }

   public void m_88315_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
      this.m_280273_(guiGraphics);
      super.m_88315_(guiGraphics, mouseX, mouseY, partialTicks);
      this.m_280072_(guiGraphics, mouseX, mouseY);
   }

   protected void m_7286_(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      guiGraphics.m_280163_(texture, this.f_97735_, this.f_97736_, 0.0F, 0.0F, this.f_97726_, this.f_97727_, this.f_97726_, this.f_97727_);
      RenderSystem.disableBlend();
   }

   public boolean m_7933_(int key, int b, int c) {
      if (key == 256) {
         this.f_96541_.f_91074_.m_6915_();
         return true;
      } else {
         return super.m_7933_(key, b, c);
      }
   }

   public void m_181908_() {
      super.m_181908_();
   }

   protected void m_280003_(GuiGraphics guiGraphics, int mouseX, int mouseY) {
      guiGraphics.m_280614_(
         this.f_96547_, Component.m_237115_("gui.inside_the_system.survey_4.label_are_you_alone_in_the_room_right"), 43, 46, -12829636, false
      );
      guiGraphics.m_280614_(this.f_96547_, Component.m_237115_("gui.inside_the_system.survey_4.label_room_right_now"), 43, 59, -12829636, false);
   }

   public void m_7379_() {
      super.m_7379_();
   }

   public void m_7856_() {
      super.m_7856_();
      this.button_yes = Button.m_253074_(Component.m_237115_("gui.inside_the_system.survey_4.button_yes"), e -> {
         InsideTheSystemMod.PACKET_HANDLER.sendToServer(new Survey4ButtonMessage(0, this.x, this.y, this.z));
         Survey4ButtonMessage.handleButtonAction(this.entity, 0, this.x, this.y, this.z);
      }).m_252987_(this.f_97735_ + 24, this.f_97736_ + 119, 40, 20).m_253136_();
      guistate.put("button:button_yes", this.button_yes);
      this.m_142416_(this.button_yes);
      this.button_no = Button.m_253074_(Component.m_237115_("gui.inside_the_system.survey_4.button_no"), e -> {
         InsideTheSystemMod.PACKET_HANDLER.sendToServer(new Survey4ButtonMessage(1, this.x, this.y, this.z));
         Survey4ButtonMessage.handleButtonAction(this.entity, 1, this.x, this.y, this.z);
      }).m_252987_(this.f_97735_ + 113, this.f_97736_ + 119, 35, 20).m_253136_();
      guistate.put("button:button_no", this.button_no);
      this.m_142416_(this.button_no);
   }
}
