package net.mcreator.insidethesystem.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.HashMap;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.TipsOpenButtonMessage;
import net.mcreator.insidethesystem.world.inventory.TipsOpenMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class TipsOpenScreen extends AbstractContainerScreen<TipsOpenMenu> {
   private static final HashMap<String, Object> guistate = TipsOpenMenu.guistate;
   private final Level world;
   private final int x;
   private final int y;
   private final int z;
   private final Player entity;
   ImageButton imagebutton_exit;
   private static final ResourceLocation texture = new ResourceLocation("inside_the_system:textures/screens/tips_open.png");

   public TipsOpenScreen(TipsOpenMenu container, Inventory inventory, Component text) {
      super(container, inventory, text);
      this.world = container.world;
      this.x = container.x;
      this.y = container.y;
      this.z = container.z;
      this.entity = container.entity;
      this.f_97726_ = 149;
      this.f_97727_ = 166;
   }

   public void m_88315_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
      this.m_280273_(guiGraphics);
      super.m_88315_(guiGraphics, mouseX, mouseY, partialTicks);
      this.m_280072_(guiGraphics, mouseX, mouseY);
   }

   protected void m_7286_(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      guiGraphics.m_280163_(texture, this.f_97735_, this.f_97736_, 0.0F, 0.0F, this.f_97726_, this.f_97727_, this.f_97726_, this.f_97727_);
      guiGraphics.m_280163_(
         new ResourceLocation("inside_the_system:textures/screens/0tips.png"), this.f_97735_ + -7, this.f_97736_ + -29, 0.0F, 0.0F, 177, 219, 177, 219
      );
      RenderSystem.disableBlend();
   }

   public boolean m_7933_(int key, int b, int c) {
      if (key == 256) {
         this.f_96541_.f_91074_.m_6915_();
         return true;
      } else {
         return super.m_7933_(key, b, c);
      }
   }

   public void m_181908_() {
      super.m_181908_();
   }

   protected void m_280003_(GuiGraphics guiGraphics, int mouseX, int mouseY) {
   }

   public void m_7379_() {
      super.m_7379_();
   }

   public void m_7856_() {
      super.m_7856_();
      this.imagebutton_exit = new ImageButton(
         this.f_97735_ + 130,
         this.f_97736_ + 172,
         15,
         8,
         0,
         0,
         8,
         new ResourceLocation("inside_the_system:textures/screens/atlas/imagebutton_exit.png"),
         15,
         16,
         e -> {
            InsideTheSystemMod.PACKET_HANDLER.sendToServer(new TipsOpenButtonMessage(0, this.x, this.y, this.z));
            TipsOpenButtonMessage.handleButtonAction(this.entity, 0, this.x, this.y, this.z);
         }
      );
      guistate.put("button:imagebutton_exit", this.imagebutton_exit);
      this.m_142416_(this.imagebutton_exit);
   }
}
