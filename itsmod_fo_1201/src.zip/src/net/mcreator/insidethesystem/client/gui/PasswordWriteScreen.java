package net.mcreator.insidethesystem.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.HashMap;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.PasswordWriteButtonMessage;
import net.mcreator.insidethesystem.world.inventory.PasswordWriteMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class PasswordWriteScreen extends AbstractContainerScreen<PasswordWriteMenu> {
   private static final HashMap<String, Object> guistate = PasswordWriteMenu.guistate;
   private final Level world;
   private final int x;
   private final int y;
   private final int z;
   private final Player entity;
   EditBox Password;
   Button button_empty;
   private static final ResourceLocation texture = new ResourceLocation("inside_the_system:textures/screens/password_write.png");

   public PasswordWriteScreen(PasswordWriteMenu container, Inventory inventory, Component text) {
      super(container, inventory, text);
      this.world = container.world;
      this.x = container.x;
      this.y = container.y;
      this.z = container.z;
      this.entity = container.entity;
      this.f_97726_ = 150;
      this.f_97727_ = 166;
   }

   public void m_88315_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
      this.m_280273_(guiGraphics);
      super.m_88315_(guiGraphics, mouseX, mouseY, partialTicks);
      this.Password.m_88315_(guiGraphics, mouseX, mouseY, partialTicks);
      this.m_280072_(guiGraphics, mouseX, mouseY);
   }

   protected void m_7286_(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      guiGraphics.m_280163_(texture, this.f_97735_, this.f_97736_, 0.0F, 0.0F, this.f_97726_, this.f_97727_, this.f_97726_, this.f_97727_);
      RenderSystem.disableBlend();
   }

   public boolean m_7933_(int key, int b, int c) {
      if (key == 256) {
         this.f_96541_.f_91074_.m_6915_();
         return true;
      } else {
         return this.Password.m_93696_() ? this.Password.m_7933_(key, b, c) : super.m_7933_(key, b, c);
      }
   }

   public void m_181908_() {
      super.m_181908_();
      this.Password.m_94120_();
   }

   protected void m_280003_(GuiGraphics guiGraphics, int mouseX, int mouseY) {
   }

   public void m_7379_() {
      super.m_7379_();
   }

   public void m_7856_() {
      super.m_7856_();
      this.Password = new EditBox(
         this.f_96547_, this.f_97735_ + 15, this.f_97736_ + 60, 120, 20, Component.m_237115_("gui.inside_the_system.password_write.Password")
      ) {
         {
            this.m_94167_(Component.m_237115_("gui.inside_the_system.password_write.Password").getString());
         }

         public void m_94164_(String text) {
            super.m_94164_(text);
            if (this.m_94155_().isEmpty()) {
               this.m_94167_(Component.m_237115_("gui.inside_the_system.password_write.Password").getString());
            } else {
               this.m_94167_(null);
            }
         }

         public void m_94192_(int pos) {
            super.m_94192_(pos);
            if (this.m_94155_().isEmpty()) {
               this.m_94167_(Component.m_237115_("gui.inside_the_system.password_write.Password").getString());
            } else {
               this.m_94167_(null);
            }
         }
      };
      this.Password.m_94199_(32767);
      guistate.put("text:Password", this.Password);
      this.m_7787_(this.Password);
      this.button_empty = Button.m_253074_(Component.m_237115_("gui.inside_the_system.password_write.button_empty"), e -> {
         InsideTheSystemMod.PACKET_HANDLER.sendToServer(new PasswordWriteButtonMessage(0, this.x, this.y, this.z));
         PasswordWriteButtonMessage.handleButtonAction(this.entity, 0, this.x, this.y, this.z);
      }).m_252987_(this.f_97735_ + 60, this.f_97736_ + 95, 25, 20).m_253136_();
      guistate.put("button:button_empty", this.button_empty);
      this.m_142416_(this.button_empty);
   }
}
