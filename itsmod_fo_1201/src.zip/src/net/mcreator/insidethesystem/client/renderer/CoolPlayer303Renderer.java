package net.mcreator.insidethesystem.client.renderer;

import com.mojang.blaze3d.platform.NativeImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import net.mcreator.insidethesystem.entity.CoolPlayer303Entity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.ResourceLocation;

public class CoolPlayer303Renderer extends HumanoidMobRenderer<CoolPlayer303Entity, HumanoidModel<CoolPlayer303Entity>> {
   private static final Path SKINS_DIR = Paths.get("saves", "InsideTheSystemSkins").toAbsolutePath();
   private static final ResourceLocation DEFAULT_SKIN = new ResourceLocation("inside_the_system:textures/entities/default.png");

   public CoolPlayer303Renderer(Context context) {
      super(context, new HumanoidModel(context.m_174023_(ModelLayers.f_171162_)), 0.5F);
      this.m_115326_(
         new HumanoidArmorLayer(
            this, new HumanoidModel(context.m_174023_(ModelLayers.f_171164_)), new HumanoidModel(context.m_174023_(ModelLayers.f_171165_)), context.m_266367_()
         )
      );
   }

   public ResourceLocation getTextureLocation(CoolPlayer303Entity entity) {
      String skinName = entity.getSkinName();
      if (skinName != null && !skinName.isEmpty() && !skinName.equals("default")) {
         ResourceLocation skinLocation = this.loadSkinTexture(skinName);
         return skinLocation != null ? skinLocation : DEFAULT_SKIN;
      } else {
         return DEFAULT_SKIN;
      }
   }

   private ResourceLocation loadSkinTexture(String skinName) {
      File skinFile = SKINS_DIR.resolve(skinName + ".png").toFile();
      if (skinFile.exists() && skinFile.isFile()) {
         try {
            ResourceLocation var8;
            try (InputStream stream = new FileInputStream(skinFile)) {
               TextureManager textureManager = Minecraft.m_91087_().m_91097_();
               ResourceLocation dynamicLoc = new ResourceLocation("inside_the_system", "dynamic_skin_" + skinName);
               if (textureManager.m_174786_(dynamicLoc, null) != null) {
                  return dynamicLoc;
               }

               NativeImage image = NativeImage.m_85058_(stream);
               DynamicTexture dynamicTexture = new DynamicTexture(image);
               textureManager.m_118495_(dynamicLoc, dynamicTexture);
               var8 = dynamicLoc;
            }

            return var8;
         } catch (Exception var11) {
            var11.printStackTrace();
            return null;
         }
      } else {
         return null;
      }
   }
}
