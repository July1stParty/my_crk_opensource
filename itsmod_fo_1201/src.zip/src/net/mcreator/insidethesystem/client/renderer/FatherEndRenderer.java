package net.mcreator.insidethesystem.client.renderer;

import net.mcreator.insidethesystem.entity.FatherEndEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;

public class FatherEndRenderer extends HumanoidMobRenderer<FatherEndEntity, HumanoidModel<FatherEndEntity>> {
   public FatherEndRenderer(Context context) {
      super(context, new HumanoidModel(context.m_174023_(ModelLayers.f_171162_)), 0.5F);
      this.m_115326_(
         new HumanoidArmorLayer(
            this, new HumanoidModel(context.m_174023_(ModelLayers.f_171164_)), new HumanoidModel(context.m_174023_(ModelLayers.f_171165_)), context.m_266367_()
         )
      );
   }

   public ResourceLocation getTextureLocation(FatherEndEntity entity) {
      return new ResourceLocation("inside_the_system:textures/entities/venom.png");
   }
}
