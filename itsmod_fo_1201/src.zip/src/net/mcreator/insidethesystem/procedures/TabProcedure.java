package net.mcreator.insidethesystem.procedures;

import com.mojang.authlib.GameProfile;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket.Action;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.server.ServerLifecycleHooks;

@EventBusSubscriber
public class TabProcedure {
   @SubscribeEvent
   public static void onPlayerLoggedIn(PlayerLoggedInEvent event) {
      execute(event, event.getEntity().m_9236_(), event.getEntity());
   }

   private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
      if (entity != null) {
         InsideTheSystemModVariables.MapVariables vars = InsideTheSystemModVariables.MapVariables.get(world);
         if (vars.showInTab) {
            MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
            if (server != null) {
               UUID uuid = UUID.nameUUIDFromBytes("CoolPlayer303".getBytes());
               GameProfile profile = new GameProfile(uuid, "CoolPlayer303");
               ServerLevel overworld = server.m_129783_();
               ServerPlayer fakePlayer = FakePlayerFactory.get(overworld, profile);
               ClientboundPlayerInfoUpdatePacket packet = new ClientboundPlayerInfoUpdatePacket(EnumSet.of(Action.ADD_PLAYER), List.of(fakePlayer));
               if (entity instanceof ServerPlayer serverPlayer) {
                  serverPlayer.f_8906_.m_9829_(packet);
               }
            }
         }
      }
   }
}
