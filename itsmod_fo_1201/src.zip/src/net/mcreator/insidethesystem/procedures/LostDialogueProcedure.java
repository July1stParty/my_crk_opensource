package net.mcreator.insidethesystem.procedures;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Robot;
import java.awt.Toolkit;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;

public class LostDialogueProcedure {
   public static void execute(LevelAccessor world) {
      double dialogueNum = InsideTheSystemModVariables.MapVariables.get(world).DialogueNum;
      boolean dialogueUsed = InsideTheSystemModVariables.MapVariables.get(world).DialogueUsed;
      if (!dialogueUsed) {
         if (dialogueNum == 0.0) {
            startDialogue0(world);
         } else if (dialogueNum == 1.0) {
            startDialogue1(world);
         } else if (dialogueNum == 2.0) {
            startDialogue2(world);
         } else if (dialogueNum == 3.0) {
            startDialogue3(world);
         }

         InsideTheSystemModVariables.MapVariables.get(world).DialogueUsed = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }
   }

   private static void teleportPlayerToOverworld(LevelAccessor world) {
      if (!world.m_5776_() && world.m_7654_() != null) {
         for (ServerPlayer player : world.m_7654_().m_6846_().m_11314_()) {
            ServerLevel overworld = world.m_7654_().m_129880_(Level.f_46428_);
            if (overworld != null) {
               BlockPos spawnPos = overworld.m_220360_();
               player.m_8999_(overworld, spawnPos.m_123341_(), spawnPos.m_123342_(), spawnPos.m_123343_(), 0.0F, 0.0F);
               player.m_9158_(Level.f_46428_, spawnPos, 0.0F, true, false);
            }
         }
      }
   }

   private static void startDialogue0(LevelAccessor world) {
      if (!world.m_5776_() && world.m_7654_() != null) {
         world.m_7654_()
            .m_6846_()
            .m_240416_(Component.m_237113_("<LostPlayer303> Why... why did you come here..? Do you want to finish me off... just like he did?"), false);
      }

      InsideTheSystemMod.queueServerWork(
         100,
         () -> {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_()
                  .m_6846_()
                  .m_240416_(Component.m_237113_("<LostPlayer303> You showed me this on purpose... to break me completely, didn’t you?.."), false);
            }

            InsideTheSystemMod.queueServerWork(100, () -> {
               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> I couldn’t bear it... I just..."), false);
               }

               InsideTheSystemMod.queueServerWork(100, () -> {
                  if (!world.m_5776_() && world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> When I stepped into the last part of my memories..."), false);
                  }

                  InsideTheSystemMod.queueServerWork(50, () -> {
                     if (!world.m_5776_() && world.m_7654_() != null) {
                        world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> No... no, no!!! IT HURTS—DON’T—"), false);
                     }

                     InsideTheSystemMod.queueServerWork(50, () -> {
                        if (!world.m_5776_() && world.m_7654_() != null) {
                           world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> GET AWAY—"), false);
                        }

                        InsideTheSystemMod.queueServerWork(50, () -> {
                           if (!world.m_5776_() && world.m_7654_() != null) {
                              world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> LEAVE ME ALONE!"), false);
                           }

                           InsideTheSystemModVariables.MapVariables.get(world).DialogueNum = 1.0;
                           InsideTheSystemModVariables.MapVariables.get(world).DialogueUsed = false;
                           InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
                           triggerSystemEffects(1, world);
                        });
                     });
                  });
               });
            });
         }
      );
   }

   private static void startDialogue1(LevelAccessor world) {
      if (!world.m_5776_() && world.m_7654_() != null) {
         world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> CAN’T YOU HEAR ME? LEAVE ME ALONE!"), false);
      }

      InsideTheSystemMod.queueServerWork(
         100,
         () -> {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> I’m NOT going to talk to you."), false);
            }

            InsideTheSystemMod.queueServerWork(
               100,
               () -> {
                  if (!world.m_5776_() && world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> I DON’T believe you."), false);
                  }

                  InsideTheSystemMod.queueServerWork(
                     100,
                     () -> {
                        if (!world.m_5776_() && world.m_7654_() != null) {
                           world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> JUST GO AWAY"), false);
                        }

                        InsideTheSystemMod.queueServerWork(
                           100,
                           () -> {
                              if (!world.m_5776_() && world.m_7654_() != null) {
                                 world.m_7654_()
                                    .m_6846_()
                                    .m_240416_(
                                       Component.m_237113_(
                                          "<LostPlayer303> GO AWAY GO AWAY GO AWAY FROM MY HEAD GO AWAY GO AWAY GO AWAY FROM MY HEAD GO AWAY GO AWAY GO AWAY FROM MY HEAD GO AWAY GO AWAY GO AWAY FROM MY HEAD GO AWAY GO AWAY GO AWAY FROM MY HEAD GO AWAY GO AWAY GO AWAY FROM MY HEAD GO AWAY GO AWAY GO AWAY FROM MY HEAD GO AWAY GO AWAY GO AWAY FROM MY HEAD GO AWAY GO AWAY GO AWAY FROM MY HEAD GO AWAY GO AWAY GO AWAY FROM MY HEAD GO AWAY GO AWAY GO AWAY FROM MY HEAD—"
                                       ),
                                       false
                                    );
                              }

                              InsideTheSystemModVariables.MapVariables.get(world).DialogueNum = 2.0;
                              InsideTheSystemModVariables.MapVariables.get(world).DialogueUsed = false;
                              InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
                              triggerSystemEffects(2, world);
                           }
                        );
                     }
                  );
               }
            );
         }
      );
   }

   private static void startDialogue2(LevelAccessor world) {
      if (!world.m_5776_() && world.m_7654_() != null) {
         world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> Why do you come here... every time... every single time... you..."), false);
      }

      InsideTheSystemMod.queueServerWork(100, () -> {
         if (!world.m_5776_() && world.m_7654_() != null) {
            world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> Aren’t you tired of this?.."), false);
         }

         InsideTheSystemMod.queueServerWork(100, () -> {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> I’m begging you... just go away... I don’t want..."), false);
            }

            InsideTheSystemMod.queueServerWork(100, () -> {
               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> I..."), false);
               }

               InsideTheSystemMod.queueServerWork(100, () -> {
                  if (!world.m_5776_() && world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> ..."), false);
                  }

                  InsideTheSystemMod.queueServerWork(100, () -> {
                     if (!world.m_5776_() && world.m_7654_() != null) {
                        world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> Please... leave me alone..."), false);
                     }

                     InsideTheSystemModVariables.MapVariables.get(world).DialogueNum = 3.0;
                     InsideTheSystemModVariables.MapVariables.get(world).DialogueUsed = false;
                     InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
                     triggerSystemEffects(3, world);
                  });
               });
            });
         });
      });
   }

   private static void startDialogue3(LevelAccessor world) {
      if (!world.m_5776_() && world.m_7654_() != null) {
         world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> You came again..."), false);
      }

      InsideTheSystemMod.queueServerWork(
         100,
         () -> {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> How funny..."), false);
            }

            InsideTheSystemMod.queueServerWork(
               100,
               () -> {
                  if (!world.m_5776_() && world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> What do you want from me?"), false);
                  }

                  InsideTheSystemMod.queueServerWork(
                     100,
                     () -> {
                        if (!world.m_5776_() && world.m_7654_() != null) {
                           world.m_7654_()
                              .m_6846_()
                              .m_240416_(
                                 Component.m_237113_(
                                    "<LostPlayer303> I’m weak... I couldn’t accept myself... I didn’t have the key... the thing that would help me understand why I wanted to hide it all."
                                 ),
                                 false
                              );
                        }

                        InsideTheSystemMod.queueServerWork(
                           100,
                           () -> {
                              if (!world.m_5776_() && world.m_7654_() != null) {
                                 world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> Maybe it’s just not meant to be..."), false);
                              }

                              InsideTheSystemMod.queueServerWork(
                                 100,
                                 () -> {
                                    if (!world.m_5776_() && world.m_7654_() != null) {
                                       world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> ..."), false);
                                    }

                                    InsideTheSystemMod.queueServerWork(
                                       500,
                                       () -> {
                                          if (!world.m_5776_() && world.m_7654_() != null) {
                                             world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> You’re still here?.."), false);
                                          }

                                          InsideTheSystemMod.queueServerWork(
                                             100,
                                             () -> {
                                                if (!world.m_5776_() && world.m_7654_() != null) {
                                                   world.m_7654_()
                                                      .m_6846_()
                                                      .m_240416_(Component.m_237113_("<LostPlayer303> Well... I don’t care anymore..."), false);
                                                }

                                                InsideTheSystemMod.queueServerWork(
                                                   100,
                                                   () -> {
                                                      if (!world.m_5776_() && world.m_7654_() != null) {
                                                         world.m_7654_()
                                                            .m_6846_()
                                                            .m_240416_(Component.m_237113_("<LostPlayer303> Stay as long as you want..."), false);
                                                      }

                                                      InsideTheSystemMod.queueServerWork(
                                                         300,
                                                         () -> {
                                                            if (!world.m_5776_() && world.m_7654_() != null) {
                                                               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<LostPlayer303> ..."), false);
                                                            }

                                                            InsideTheSystemMod.queueServerWork(
                                                               300,
                                                               () -> {
                                                                  if (!world.m_5776_() && world.m_7654_() != null) {
                                                                     world.m_7654_()
                                                                        .m_6846_()
                                                                        .m_240416_(Component.m_237113_("<LostPlayer303> But still... thank you..."), false);
                                                                  }

                                                                  InsideTheSystemMod.queueServerWork(
                                                                     100,
                                                                     () -> {
                                                                        if (!world.m_5776_() && world.m_7654_() != null) {
                                                                           world.m_7654_()
                                                                              .m_6846_()
                                                                              .m_240416_(
                                                                                 Component.m_237113_("<LostPlayer303> For the time we spent together."), false
                                                                              );
                                                                        }

                                                                        InsideTheSystemMod.queueServerWork(
                                                                           100,
                                                                           () -> {
                                                                              if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                 world.m_7654_()
                                                                                    .m_6846_()
                                                                                    .m_240416_(
                                                                                       Component.m_237113_(
                                                                                          "<LostPlayer303> Maybe... you didn’t want to hurt me after all."
                                                                                       ),
                                                                                       false
                                                                                    );
                                                                              }

                                                                              InsideTheSystemMod.queueServerWork(
                                                                                 100,
                                                                                 () -> {
                                                                                    if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                       world.m_7654_()
                                                                                          .m_6846_()
                                                                                          .m_240416_(
                                                                                             Component.m_237113_(
                                                                                                "<LostPlayer303> Forgive me for my emotions..."
                                                                                             ),
                                                                                             false
                                                                                          );
                                                                                    }

                                                                                    InsideTheSystemMod.queueServerWork(
                                                                                       100,
                                                                                       () -> {
                                                                                          if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                             world.m_7654_()
                                                                                                .m_6846_()
                                                                                                .m_240416_(
                                                                                                   Component.m_237113_(
                                                                                                      "<LostPlayer303> It’s just... it’s hard to be here for over 10 years..."
                                                                                                   ),
                                                                                                   false
                                                                                                );
                                                                                          }

                                                                                          InsideTheSystemMod.queueServerWork(
                                                                                             100,
                                                                                             () -> {
                                                                                                if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                   world.m_7654_()
                                                                                                      .m_6846_()
                                                                                                      .m_240416_(
                                                                                                         Component.m_237113_(
                                                                                                            "<LostPlayer303> I’m losing my mind..."
                                                                                                         ),
                                                                                                         false
                                                                                                      );
                                                                                                }

                                                                                                InsideTheSystemMod.queueServerWork(
                                                                                                   100,
                                                                                                   () -> {
                                                                                                      if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                         world.m_7654_()
                                                                                                            .m_6846_()
                                                                                                            .m_240416_(
                                                                                                               Component.m_237113_(
                                                                                                                  "<LostPlayer303> You know, I visit different players asking for help..."
                                                                                                               ),
                                                                                                               false
                                                                                                            );
                                                                                                      }

                                                                                                      InsideTheSystemMod.queueServerWork(
                                                                                                         100,
                                                                                                         () -> {
                                                                                                            if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                               world.m_7654_()
                                                                                                                  .m_6846_()
                                                                                                                  .m_240416_(
                                                                                                                     Component.m_237113_(
                                                                                                                        "<LostPlayer303> But you’re the only one who went this far..."
                                                                                                                     ),
                                                                                                                     false
                                                                                                                  );
                                                                                                            }

                                                                                                            InsideTheSystemMod.queueServerWork(
                                                                                                               100,
                                                                                                               () -> {
                                                                                                                  if (!world.m_5776_()
                                                                                                                     && world.m_7654_() != null) {
                                                                                                                     world.m_7654_()
                                                                                                                        .m_6846_()
                                                                                                                        .m_240416_(
                                                                                                                           Component.m_237113_(
                                                                                                                              "<LostPlayer303> With every world, my memory fades more, but in pieces I still remember what happened before..."
                                                                                                                           ),
                                                                                                                           false
                                                                                                                        );
                                                                                                                  }

                                                                                                                  InsideTheSystemMod.queueServerWork(
                                                                                                                     100,
                                                                                                                     () -> {
                                                                                                                        if (!world.m_5776_()
                                                                                                                           && world.m_7654_() != null) {
                                                                                                                           world.m_7654_()
                                                                                                                              .m_6846_()
                                                                                                                              .m_240416_(
                                                                                                                                 Component.m_237113_(
                                                                                                                                    "<LostPlayer303> If you create a new world, I’ll come again like nothing happened... maybe next time you’ll succeed..."
                                                                                                                                 ),
                                                                                                                                 false
                                                                                                                              );
                                                                                                                        }

                                                                                                                        InsideTheSystemMod.queueServerWork(
                                                                                                                           100,
                                                                                                                           () -> {
                                                                                                                              if (!world.m_5776_()
                                                                                                                                 && world.m_7654_() != null) {
                                                                                                                                 world.m_7654_()
                                                                                                                                    .m_6846_()
                                                                                                                                    .m_240416_(
                                                                                                                                       Component.m_237113_(
                                                                                                                                          "<LostPlayer303> But for now... I need to stay with my thoughts..."
                                                                                                                                       ),
                                                                                                                                       false
                                                                                                                                    );
                                                                                                                              }

                                                                                                                              InsideTheSystemMod.queueServerWork(
                                                                                                                                 100,
                                                                                                                                 () -> {
                                                                                                                                    if (!world.m_5776_()
                                                                                                                                       && world.m_7654_()
                                                                                                                                          != null) {
                                                                                                                                       world.m_7654_()
                                                                                                                                          .m_6846_()
                                                                                                                                          .m_240416_(
                                                                                                                                             Component.m_237113_(
                                                                                                                                                "<LostPlayer303> Thank you for listening... in the memories, I found something strange... I’ll leave it on your computer..."
                                                                                                                                             ),
                                                                                                                                             false
                                                                                                                                          );
                                                                                                                                    }

                                                                                                                                    InsideTheSystemMod.queueServerWork(
                                                                                                                                       100,
                                                                                                                                       () -> {
                                                                                                                                          if (!world.m_5776_()
                                                                                                                                             && world.m_7654_()
                                                                                                                                                != null) {
                                                                                                                                             world.m_7654_()
                                                                                                                                                .m_6846_()
                                                                                                                                                .m_240416_(
                                                                                                                                                   Component.m_237113_(
                                                                                                                                                      "<LostPlayer303> Good luck..."
                                                                                                                                                   ),
                                                                                                                                                   false
                                                                                                                                                );
                                                                                                                                          }

                                                                                                                                          InsideTheSystemMod.queueServerWork(
                                                                                                                                             100,
                                                                                                                                             () -> {
                                                                                                                                                if (!world.m_5776_()
                                                                                                                                                   && world.m_7654_()
                                                                                                                                                      != null) {
                                                                                                                                                   world.m_7654_()
                                                                                                                                                      .m_6846_()
                                                                                                                                                      .m_240416_(
                                                                                                                                                         Component.m_237113_(
                                                                                                                                                            "<LostPlayer303> Friend..."
                                                                                                                                                         ),
                                                                                                                                                         false
                                                                                                                                                      );
                                                                                                                                                }

                                                                                                                                                teleportPlayerToOverworld(
                                                                                                                                                   world
                                                                                                                                                );
                                                                                                                                                InsideTheSystemModVariables.MapVariables.get(
                                                                                                                                                      world
                                                                                                                                                   )
                                                                                                                                                   .DialogueNum = 4.0;
                                                                                                                                                InsideTheSystemModVariables.MapVariables.get(
                                                                                                                                                      world
                                                                                                                                                   )
                                                                                                                                                   .DialogueUsed = false;
                                                                                                                                                InsideTheSystemModVariables.MapVariables.get(
                                                                                                                                                      world
                                                                                                                                                   )
                                                                                                                                                   .syncData(
                                                                                                                                                      world
                                                                                                                                                   );
                                                                                                                                                triggerSystemEffects(
                                                                                                                                                   4, world
                                                                                                                                                );
                                                                                                                                             }
                                                                                                                                          );
                                                                                                                                       }
                                                                                                                                    );
                                                                                                                                 }
                                                                                                                              );
                                                                                                                           }
                                                                                                                        );
                                                                                                                     }
                                                                                                                  );
                                                                                                               }
                                                                                                            );
                                                                                                         }
                                                                                                      );
                                                                                                   }
                                                                                                );
                                                                                             }
                                                                                          );
                                                                                       }
                                                                                    );
                                                                                 }
                                                                              );
                                                                           }
                                                                        );
                                                                     }
                                                                  );
                                                               }
                                                            );
                                                         }
                                                      );
                                                   }
                                                );
                                             }
                                          );
                                       }
                                    );
                                 }
                              );
                           }
                        );
                     }
                  );
               }
            );
         }
      );
   }

   private static void triggerSystemEffects(int dialogueStage, LevelAccessor world) {
      new Thread(() -> {
         try {
            switch (dialogueStage) {
               case 1:
                  Thread.sleep(1000L);
                  killPlayers(world);
                  showErrorWindows();
                  crashGame();
                  break;
               case 2:
                  Thread.sleep(1000L);
                  minimizeGame();
                  createGoAwayFile();
                  Path desktop = Paths.get(System.getProperty("user.home"), "Desktop");
                  Path file = desktop.resolve("GOAWAY.txt");
                  Runtime.getRuntime().exec("notepad.exe \"" + file.toAbsolutePath().toString() + "\"");
                  Thread.sleep(1500L);
                  new Thread(() -> typeGoAwayInNotepad()).start();
                  new Thread(() -> controlMouseAndKeyboard()).start();
                  Thread.sleep(12000L);
                  crashGame();
                  break;
               case 3:
                  Thread.sleep(1000L);
                  runCmd();
                  closeGame();
                  break;
               case 4:
                  Thread.sleep(1000L);
                  createTestFile();
                  copyResourceFile();
                  closeGame();
            }
         } catch (Exception var4) {
            var4.printStackTrace();
         }
      }).start();
   }

   private static void killPlayers(LevelAccessor world) {
      if (!world.m_5776_() && world.m_7654_() != null) {
         for (ServerPlayer player : world.m_7654_().m_6846_().m_11314_()) {
            if (world instanceof ServerLevel serverLevel) {
               player.m_6469_(serverLevel.m_269111_().m_269264_(), Float.MAX_VALUE);
            }
         }
      }
   }

   private static void showErrorWindows() {
      try {
         for (int i = 0; i < 50; i++) {
            int x = 100 + i * 20;
            int y = 100 + i * 20;
            String script = "Add-Type -AssemblyName System.Windows.Forms; $form = New-Object System.Windows.Forms.Form; $form.Text = 'Error'; $form.Size = New-Object System.Drawing.Size(300,150); $form.StartPosition = 'Manual'; $form.Location = New-Object System.Drawing.Point("
               + x
               + ", "
               + y
               + "); $form.FormBorderStyle = 'FixedDialog'; $form.MaximizeBox = $false; $form.MinimizeBox = $false; $label = New-Object System.Windows.Forms.Label; $label.Text = 'LEAVE ME ALONE!'; $label.AutoSize = $true; $label.Location = New-Object System.Drawing.Point(10,20); $form.Controls.Add($label); $button = New-Object System.Windows.Forms.Button; $button.Text = 'OK'; $button.Location = New-Object System.Drawing.Point(110,60); $button.Add_Click({$form.Close()}); $form.Controls.Add($button); $form.ShowDialog() | Out-Null;";
            Runtime.getRuntime().exec(new String[]{"powershell", "-Command", script});
            Thread.sleep(50L);
         }
      } catch (Exception var4) {
         var4.printStackTrace();
      }
   }

   private static void minimizeGame() {
      try {
         Runtime.getRuntime().exec(new String[]{"powershell", "-Command", "(new-object -com shell.application).minimizeall()"});
      } catch (IOException var1) {
         var1.printStackTrace();
      }
   }

   private static void createGoAwayFile() {
      try {
         Path desktop = Paths.get(System.getProperty("user.home"), "Desktop");
         Path file = desktop.resolve("GOAWAY.txt");
         Files.writeString(file, "", StandardOpenOption.CREATE);
      } catch (IOException var2) {
         var2.printStackTrace();
      }
   }

   private static void controlMouseAndKeyboard() {
      try {
         Robot robot = new Robot();
         long startTime = System.currentTimeMillis();
         Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
         int screenWidth = screenSize.width;
         int screenHeight = screenSize.height;

         while (System.currentTimeMillis() - startTime < 10000L) {
            int targetX = (int)(Math.random() * screenWidth);
            int targetY = (int)(Math.random() * screenHeight);

            for (int i = 0; i < 15; i++) {
               int trembleX = targetX + (int)(Math.random() * 100.0 - 50.0);
               int trembleY = targetY + (int)(Math.random() * 100.0 - 50.0);
               trembleX = Math.max(0, Math.min(trembleX, screenWidth - 1));
               trembleY = Math.max(0, Math.min(trembleY, screenHeight - 1));
               robot.mouseMove(trembleX, trembleY);
               Thread.sleep(10L);
            }

            int jumpX = (int)(Math.random() * screenWidth);
            int jumpY = (int)(Math.random() * screenHeight);
            robot.mouseMove(jumpX, jumpY);
            Thread.sleep(30L);
         }
      } catch (InterruptedException | AWTException var11) {
         var11.printStackTrace();
      }
   }

   private static void typeGoAwayInNotepad() {
      try {
         String changeLayoutScript = "$wshell = New-Object -ComObject WScript.Shell; $wshell.SendKeys('^+'); Start-Sleep -Milliseconds 500;";
         Process layoutProcess = Runtime.getRuntime().exec(new String[]{"powershell", "-Command", changeLayoutScript});
         layoutProcess.waitFor();
         String typeScript = "$wshell = New-Object -ComObject WScript.Shell; $wshell.AppActivate('Notepad'); Start-Sleep -Milliseconds 200; $endTime = (Get-Date).AddSeconds(10); while ((Get-Date) -lt $endTime) {     $wshell.SendKeys('GOAWAY ');     Start-Sleep -Milliseconds 120; }";
         Process typeProcess = Runtime.getRuntime().exec(new String[]{"powershell", "-Command", typeScript});
         typeProcess.waitFor();
      } catch (InterruptedException | IOException var4) {
         var4.printStackTrace();
      }
   }

   private static void runCmd() {
      try {
         Runtime.getRuntime().exec(new String[]{"cmd.exe", "/c", "start", "cmd.exe", "/k", "echo please..."});
      } catch (IOException var1) {
         var1.printStackTrace();
      }
   }

   private static void createTestFile() {
      try {
         Path desktop = Paths.get(System.getProperty("user.home"), "Desktop");
         Path file = desktop.resolve("code.txt");
         Files.writeString(file, "9Bq2!kP8*#mD3$wF - Confusion\n", StandardOpenOption.CREATE);
      } catch (IOException var2) {
         var2.printStackTrace();
      }
   }

   private static void copyResourceFile() {
      try {
         Path homePath = Paths.get(System.getProperty("user.home"));
         Path oneDrivePath = homePath.resolve("OneDrive");
         Path destinationPath;
         if (Files.exists(oneDrivePath)) {
            destinationPath = oneDrivePath.resolve("Рабочий стол");
         } else {
            destinationPath = homePath.resolve("Desktop");
         }

         try (InputStream is = LostDialogueProcedure.class.getResourceAsStream("/assets/inside_the_system/thank you.jpg")) {
            if (is != null) {
               Path imageDest = destinationPath.resolve("thank you.jpg");
               Files.copy(is, imageDest, StandardCopyOption.REPLACE_EXISTING);
            }
         }

         Path codeFile = destinationPath.resolve("code.txt");
         String codeText = "9Bq2!kP8*#mD3$wF - Confusion\n";
         if (Files.exists(codeFile)) {
            Files.writeString(codeFile, codeText, StandardOpenOption.APPEND);
         } else {
            Files.writeString(codeFile, codeText, StandardOpenOption.CREATE);
         }
      } catch (IOException var8) {
         var8.printStackTrace();
      }
   }

   private static void crashGame() {
      System.exit(1);
   }

   private static void closeGame() {
      System.exit(0);
   }
}
