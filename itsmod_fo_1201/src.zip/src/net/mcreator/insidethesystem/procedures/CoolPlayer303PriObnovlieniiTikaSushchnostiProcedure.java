package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.LevelAccessor;

public class CoolPlayer303PriObnovlieniiTikaSushchnostiProcedure {
   private static final double FOLLOW_RADIUS = 7.0;

   public static void execute(LevelAccessor world, Entity entity) {
      if (entity != null) {
         entity.m_6593_(Component.m_237113_("CoolPlayer303"));
         entity.m_20340_(true);
         String targetSkin = InsideTheSystemModVariables.MapVariables.get(world).CoolPlayer303Skin;
         if (targetSkin != null && !targetSkin.isEmpty()) {
            entity.getPersistentData().m_128359_("CoolPlayer303Skin", targetSkin);
         }

         double playerX = InsideTheSystemModVariables.MapVariables.get(world).PlayerX;
         double playerY = InsideTheSystemModVariables.MapVariables.get(world).PlayerY;
         double playerZ = InsideTheSystemModVariables.MapVariables.get(world).PlayerZ;
         if (InsideTheSystemModVariables.MapVariables.get(world).follow && entity instanceof Mob _mob) {
            double dx = playerX - _mob.m_20185_();
            double dz = playerZ - _mob.m_20189_();
            double distanceSq = dx * dx + dz * dz;
            if (distanceSq > 49.0) {
               _mob.m_21573_().m_26519_(playerX, playerY, playerZ, 1.0);
            } else {
               _mob.m_21573_().m_26573_();
            }
         }

         if (InsideTheSystemModVariables.MapVariables.get(world).Angry && !entity.m_9236_().m_5776_()) {
            entity.m_146870_();
         }
      }
   }
}
