package net.mcreator.insidethesystem.procedures;

import io.netty.buffer.Unpooled;
import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.mcreator.insidethesystem.world.inventory.WarningMenu;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.registries.ForgeRegistries;

@EventBusSubscriber
public class IfPlayerJoinProcedure {
   @SubscribeEvent
   public static void onPlayerLoggedIn(PlayerLoggedInEvent event) {
      execute(event, event.getEntity().m_9236_(), event.getEntity().m_20185_(), event.getEntity().m_20186_(), event.getEntity().m_20189_(), event.getEntity());
   }

   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      execute(null, world, x, y, z, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         InsideTheSystemModVariables.MapVariables.get(world).Colljoin = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).Inworld = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).BlockCommands = false;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).TimerBuild = 100.0;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).Angrybuild = 0.0;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).build = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).builderSpawnTimer = 32000.0;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).summon = false;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         if (InsideTheSystemModVariables.MapVariables.get(world).WorldDied < 192000.0) {
            InsideTheSystemModVariables.MapVariables.get(world).WorldDied = InsideTheSystemModVariables.MapVariables.get(world).worldDiedTemp;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }

         if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife < 600000.0) {
            InsideTheSystemModVariables.MapVariables.get(world).WorldLife = InsideTheSystemModVariables.MapVariables.get(world).WorldLifeTemp;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }

         if (InsideTheSystemModVariables.MapVariables.get(world).WorldDied == 0.0) {
            InsideTheSystemModVariables.MapVariables.get(world).WorldDied = 192000.0;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }

         if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife == 0.0) {
            InsideTheSystemModVariables.MapVariables.get(world).WorldLife = 600000.0;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }

         if (InsideTheSystemModVariables.MapVariables.get(world).eventfollover) {
            InsideTheSystemModVariables.MapVariables.get(world).followerdied = 1690.0;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }

         if (InsideTheSystemModVariables.MapVariables.get(world).Disc) {
            if (entity instanceof ServerPlayer _ent) {
               final BlockPos _bpos = BlockPos.m_274561_(x, y, z);
               NetworkHooks.openScreen(_ent, new MenuProvider() {
                  public Component m_5446_() {
                     return Component.m_237113_("Warning");
                  }

                  public AbstractContainerMenu m_7208_(int id, Inventory inventory, Player player) {
                     return new WarningMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).m_130064_(_bpos));
                  }
               }, _bpos);
            }

            InsideTheSystemModVariables.MapVariables.get(world).Disc = false;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }

         if (entity.m_9236_().m_46472_() == ResourceKey.m_135785_(Registries.f_256858_, new ResourceLocation("inside_the_system:password"))) {
            if (world instanceof ServerLevel _level) {
               _level.m_7654_()
                  .m_129892_()
                  .m_230957_(
                     new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                        )
                        .m_81324_(),
                     "/title @a times 20 60 20"
                  );
            }

            if (world instanceof ServerLevel _level) {
               _level.m_7654_()
                  .m_129892_()
                  .m_230957_(
                     new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                        )
                        .m_81324_(),
                     "/title @a subtitle {\"text\":\"Closed answers\",\"italic\":true,\"color\":\"#DADADA\"}"
                  );
            }

            if (world instanceof ServerLevel _level) {
               _level.m_7654_()
                  .m_129892_()
                  .m_230957_(
                     new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                        )
                        .m_81324_(),
                     "/title @a title {\"text\":\"ACT IV\"}"
                  );
            }
         }

         if (InsideTheSystemModVariables.MapVariables.get(world).DialogueNum == 4.0) {
            if (world instanceof Level _level) {
               if (!_level.m_5776_()) {
                  _level.m_5594_(
                     null,
                     BlockPos.m_274561_(x, y, z),
                     (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:endingd")),
                     SoundSource.NEUTRAL,
                     1.0F,
                     1.0F
                  );
               } else {
                  _level.m_7785_(
                     x,
                     y,
                     z,
                     (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:endingd")),
                     SoundSource.NEUTRAL,
                     1.0F,
                     1.0F,
                     false
                  );
               }
            }

            if (world instanceof ServerLevel _levelx) {
               _levelx.m_7654_()
                  .m_129892_()
                  .m_230957_(
                     new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _levelx, 4, "", Component.m_237113_(""), _levelx.m_7654_(), null
                        )
                        .m_81324_(),
                     "/title @a times 20 60 20"
                  );
            }

            if (world instanceof ServerLevel _levelx) {
               _levelx.m_7654_()
                  .m_129892_()
                  .m_230957_(
                     new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _levelx, 4, "", Component.m_237113_(""), _levelx.m_7654_(), null
                        )
                        .m_81324_(),
                     "/title @a subtitle {\"text\":\"Mental confusion\",\"italic\":true,\"color\":\"#DADADA\"}"
                  );
            }

            if (world instanceof ServerLevel _levelx) {
               _levelx.m_7654_()
                  .m_129892_()
                  .m_230957_(
                     new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _levelx, 4, "", Component.m_237113_(""), _levelx.m_7654_(), null
                        )
                        .m_81324_(),
                     "/title @a title {\"text\":\"Ending D\"}"
                  );
            }

            InsideTheSystemModVariables.MapVariables.get(world).DialogueNum = 20.0;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }

         if (!InsideTheSystemModVariables.MapVariables.get(world).Note) {
            InsideTheSystemMod.queueServerWork(5000, () -> {
               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> If you want, you can poke me, hehe, and I'll wait here"), false);
               }

               InsideTheSystemModVariables.MapVariables.get(world).Note = true;
               InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            });
         }

         InsideTheSystemMod.queueServerWork(100, () -> {
            InsideTheSystemModVariables.MapVariables.get(world).TimerN = 30000.0;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         });
         if (InsideTheSystemModVariables.MapVariables.get(world).EndingDtext) {
            if (world instanceof ServerLevel _levelx) {
               _levelx.m_7654_()
                  .m_129892_()
                  .m_230957_(
                     new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _levelx, 4, "", Component.m_237113_(""), _levelx.m_7654_(), null
                        )
                        .m_81324_(),
                     "/title @a times 20 60 20"
                  );
            }

            if (world instanceof ServerLevel _levelx) {
               _levelx.m_7654_()
                  .m_129892_()
                  .m_230957_(
                     new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _levelx, 4, "", Component.m_237113_(""), _levelx.m_7654_(), null
                        )
                        .m_81324_(),
                     "/title @a title {\"text\":\"Ending D\"}"
                  );
            }

            if (world instanceof ServerLevel _levelx) {
               _levelx.m_7654_()
                  .m_129892_()
                  .m_230957_(
                     new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _levelx, 4, "", Component.m_237113_(""), _levelx.m_7654_(), null
                        )
                        .m_81324_(),
                     "/title @a subtitle {\"text\":\"Mental confusion\",\"italic\":true,\"color\":\"#DADADA\"}"
                  );
            }

            InsideTheSystemModVariables.MapVariables.get(world).EndingDtext = false;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }
      }
   }
}
