package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class OnPlayerJoinProcedure {
   @SubscribeEvent
   public static void onPlayerLoggedIn(PlayerLoggedInEvent event) {
      execute(event, event.getEntity().m_9236_(), event.getEntity());
   }

   private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
      if (entity != null) {
         InsideTheSystemModVariables.MapVariables vars = InsideTheSystemModVariables.MapVariables.get(world);
         if (!vars.timerStarted) {
            vars.TimerJoin = 7000.0;
            vars.timerStarted = true;
            vars.TimerEnd = false;
            vars.Colljoin = true;
            vars.PlayerX = entity.m_20185_();
            vars.PlayerY = entity.m_20186_();
            vars.PlayerZ = entity.m_20189_();
            vars.syncData(world);
         }
      }
   }
}
