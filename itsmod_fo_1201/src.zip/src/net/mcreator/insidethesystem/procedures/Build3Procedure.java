package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.init.InsideTheSystemModEntities;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.registries.ForgeRegistries;

@EventBusSubscriber
public class Build3Procedure {
   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player.m_20185_(), event.player.m_20186_(), event.player.m_20189_(), event.player);
      }
   }

   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      execute(null, world, x, y, z, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (InsideTheSystemModVariables.MapVariables.get(world).story2) {
            InsideTheSystemModVariables.MapVariables.get(world).story2 = false;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemMod.queueServerWork(
               20,
               () -> {
                  if (world instanceof Level _level) {
                     if (!_level.m_5776_()) {
                        _level.m_5594_(
                           null,
                           BlockPos.m_274561_(x, y, z),
                           (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                           SoundSource.NEUTRAL,
                           1.0F,
                           1.0F
                        );
                     } else {
                        _level.m_7785_(
                           x,
                           y,
                           z,
                           (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                           SoundSource.NEUTRAL,
                           1.0F,
                           1.0F,
                           false
                        );
                     }
                  }

                  if (world instanceof ServerLevel _levelx) {
                     _levelx.m_7654_()
                        .m_129892_()
                        .m_230957_(
                           new CommandSourceStack(
                                 CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _levelx, 4, "", Component.m_237113_(""), _levelx.m_7654_(), null
                              )
                              .m_81324_(),
                           "/setblock 7 10 55 inside_the_system:base"
                        );
                  }

                  if (world instanceof ServerLevel _levelx) {
                     _levelx.m_8767_(ParticleTypes.f_123746_, x, y, z, 5, 7.0, 10.0, 22.0, 1.0);
                  }

                  InsideTheSystemMod.queueServerWork(
                     20,
                     () -> {
                        if (world instanceof Level _levelxxx) {
                           if (!_levelxxx.m_5776_()) {
                              _levelxxx.m_5594_(
                                 null,
                                 BlockPos.m_274561_(x, y, z),
                                 (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                 SoundSource.NEUTRAL,
                                 1.0F,
                                 1.0F
                              );
                           } else {
                              _levelxxx.m_7785_(
                                 x,
                                 y,
                                 z,
                                 (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                 SoundSource.NEUTRAL,
                                 1.0F,
                                 1.0F,
                                 false
                              );
                           }
                        }

                        if (world instanceof ServerLevel _levelx) {
                           _levelx.m_7654_()
                              .m_129892_()
                              .m_230957_(
                                 new CommandSourceStack(
                                       CommandSource.f_80164_,
                                       new Vec3(x, y, z),
                                       Vec2.f_82462_,
                                       _levelx,
                                       4,
                                       "",
                                       Component.m_237113_(""),
                                       _levelx.m_7654_(),
                                       null
                                    )
                                    .m_81324_(),
                                 "/setblock 7 10 56 inside_the_system:base"
                              );
                        }

                        if (world instanceof ServerLevel _levelx) {
                           _levelx.m_8767_(ParticleTypes.f_123746_, x, y, z, 5, 7.0, 10.0, 23.0, 1.0);
                        }

                        InsideTheSystemMod.queueServerWork(
                           20,
                           () -> {
                              if (world instanceof Level _levelxxxxxx) {
                                 if (!_levelxxxxxx.m_5776_()) {
                                    _levelxxxxxx.m_5594_(
                                       null,
                                       BlockPos.m_274561_(x, y, z),
                                       (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                       SoundSource.NEUTRAL,
                                       1.0F,
                                       1.0F
                                    );
                                 } else {
                                    _levelxxxxxx.m_7785_(
                                       x,
                                       y,
                                       z,
                                       (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                       SoundSource.NEUTRAL,
                                       1.0F,
                                       1.0F,
                                       false
                                    );
                                 }
                              }

                              if (world instanceof ServerLevel _levelx) {
                                 _levelx.m_7654_()
                                    .m_129892_()
                                    .m_230957_(
                                       new CommandSourceStack(
                                             CommandSource.f_80164_,
                                             new Vec3(x, y, z),
                                             Vec2.f_82462_,
                                             _levelx,
                                             4,
                                             "",
                                             Component.m_237113_(""),
                                             _levelx.m_7654_(),
                                             null
                                          )
                                          .m_81324_(),
                                       "/setblock 7 10 57 inside_the_system:base"
                                    );
                              }

                              if (world instanceof ServerLevel _levelx) {
                                 _levelx.m_8767_(ParticleTypes.f_123746_, x, y, z, 5, 7.0, 10.0, 24.0, 1.0);
                              }

                              InsideTheSystemMod.queueServerWork(
                                 20,
                                 () -> {
                                    if (world instanceof Level _levelxxxxxxxxx) {
                                       if (!_levelxxxxxxxxx.m_5776_()) {
                                          _levelxxxxxxxxx.m_5594_(
                                             null,
                                             BlockPos.m_274561_(x, y, z),
                                             (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                             SoundSource.NEUTRAL,
                                             1.0F,
                                             1.0F
                                          );
                                       } else {
                                          _levelxxxxxxxxx.m_7785_(
                                             x,
                                             y,
                                             z,
                                             (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                             SoundSource.NEUTRAL,
                                             1.0F,
                                             1.0F,
                                             false
                                          );
                                       }
                                    }

                                    if (world instanceof ServerLevel _levelx) {
                                       _levelx.m_7654_()
                                          .m_129892_()
                                          .m_230957_(
                                             new CommandSourceStack(
                                                   CommandSource.f_80164_,
                                                   new Vec3(x, y, z),
                                                   Vec2.f_82462_,
                                                   _levelx,
                                                   4,
                                                   "",
                                                   Component.m_237113_(""),
                                                   _levelx.m_7654_(),
                                                   null
                                                )
                                                .m_81324_(),
                                             "/setblock 7 10 58 inside_the_system:base"
                                          );
                                    }

                                    if (world instanceof ServerLevel _levelx) {
                                       _levelx.m_8767_(ParticleTypes.f_123746_, x, y, z, 5, 7.0, 10.0, 25.0, 1.0);
                                    }

                                    InsideTheSystemMod.queueServerWork(
                                       20,
                                       () -> {
                                          if (world instanceof Level _levelxxxxxxxxxxxx) {
                                             if (!_levelxxxxxxxxxxxx.m_5776_()) {
                                                _levelxxxxxxxxxxxx.m_5594_(
                                                   null,
                                                   BlockPos.m_274561_(x, y, z),
                                                   (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                                   SoundSource.NEUTRAL,
                                                   1.0F,
                                                   1.0F
                                                );
                                             } else {
                                                _levelxxxxxxxxxxxx.m_7785_(
                                                   x,
                                                   y,
                                                   z,
                                                   (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                                   SoundSource.NEUTRAL,
                                                   1.0F,
                                                   1.0F,
                                                   false
                                                );
                                             }
                                          }

                                          if (world instanceof ServerLevel _levelx) {
                                             _levelx.m_7654_()
                                                .m_129892_()
                                                .m_230957_(
                                                   new CommandSourceStack(
                                                         CommandSource.f_80164_,
                                                         new Vec3(x, y, z),
                                                         Vec2.f_82462_,
                                                         _levelx,
                                                         4,
                                                         "",
                                                         Component.m_237113_(""),
                                                         _levelx.m_7654_(),
                                                         null
                                                      )
                                                      .m_81324_(),
                                                   "/setblock 7 10 59 inside_the_system:base"
                                                );
                                          }

                                          if (world instanceof ServerLevel _levelx) {
                                             _levelx.m_8767_(ParticleTypes.f_123746_, x, y, z, 5, 7.0, 10.0, 26.0, 1.0);
                                          }

                                          InsideTheSystemMod.queueServerWork(
                                             20,
                                             () -> {
                                                if (world instanceof Level _levelxxxxxxxxxxxxxxx) {
                                                   if (!_levelxxxxxxxxxxxxxxx.m_5776_()) {
                                                      _levelxxxxxxxxxxxxxxx.m_5594_(
                                                         null,
                                                         BlockPos.m_274561_(x, y, z),
                                                         (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                                         SoundSource.NEUTRAL,
                                                         1.0F,
                                                         1.0F
                                                      );
                                                   } else {
                                                      _levelxxxxxxxxxxxxxxx.m_7785_(
                                                         x,
                                                         y,
                                                         z,
                                                         (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                                         SoundSource.NEUTRAL,
                                                         1.0F,
                                                         1.0F,
                                                         false
                                                      );
                                                   }
                                                }

                                                if (world instanceof ServerLevel _levelx) {
                                                   _levelx.m_8767_(ParticleTypes.f_123746_, x, y, z, 5, 7.0, 10.0, 27.0, 1.0);
                                                }

                                                if (world instanceof ServerLevel _levelx) {
                                                   _levelx.m_7654_()
                                                      .m_129892_()
                                                      .m_230957_(
                                                         new CommandSourceStack(
                                                               CommandSource.f_80164_,
                                                               new Vec3(x, y, z),
                                                               Vec2.f_82462_,
                                                               _levelx,
                                                               4,
                                                               "",
                                                               Component.m_237113_(""),
                                                               _levelx.m_7654_(),
                                                               null
                                                            )
                                                            .m_81324_(),
                                                         "/setblock 7 10 60 inside_the_system:base"
                                                      );
                                                }

                                                InsideTheSystemMod.queueServerWork(
                                                   20,
                                                   () -> {
                                                      if (world instanceof Level _levelxxxxxxxxxxxxxxxxxx) {
                                                         if (!_levelxxxxxxxxxxxxxxxxxx.m_5776_()) {
                                                            _levelxxxxxxxxxxxxxxxxxx.m_5594_(
                                                               null,
                                                               BlockPos.m_274561_(x, y, z),
                                                               (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                  .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                               SoundSource.NEUTRAL,
                                                               1.0F,
                                                               1.0F
                                                            );
                                                         } else {
                                                            _levelxxxxxxxxxxxxxxxxxx.m_7785_(
                                                               x,
                                                               y,
                                                               z,
                                                               (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                  .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                               SoundSource.NEUTRAL,
                                                               1.0F,
                                                               1.0F,
                                                               false
                                                            );
                                                         }
                                                      }

                                                      if (world instanceof ServerLevel _levelx) {
                                                         _levelx.m_8767_(ParticleTypes.f_123765_, x, y, z, 5, 7.0, 10.0, 28.0, 1.0);
                                                      }

                                                      if (world instanceof ServerLevel _levelx) {
                                                         _levelx.m_7654_()
                                                            .m_129892_()
                                                            .m_230957_(
                                                               new CommandSourceStack(
                                                                     CommandSource.f_80164_,
                                                                     new Vec3(x, y, z),
                                                                     Vec2.f_82462_,
                                                                     _levelx,
                                                                     4,
                                                                     "",
                                                                     Component.m_237113_(""),
                                                                     _levelx.m_7654_(),
                                                                     null
                                                                  )
                                                                  .m_81324_(),
                                                               "/setblock 7 10 61 inside_the_system:base"
                                                            );
                                                      }

                                                      InsideTheSystemMod.queueServerWork(
                                                         20,
                                                         () -> {
                                                            if (world instanceof Level _levelxxxxxxxxxxxxxxxxxxxxx) {
                                                               if (!_levelxxxxxxxxxxxxxxxxxxxxx.m_5776_()) {
                                                                  _levelxxxxxxxxxxxxxxxxxxxxx.m_5594_(
                                                                     null,
                                                                     BlockPos.m_274561_(x, y, z),
                                                                     (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                        .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                     SoundSource.NEUTRAL,
                                                                     1.0F,
                                                                     1.0F
                                                                  );
                                                               } else {
                                                                  _levelxxxxxxxxxxxxxxxxxxxxx.m_7785_(
                                                                     x,
                                                                     y,
                                                                     z,
                                                                     (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                        .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                     SoundSource.NEUTRAL,
                                                                     1.0F,
                                                                     1.0F,
                                                                     false
                                                                  );
                                                               }
                                                            }

                                                            if (world instanceof ServerLevel _levelx) {
                                                               _levelx.m_8767_(ParticleTypes.f_123765_, x, y, z, 5, 7.0, 10.0, 28.0, 1.0);
                                                            }

                                                            if (world instanceof ServerLevel _levelx) {
                                                               _levelx.m_7654_()
                                                                  .m_129892_()
                                                                  .m_230957_(
                                                                     new CommandSourceStack(
                                                                           CommandSource.f_80164_,
                                                                           new Vec3(x, y, z),
                                                                           Vec2.f_82462_,
                                                                           _levelx,
                                                                           4,
                                                                           "",
                                                                           Component.m_237113_(""),
                                                                           _levelx.m_7654_(),
                                                                           null
                                                                        )
                                                                        .m_81324_(),
                                                                     "/setblock 7 10 62 inside_the_system:base"
                                                                  );
                                                            }

                                                            InsideTheSystemMod.queueServerWork(
                                                               20,
                                                               () -> {
                                                                  if (world instanceof Level _levelxxxxxxxxxxxxxxxxxxxxxxxx) {
                                                                     if (!_levelxxxxxxxxxxxxxxxxxxxxxxxx.m_5776_()) {
                                                                        _levelxxxxxxxxxxxxxxxxxxxxxxxx.m_5594_(
                                                                           null,
                                                                           BlockPos.m_274561_(x, y, z),
                                                                           (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                              .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                           SoundSource.NEUTRAL,
                                                                           1.0F,
                                                                           1.0F
                                                                        );
                                                                     } else {
                                                                        _levelxxxxxxxxxxxxxxxxxxxxxxxx.m_7785_(
                                                                           x,
                                                                           y,
                                                                           z,
                                                                           (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                              .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                           SoundSource.NEUTRAL,
                                                                           1.0F,
                                                                           1.0F,
                                                                           false
                                                                        );
                                                                     }
                                                                  }

                                                                  if (world instanceof ServerLevel _levelx) {
                                                                     _levelx.m_8767_(ParticleTypes.f_123765_, x, y, z, 5, 7.0, 10.0, 28.0, 1.0);
                                                                  }

                                                                  if (world instanceof ServerLevel _levelx) {
                                                                     _levelx.m_7654_()
                                                                        .m_129892_()
                                                                        .m_230957_(
                                                                           new CommandSourceStack(
                                                                                 CommandSource.f_80164_,
                                                                                 new Vec3(x, y, z),
                                                                                 Vec2.f_82462_,
                                                                                 _levelx,
                                                                                 4,
                                                                                 "",
                                                                                 Component.m_237113_(""),
                                                                                 _levelx.m_7654_(),
                                                                                 null
                                                                              )
                                                                              .m_81324_(),
                                                                           "/setblock 7 10 63 inside_the_system:base"
                                                                        );
                                                                  }

                                                                  InsideTheSystemMod.queueServerWork(
                                                                     20,
                                                                     () -> {
                                                                        if (world instanceof Level _levelxxxxxxxxxxxxxxxxxxxxxxxxxxx) {
                                                                           if (!_levelxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_5776_()) {
                                                                              _levelxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_5594_(
                                                                                 null,
                                                                                 BlockPos.m_274561_(x, y, z),
                                                                                 (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                    .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                                 SoundSource.NEUTRAL,
                                                                                 1.0F,
                                                                                 1.0F
                                                                              );
                                                                           } else {
                                                                              _levelxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_7785_(
                                                                                 x,
                                                                                 y,
                                                                                 z,
                                                                                 (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                    .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                                 SoundSource.NEUTRAL,
                                                                                 1.0F,
                                                                                 1.0F,
                                                                                 false
                                                                              );
                                                                           }
                                                                        }

                                                                        if (world instanceof ServerLevel _levelx) {
                                                                           _levelx.m_8767_(ParticleTypes.f_123765_, x, y, z, 5, 7.0, 10.0, 28.0, 1.0);
                                                                        }

                                                                        if (world instanceof ServerLevel _levelx) {
                                                                           _levelx.m_7654_()
                                                                              .m_129892_()
                                                                              .m_230957_(
                                                                                 new CommandSourceStack(
                                                                                       CommandSource.f_80164_,
                                                                                       new Vec3(x, y, z),
                                                                                       Vec2.f_82462_,
                                                                                       _levelx,
                                                                                       4,
                                                                                       "",
                                                                                       Component.m_237113_(""),
                                                                                       _levelx.m_7654_(),
                                                                                       null
                                                                                    )
                                                                                    .m_81324_(),
                                                                                 "/setblock 7 10 64 inside_the_system:base"
                                                                              );
                                                                        }

                                                                        InsideTheSystemMod.queueServerWork(
                                                                           20,
                                                                           () -> {
                                                                              if (world instanceof Level _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxx) {
                                                                                 if (!_levelxxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_5776_()) {
                                                                                    _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_5594_(
                                                                                       null,
                                                                                       BlockPos.m_274561_(x, y, z),
                                                                                       (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                          .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                                       SoundSource.NEUTRAL,
                                                                                       1.0F,
                                                                                       1.0F
                                                                                    );
                                                                                 } else {
                                                                                    _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_7785_(
                                                                                       x,
                                                                                       y,
                                                                                       z,
                                                                                       (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                          .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                                       SoundSource.NEUTRAL,
                                                                                       1.0F,
                                                                                       1.0F,
                                                                                       false
                                                                                    );
                                                                                 }
                                                                              }

                                                                              if (world instanceof ServerLevel _serverworld) {
                                                                                 StructureTemplate template = _serverworld.m_215082_()
                                                                                    .m_230359_(new ResourceLocation("inside_the_system", "story3"));
                                                                                 if (template != null) {
                                                                                    template.m_230328_(
                                                                                       _serverworld,
                                                                                       new BlockPos(5, 10, 65),
                                                                                       new BlockPos(5, 10, 65),
                                                                                       new StructurePlaceSettings()
                                                                                          .m_74379_(Rotation.NONE)
                                                                                          .m_74377_(Mirror.NONE)
                                                                                          .m_74392_(false),
                                                                                       _serverworld.f_46441_,
                                                                                       3
                                                                                    );
                                                                                 }
                                                                              }

                                                                              InsideTheSystemMod.queueServerWork(
                                                                                 30,
                                                                                 () -> {
                                                                                    if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                       world.m_7654_()
                                                                                          .m_6846_()
                                                                                          .m_240416_(
                                                                                             Component.m_237113_(
                                                                                                "<CoolPlayer303> And so... she arrived at the tunnel. A foul odor drifted from within, the kind that spoke of long abandonment. A faint fear wrapped itself around the girl"
                                                                                             ),
                                                                                             false
                                                                                          );
                                                                                    }

                                                                                    if (entity instanceof LivingEntity _entity && !_entity.m_9236_().m_5776_()) {
                                                                                       _entity.m_7292_(
                                                                                          new MobEffectInstance(MobEffects.f_19610_, 9999, 3, false, false)
                                                                                       );
                                                                                    }

                                                                                    if (entity instanceof LivingEntity _entity && !_entity.m_9236_().m_5776_()) {
                                                                                       _entity.m_7292_(
                                                                                          new MobEffectInstance(MobEffects.f_19597_, 9999, 3, false, false)
                                                                                       );
                                                                                    }

                                                                                    InsideTheSystemMod.queueServerWork(
                                                                                       100,
                                                                                       () -> {
                                                                                          if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                             world.m_7654_()
                                                                                                .m_6846_()
                                                                                                .m_240416_(
                                                                                                   Component.m_237113_(
                                                                                                      "<CoolPlayer303> Why didn’t he meet me outside? Why didn’t he want to come with me? — such thoughts rushed through her mind"
                                                                                                   ),
                                                                                                   false
                                                                                                );
                                                                                          }

                                                                                          InsideTheSystemMod.queueServerWork(
                                                                                             100,
                                                                                             () -> {
                                                                                                if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                   world.m_7654_()
                                                                                                      .m_6846_()
                                                                                                      .m_240416_(
                                                                                                         Component.m_237113_(
                                                                                                            "<CoolPlayer303> She stepped forward, and inside her chest everything tightened"
                                                                                                         ),
                                                                                                         false
                                                                                                      );
                                                                                                }

                                                                                                if (entity instanceof LivingEntity _entityx
                                                                                                   && !_entityx.m_9236_().m_5776_()) {
                                                                                                   _entityx.m_7292_(
                                                                                                      new MobEffectInstance(
                                                                                                         MobEffects.f_19597_, 9999, 4, false, false
                                                                                                      )
                                                                                                   );
                                                                                                }

                                                                                                InsideTheSystemMod.queueServerWork(
                                                                                                   100,
                                                                                                   () -> {
                                                                                                      if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                         world.m_7654_()
                                                                                                            .m_6846_()
                                                                                                            .m_240416_(
                                                                                                               Component.m_237113_(
                                                                                                                  "<CoolPlayer303> Her body trembled..."
                                                                                                               ),
                                                                                                               false
                                                                                                            );
                                                                                                      }

                                                                                                      if (entity instanceof LivingEntity _entityxx
                                                                                                         && !_entityxx.m_9236_().m_5776_()) {
                                                                                                         _entityxx.m_7292_(
                                                                                                            new MobEffectInstance(
                                                                                                               MobEffects.f_19597_, 9999, 5, false, false
                                                                                                            )
                                                                                                         );
                                                                                                      }

                                                                                                      InsideTheSystemMod.queueServerWork(
                                                                                                         100,
                                                                                                         () -> {
                                                                                                            if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                               world.m_7654_()
                                                                                                                  .m_6846_()
                                                                                                                  .m_240416_(
                                                                                                                     Component.m_237113_(
                                                                                                                        "<CoolPlayer303> Yet, despite the fear gnawing at her, the girl continued onward"
                                                                                                                     ),
                                                                                                                     false
                                                                                                                  );
                                                                                                            }

                                                                                                            if (entity instanceof LivingEntity _entityxxx
                                                                                                               && !_entityxxx.m_9236_().m_5776_()) {
                                                                                                               _entityxxx.m_7292_(
                                                                                                                  new MobEffectInstance(
                                                                                                                     MobEffects.f_19610_, 9999, 5, false, false
                                                                                                                  )
                                                                                                               );
                                                                                                            }

                                                                                                            InsideTheSystemMod.queueServerWork(
                                                                                                               100,
                                                                                                               () -> {
                                                                                                                  InsideTheSystemModVariables.MapVariables.get(
                                                                                                                        world
                                                                                                                     )
                                                                                                                     .story3 = true;
                                                                                                                  InsideTheSystemModVariables.MapVariables.get(
                                                                                                                        world
                                                                                                                     )
                                                                                                                     .syncData(world);
                                                                                                                  if (world instanceof ServerLevel _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
                                                                                                                     )
                                                                                                                   {
                                                                                                                     Entity entityToSpawn = ((EntityType)InsideTheSystemModEntities.FATHER
                                                                                                                           .get())
                                                                                                                        .m_262496_(
                                                                                                                           _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx,
                                                                                                                           BlockPos.m_274561_(
                                                                                                                              InsideTheSystemModVariables.MapVariables.get(
                                                                                                                                    world
                                                                                                                                 )
                                                                                                                                 .PlayerX,
                                                                                                                              InsideTheSystemModVariables.MapVariables.get(
                                                                                                                                    world
                                                                                                                                 )
                                                                                                                                 .PlayerY,
                                                                                                                              InsideTheSystemModVariables.MapVariables.get(
                                                                                                                                       world
                                                                                                                                    )
                                                                                                                                    .PlayerZ
                                                                                                                                 - 4.0
                                                                                                                           ),
                                                                                                                           MobSpawnType.MOB_SUMMONED
                                                                                                                        );
                                                                                                                     if (entityToSpawn != null) {
                                                                                                                        entityToSpawn.m_146922_(
                                                                                                                           world.m_213780_().m_188501_()
                                                                                                                              * 360.0F
                                                                                                                        );
                                                                                                                     }
                                                                                                                  }

                                                                                                                  if (world instanceof ServerLevel _levelx) {
                                                                                                                     _levelx.m_7654_()
                                                                                                                        .m_129892_()
                                                                                                                        .m_230957_(
                                                                                                                           new CommandSourceStack(
                                                                                                                                 CommandSource.f_80164_,
                                                                                                                                 new Vec3(x, y, z),
                                                                                                                                 Vec2.f_82462_,
                                                                                                                                 _levelx,
                                                                                                                                 4,
                                                                                                                                 "",
                                                                                                                                 Component.m_237113_(""),
                                                                                                                                 _levelx.m_7654_(),
                                                                                                                                 null
                                                                                                                              )
                                                                                                                              .m_81324_(),
                                                                                                                           "/setblock ~ ~ ~ light[level=3]"
                                                                                                                        );
                                                                                                                  }
                                                                                                               }
                                                                                                            );
                                                                                                         }
                                                                                                      );
                                                                                                   }
                                                                                                );
                                                                                             }
                                                                                          );
                                                                                       }
                                                                                    );
                                                                                 }
                                                                              );
                                                                           }
                                                                        );
                                                                     }
                                                                  );
                                                               }
                                                            );
                                                         }
                                                      );
                                                   }
                                                );
                                             }
                                          );
                                       }
                                    );
                                 }
                              );
                           }
                        );
                     }
                  );
               }
            );
         }
      }
   }
}
