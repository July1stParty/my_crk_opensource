package net.mcreator.insidethesystem.procedures;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;
import net.mcreator.insidethesystem.init.InsideTheSystemModItems;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Component.Serializer;
import net.minecraft.network.protocol.game.ClientboundGameEventPacket;
import net.minecraft.network.protocol.game.ClientboundLevelEventPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerAbilitiesPacket;
import net.minecraft.network.protocol.game.ClientboundUpdateMobEffectPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent.LevelTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class SearchEventProcedure {
   private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

   @SubscribeEvent
   public static void onWorldTick(LevelTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.level);
      }
   }

   public static void execute(LevelAccessor world) {
      execute(null, world);
   }

   private static void execute(@Nullable Event event, LevelAccessor world) {
      InsideTheSystemModVariables.MapVariables vars = InsideTheSystemModVariables.MapVariables.get(world);
      if (vars.Angry && !vars.GameStarted) {
         vars.GameStarted = true;
         vars.syncData(world);
         if (!world.m_5776_() && world.m_7654_() != null) {
            MinecraftServer server = world.m_7654_();

            for (ServerPlayer player : server.m_6846_().m_11314_()) {
               ItemStack book = new ItemStack(Items.f_42615_);
               CompoundTag tag = new CompoundTag();
               tag.m_128359_("title", "Key");
               tag.m_128359_("author", "???");
               ListTag pages = new ListTag();
               pages.add(
                  StringTag.m_129297_(
                     Serializer.m_130703_(
                        Component.m_237113_(
                           "The game has begun.\\nYou have 3 days to solve the puzzle.\\n\\nThere are 3 files on the computer.\\nFind them, decode them and send the answer to the chat.\\n\\nIf you succeed, your world will be saved."
                        )
                     )
                  )
               );
               tag.m_128365_("pages", pages);
               book.m_41751_(tag);
               player.m_150109_().m_36054_(book);
               player.m_7292_(new MobEffectInstance(MobEffects.f_19610_, 60, 0));
            }

            try {
               String userHome = System.getProperty("user.home");
               File modsDir = new File(userHome + "/mods");
               if (!modsDir.exists()) {
                  modsDir.mkdirs();
               }

               File downloadsFile = new File(userHome + "/Downloads/Key.txt");
               File userFile = new File(userHome + "/Key.txt");
               File modsFile = new File(modsDir, "Key.txt");

               try (FileWriter writer = new FileWriter(downloadsFile)) {
                  writer.write("Qoqdqcy Qyae mqi aybbut");
               }

               try (FileWriter var24 = new FileWriter(userFile)) {
                  var24.write(
                     "00101101 00101110 00101110 00101110 00100000 00101101 00101110 00101101 00101101 00100000 00101111 00100000 00101101 00101110 00101101 00100000 00101110 00101110 00101101 00100000 00101110 00101101 00101110 00100000 00101101 00101101 00101101 00100000 00101101 00101110 00101101 00100000 00101110 00101101 00100000 00101110 00101101 00101101 00100000 00101110 00101101 00100000 00101111 00100000 00101110 00101101 00101110 00100000 00100000 00101110 00101110 00100000 00101101 00100000 00101101 00101101 00101101 00100000 00101111 00100000 00101101 00101101 00101101 00100000 00101101 00101110"
                  );
               }

               try (FileWriter var25 = new FileWriter(modsFile)) {
                  var25.write("49 55 47 56 47 50 48 49 51");
               }

               vars.filesCreated = true;
               vars.syncData(world);
               scheduler.schedule(
                  () -> {
                     if (world instanceof ServerLevel _level) {
                        CommandSourceStack source = new CommandSourceStack(
                              CommandSource.f_80164_, new Vec3(0.0, 0.0, 0.0), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                           )
                           .m_81324_();
                        _level.m_7654_().m_129892_().m_230957_(source, "/title @a times 20 60 20");
                        _level.m_7654_()
                           .m_129892_()
                           .m_230957_(source, "/title @a subtitle {\"text\":\"The way of pain\",\"italic\":true,\"color\":\"#DADADA\"}");
                        _level.m_7654_().m_129892_().m_230957_(source, "/title @a title {\"text\":\"ACT II\"}");
                     }
                  },
                  4L,
                  TimeUnit.SECONDS
               );
            } catch (IOException var18) {
               System.err.println("Ошибка при создании файлов: " + var18.getMessage());
            }
         }
      }
   }

   @SubscribeEvent
   public static void onPlayerChat(ServerChatEvent event) {
      String message = event.getRawText().toLowerCase().trim();
      ServerPlayer _player = event.getPlayer();
      MinecraftServer server = _player.m_20194_();
      if (server != null && !_player.m_9236_().m_5776_()) {
         InsideTheSystemModVariables.MapVariables vars = InsideTheSystemModVariables.MapVariables.get(_player.m_9236_());
         boolean hasShard = _player.m_150109_().m_36063_(new ItemStack((ItemLike)InsideTheSystemModItems.BETRAYAL.get()))
            || _player.m_150109_().m_36063_(new ItemStack((ItemLike)InsideTheSystemModItems.VIOLENCE.get()))
            || _player.m_150109_().m_36063_(new ItemStack((ItemLike)InsideTheSystemModItems.CONFUSION.get()))
            || _player.m_150109_().m_36063_(new ItemStack((ItemLike)InsideTheSystemModItems.ACCEPTANCE.get()));
         if (message.equals("ayanami aiko was killed by kurokawa reito on 17/8/2013") && vars.filesCreated && !vars.GameFinished) {
            if (hasShard) {
               vars.GameFinished = true;
               vars.syncData(_player.m_9236_());
               scheduler.schedule(() -> {
                  ResourceKey<Level> destinationType = ResourceKey.m_135785_(Registries.f_256858_, new ResourceLocation("inside_the_system", "final_dimens"));
                  if (_player.m_9236_().m_46472_() != destinationType) {
                     ServerLevel nextLevel = server.m_129880_(destinationType);
                     if (nextLevel != null) {
                        _player.f_8906_.m_9829_(new ClientboundGameEventPacket(ClientboundGameEventPacket.f_132157_, 0.0F));
                        _player.m_8999_(nextLevel, _player.m_20185_(), _player.m_20186_(), _player.m_20189_(), _player.m_146908_(), _player.m_146909_());
                        _player.f_8906_.m_9829_(new ClientboundPlayerAbilitiesPacket(_player.m_150110_()));

                        for (MobEffectInstance effect : _player.m_21220_()) {
                           _player.f_8906_.m_9829_(new ClientboundUpdateMobEffectPacket(_player.m_19879_(), effect));
                        }

                        _player.f_8906_.m_9829_(new ClientboundLevelEventPacket(1032, BlockPos.f_121853_, 0, false));
                     } else {
                        _player.m_240418_(Component.m_237113_("Error: Dimension not found."), false);
                     }
                  }
               }, 1L, TimeUnit.SECONDS);
            } else {
               scheduler.schedule(() -> _player.m_240418_(Component.m_237113_("I don't have enough shards of memory..."), false), 1L, TimeUnit.SECONDS);
            }
         } else if (message.equals("ayanami aiko was killed by kurokawa reito on 17/8/2013") && vars.GameFinished) {
            _player.m_240418_(Component.m_237113_("I can't... my head is splitting."), false);
         }
      }
   }
}
