package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.CommandEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class BlockCommandsProcedure {
   @SubscribeEvent
   public static void onCommand(CommandEvent event) {
      if (!((CommandSourceStack)event.getParseResults().getContext().getSource()).m_81372_().m_5776_()
         && InsideTheSystemModVariables.MapVariables.get(((CommandSourceStack)event.getParseResults().getContext().getSource()).m_81372_()).BlockCommands
         && ((CommandSourceStack)event.getParseResults().getContext().getSource()).m_81373_() instanceof Player player) {
         event.setCanceled(true);
         player.m_5661_(Component.m_237113_("§c現在、コマンドは使えません。"), false);
      }
   }
}
