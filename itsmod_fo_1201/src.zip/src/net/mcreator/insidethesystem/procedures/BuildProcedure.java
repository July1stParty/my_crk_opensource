package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.registries.ForgeRegistries;

@EventBusSubscriber
public class BuildProcedure {
   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player.m_20185_(), event.player.m_20186_(), event.player.m_20189_(), event.player);
      }
   }

   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      execute(null, world, x, y, z, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (entity.m_9236_().m_46472_() == ResourceKey.m_135785_(Registries.f_256858_, new ResourceLocation("inside_the_system:home"))
            && Math.round(entity.m_20185_()) == 7L
            && Math.round(entity.m_20189_()) == 7L
            && !InsideTheSystemModVariables.MapVariables.get(world).story0) {
            InsideTheSystemModVariables.MapVariables.get(world).story0 = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemMod.queueServerWork(
               50,
               () -> {
                  if (world instanceof ServerLevel _level) {
                     _level.m_7654_()
                        .m_129892_()
                        .m_230957_(
                           new CommandSourceStack(
                                 CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                              )
                              .m_81324_(),
                           "/setblock 7 12 13 minecraft:light"
                        );
                  }

                  if (world instanceof Level _level) {
                     if (!_level.m_5776_()) {
                        _level.m_5594_(
                           null,
                           BlockPos.m_274561_(x, y, z),
                           (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:light")),
                           SoundSource.NEUTRAL,
                           1.0F,
                           1.0F
                        );
                     } else {
                        _level.m_7785_(
                           x,
                           y,
                           z,
                           (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:light")),
                           SoundSource.NEUTRAL,
                           1.0F,
                           1.0F,
                           false
                        );
                     }
                  }

                  if (!world.m_5776_() && world.m_7654_() != null) {
                     world.m_7654_()
                        .m_6846_()
                        .m_240416_(Component.m_237113_("<CoolPlayer303> So you came here... right into the depths of my memories, huh?"), false);
                  }

                  InsideTheSystemMod.queueServerWork(
                     200,
                     () -> {
                        if (!world.m_5776_() && world.m_7654_() != null) {
                           world.m_7654_()
                              .m_6846_()
                              .m_240416_(Component.m_237113_("<CoolPlayer303> It’s funny that you went through so much just for this... well then"), false);
                        }

                        InsideTheSystemMod.queueServerWork(
                           200,
                           () -> {
                              if (!world.m_5776_() && world.m_7654_() != null) {
                                 world.m_7654_()
                                    .m_6846_()
                                    .m_240416_(
                                       Component.m_237113_("<CoolPlayer303> I’ll be your little storyteller, ehehe, let’s see what happens from here!"), false
                                    );
                              }

                              InsideTheSystemMod.queueServerWork(
                                 200,
                                 () -> {
                                    if (!world.m_5776_() && world.m_7654_() != null) {
                                       world.m_7654_()
                                          .m_6846_()
                                          .m_240416_(Component.m_237113_("<CoolPlayer303> And yet... thank you for trying so hard for me"), false);
                                    }

                                    InsideTheSystemMod.queueServerWork(
                                       200,
                                       () -> {
                                          if (!world.m_5776_() && world.m_7654_() != null) {
                                             world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> Well then... let's begin"), false);
                                          }

                                          InsideTheSystemMod.queueServerWork(
                                             200,
                                             () -> {
                                                if (!world.m_5776_() && world.m_7654_() != null) {
                                                   world.m_7654_()
                                                      .m_6846_()
                                                      .m_240416_(
                                                         Component.m_237113_(
                                                            "<CoolPlayer303> The clock was already nearing evening, and a certain joy filled her heart at the thought of seeing her friend"
                                                         ),
                                                         false
                                                      );
                                                }

                                                InsideTheSystemMod.queueServerWork(
                                                   200,
                                                   () -> {
                                                      if (!world.m_5776_() && world.m_7654_() != null) {
                                                         world.m_7654_()
                                                            .m_6846_()
                                                            .m_240416_(
                                                               Component.m_237113_(
                                                                  "<CoolPlayer303> She carefully chose her best outfit, unnoticed by her mother, who was too absorbed in a phone conversation with someone else"
                                                               ),
                                                               false
                                                            );
                                                      }

                                                      InsideTheSystemMod.queueServerWork(
                                                         200,
                                                         () -> {
                                                            if (!world.m_5776_() && world.m_7654_() != null) {
                                                               world.m_7654_()
                                                                  .m_6846_()
                                                                  .m_240416_(
                                                                     Component.m_237113_(
                                                                        "<CoolPlayer303> The day before, when she had mentioned going out with her friends, her mother’s smile had shone with rare sincerity—one of those fleeting moments that left a trace in memor"
                                                                     ),
                                                                     false
                                                                  );
                                                            }

                                                            InsideTheSystemMod.queueServerWork(
                                                               200,
                                                               () -> {
                                                                  if (!world.m_5776_() && world.m_7654_() != null) {
                                                                     world.m_7654_()
                                                                        .m_6846_()
                                                                        .m_240416_(
                                                                           Component.m_237113_(
                                                                              "<CoolPlayer303> Their house, though modest, radiated warmth: white walls, two floors, and a quiet sense of comfort. For her, it was enough"
                                                                           ),
                                                                           false
                                                                        );
                                                                  }

                                                                  InsideTheSystemMod.queueServerWork(
                                                                     200,
                                                                     () -> {
                                                                        if (!world.m_5776_() && world.m_7654_() != null) {
                                                                           world.m_7654_()
                                                                              .m_6846_()
                                                                              .m_240416_(
                                                                                 Component.m_237113_(
                                                                                    "<CoolPlayer303> Yet something was missing—her father. He had left long ago, and despite her longing, he no longer reached out to her. By her understanding, her mother had forbidden it through official means"
                                                                                 ),
                                                                                 false
                                                                              );
                                                                        }

                                                                        InsideTheSystemMod.queueServerWork(
                                                                           200,
                                                                           () -> {
                                                                              if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                 world.m_7654_()
                                                                                    .m_6846_()
                                                                                    .m_240416_(
                                                                                       Component.m_237113_(
                                                                                          "<CoolPlayer303> Still, she had accepted this absence long ago. And so, on this particular evening, she did not dwell on it. She simply opened the door and stepped out, beginning her small journey"
                                                                                       ),
                                                                                       false
                                                                                    );
                                                                              }

                                                                              InsideTheSystemModVariables.MapVariables.get(world).story1 = true;
                                                                              InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
                                                                           }
                                                                        );
                                                                     }
                                                                  );
                                                               }
                                                            );
                                                         }
                                                      );
                                                   }
                                                );
                                             }
                                          );
                                       }
                                    );
                                 }
                              );
                           }
                        );
                     }
                  );
               }
            );
         }
      }
   }
}
