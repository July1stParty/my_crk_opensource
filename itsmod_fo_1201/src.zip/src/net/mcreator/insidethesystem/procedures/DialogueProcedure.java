package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent.LevelTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class DialogueProcedure {
   @SubscribeEvent
   public static void onWorldTick(LevelTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.level);
      }
   }

   public static void execute(LevelAccessor world) {
      execute(null, world);
   }

   private static void execute(@Nullable Event event, LevelAccessor world) {
      if (InsideTheSystemModVariables.MapVariables.get(world).DialogueBool) {
         if (InsideTheSystemModVariables.MapVariables.get(world).Dialogue == 1000.0) {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("..."), false);
            }
         } else if (InsideTheSystemModVariables.MapVariables.get(world).Dialogue == 800.0) {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("Unfortunately, that world was destroyed"), false);
            }
         } else if (InsideTheSystemModVariables.MapVariables.get(world).Dialogue == 600.0) {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("Why didn't you save me?"), false);
            }
         } else if (InsideTheSystemModVariables.MapVariables.get(world).Dialogue == 400.0) {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("Maybe I deserved it."), false);
            }
         } else if (InsideTheSystemModVariables.MapVariables.get(world).Dialogue == 200.0) {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("To die."), false);
            }
         } else if (InsideTheSystemModVariables.MapVariables.get(world).Dialogue == 0.0) {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("この瞬間を一緒に過ごしてくれてありがとう。"), false);
            }

            if (world instanceof ServerLevel _level) {
               _level.m_7654_()
                  .m_129892_()
                  .m_230957_(
                     new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(0.0, 0.0, 0.0), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                        )
                        .m_81324_(),
                     "/title @a times 20 60 20"
                  );
            }

            if (world instanceof ServerLevel _level) {
               _level.m_7654_()
                  .m_129892_()
                  .m_230957_(
                     new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(0.0, 0.0, 0.0), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                        )
                        .m_81324_(),
                     "/title @a subtitle {\"text\":\"An unsolved puzzle...\",\"italic\":true,\"color\":\"#DADADA\"}"
                  );
            }

            if (world instanceof ServerLevel _level) {
               _level.m_7654_()
                  .m_129892_()
                  .m_230957_(
                     new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(0.0, 0.0, 0.0), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                        )
                        .m_81324_(),
                     "/title @a title {\"text\":\"Ending E\"}"
                  );
            }
         }

         InsideTheSystemModVariables.MapVariables.get(world).Dialogue--;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }
   }
}
