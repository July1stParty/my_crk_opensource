package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundGameEventPacket;
import net.minecraft.network.protocol.game.ClientboundLevelEventPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerAbilitiesPacket;
import net.minecraft.network.protocol.game.ClientboundUpdateMobEffectPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

public class EndingCProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity sourceentity) {
      if (sourceentity != null) {
         if (sourceentity instanceof LivingEntity _entity && !_entity.m_9236_().m_5776_()) {
            _entity.m_7292_(new MobEffectInstance(MobEffects.f_19610_, 300, 20, false, false));
         }

         if (sourceentity instanceof LivingEntity _entity && !_entity.m_9236_().m_5776_()) {
            _entity.m_7292_(new MobEffectInstance(MobEffects.f_19597_, 300, 20, false, false));
         }

         if (world instanceof ServerLevel _level) {
            _level.m_7654_()
               .m_129892_()
               .m_230957_(
                  new CommandSourceStack(
                        CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                     )
                     .m_81324_(),
                  "/stopsound"
               );
         }

         if (world instanceof Level _level) {
            if (!_level.m_5776_()) {
               _level.m_5594_(
                  null,
                  BlockPos.m_274561_(
                     InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                     InsideTheSystemModVariables.MapVariables.get(world).PlayerY,
                     InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
                  ),
                  (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:endingc")),
                  SoundSource.NEUTRAL,
                  1.0F,
                  1.0F
               );
            } else {
               _level.m_7785_(
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerY,
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerZ,
                  (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:endingc")),
                  SoundSource.NEUTRAL,
                  1.0F,
                  1.0F,
                  false
               );
            }
         }

         InsideTheSystemMod.queueServerWork(
            100,
            () -> {
               if (world instanceof ServerLevel _levelxxx) {
                  _levelxxx.m_7654_()
                     .m_129892_()
                     .m_230957_(
                        new CommandSourceStack(
                              CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _levelxxx, 4, "", Component.m_237113_(""), _levelxxx.m_7654_(), null
                           )
                           .m_81324_(),
                        "/title @a times 20 60 20"
                     );
               }

               if (world instanceof ServerLevel _levelxx) {
                  _levelxx.m_7654_()
                     .m_129892_()
                     .m_230957_(
                        new CommandSourceStack(
                              CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _levelxx, 4, "", Component.m_237113_(""), _levelxx.m_7654_(), null
                           )
                           .m_81324_(),
                        "/title @a subtitle {\"text\":\"My revenge...\",\"italic\":true,\"color\":\"#DADADA\"}"
                     );
               }

               if (world instanceof ServerLevel _levelx) {
                  _levelx.m_7654_()
                     .m_129892_()
                     .m_230957_(
                        new CommandSourceStack(
                              CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _levelx, 4, "", Component.m_237113_(""), _levelx.m_7654_(), null
                           )
                           .m_81324_(),
                        "/title @a title {\"text\":\"Ending C\"}"
                     );
               }

               InsideTheSystemMod.queueServerWork(
                  100,
                  () -> {
                     if (world instanceof ServerLevel _levelxxxxx) {
                        _levelxxxxx.m_7654_()
                           .m_129892_()
                           .m_230957_(
                              new CommandSourceStack(
                                    CommandSource.f_80164_,
                                    new Vec3(x, y, z),
                                    Vec2.f_82462_,
                                    _levelxxxxx,
                                    4,
                                    "",
                                    Component.m_237113_(""),
                                    _levelxxxxx.m_7654_(),
                                    null
                                 )
                                 .m_81324_(),
                              "/title @a times 20 60 20"
                           );
                     }

                     if (world instanceof ServerLevel _levelxxxx) {
                        _levelxxxx.m_7654_()
                           .m_129892_()
                           .m_230957_(
                              new CommandSourceStack(
                                    CommandSource.f_80164_,
                                    new Vec3(x, y, z),
                                    Vec2.f_82462_,
                                    _levelxxxx,
                                    4,
                                    "",
                                    Component.m_237113_(""),
                                    _levelxxxx.m_7654_(),
                                    null
                                 )
                                 .m_81324_(),
                              "/title @a title {\"text\":\"Thanks for playing\"}"
                           );
                     }

                     InsideTheSystemMod.queueServerWork(
                        100,
                        () -> {
                           if (world instanceof ServerLevel _levelxxxxxxx) {
                              _levelxxxxxxx.m_7654_()
                                 .m_129892_()
                                 .m_230957_(
                                    new CommandSourceStack(
                                          CommandSource.f_80164_,
                                          new Vec3(x, y, z),
                                          Vec2.f_82462_,
                                          _levelxxxxxxx,
                                          4,
                                          "",
                                          Component.m_237113_(""),
                                          _levelxxxxxxx.m_7654_(),
                                          null
                                       )
                                       .m_81324_(),
                                    "/title @a times 20 60 20"
                                 );
                           }

                           if (world instanceof ServerLevel _levelxxxxxx) {
                              _levelxxxxxx.m_7654_()
                                 .m_129892_()
                                 .m_230957_(
                                    new CommandSourceStack(
                                          CommandSource.f_80164_,
                                          new Vec3(x, y, z),
                                          Vec2.f_82462_,
                                          _levelxxxxxx,
                                          4,
                                          "",
                                          Component.m_237113_(""),
                                          _levelxxxxxx.m_7654_(),
                                          null
                                       )
                                       .m_81324_(),
                                    "/title @a title {\"text\":\"But...\"}"
                                 );
                           }

                           InsideTheSystemMod.queueServerWork(
                              100,
                              () -> {
                                 if (world instanceof ServerLevel _levelxxxxxxxxx) {
                                    _levelxxxxxxxxx.m_7654_()
                                       .m_129892_()
                                       .m_230957_(
                                          new CommandSourceStack(
                                                CommandSource.f_80164_,
                                                new Vec3(x, y, z),
                                                Vec2.f_82462_,
                                                _levelxxxxxxxxx,
                                                4,
                                                "",
                                                Component.m_237113_(""),
                                                _levelxxxxxxxxx.m_7654_(),
                                                null
                                             )
                                             .m_81324_(),
                                          "/title @a times 20 60 20"
                                       );
                                 }

                                 if (world instanceof ServerLevel _levelxxxxxxxx) {
                                    _levelxxxxxxxx.m_7654_()
                                       .m_129892_()
                                       .m_230957_(
                                          new CommandSourceStack(
                                                CommandSource.f_80164_,
                                                new Vec3(x, y, z),
                                                Vec2.f_82462_,
                                                _levelxxxxxxxx,
                                                4,
                                                "",
                                                Component.m_237113_(""),
                                                _levelxxxxxxxx.m_7654_(),
                                                null
                                             )
                                             .m_81324_(),
                                          "/title @a title {\"text\":\"Can it be changed?\"}"
                                       );
                                 }

                                 InsideTheSystemMod.queueServerWork(
                                    260,
                                    () -> {
                                       if (sourceentity instanceof ServerPlayer _player && !_player.m_9236_().m_5776_()) {
                                          ResourceKey<Level> destinationType = Level.f_46428_;
                                          if (_player.m_9236_().m_46472_() == destinationType) {
                                             return;
                                          }

                                          ServerLevel nextLevel = _player.f_8924_.m_129880_(destinationType);
                                          if (nextLevel != null) {
                                             _player.f_8906_.m_9829_(new ClientboundGameEventPacket(ClientboundGameEventPacket.f_132157_, 0.0F));
                                             _player.m_8999_(
                                                nextLevel, _player.m_20185_(), _player.m_20186_(), _player.m_20189_(), _player.m_146908_(), _player.m_146909_()
                                             );
                                             _player.f_8906_.m_9829_(new ClientboundPlayerAbilitiesPacket(_player.m_150110_()));

                                             for (MobEffectInstance _effectinstance : _player.m_21220_()) {
                                                _player.f_8906_.m_9829_(new ClientboundUpdateMobEffectPacket(_player.m_19879_(), _effectinstance));
                                             }

                                             _player.f_8906_.m_9829_(new ClientboundLevelEventPacket(1032, BlockPos.f_121853_, 0, false));
                                          }
                                       }
                                    }
                                 );
                              }
                           );
                        }
                     );
                  }
               );
            }
         );
      }
   }
}
