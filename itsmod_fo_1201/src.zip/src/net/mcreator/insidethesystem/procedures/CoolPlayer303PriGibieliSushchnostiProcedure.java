package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.init.InsideTheSystemModEntities;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.LevelAccessor;

public class CoolPlayer303PriGibieliSushchnostiProcedure {
   public static void execute(LevelAccessor world) {
      if (InsideTheSystemModVariables.MapVariables.get(world).Inworld && !InsideTheSystemModVariables.MapVariables.get(world).Angry) {
         if (!world.m_5776_() && world.m_7654_() != null) {
            world.m_7654_().m_6846_().m_240416_(Component.m_237113_("CoolPlayer303 Died from §k:#№;%;?"), false);
         }

         if (world instanceof ServerLevel _level) {
            Entity entityToSpawn = ((EntityType)InsideTheSystemModEntities.COOL_PLAYER_303.get())
               .m_262496_(
                  _level,
                  BlockPos.m_274561_(
                     InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                     InsideTheSystemModVariables.MapVariables.get(world).PlayerY,
                     InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
                  ),
                  MobSpawnType.MOB_SUMMONED
               );
            if (entityToSpawn != null) {
            }
         }
      }
   }
}
