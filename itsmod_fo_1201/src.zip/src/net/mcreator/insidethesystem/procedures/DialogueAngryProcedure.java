package net.mcreator.insidethesystem.procedures;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.TickEvent.LevelTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class DialogueAngryProcedure {
   private static long lastTick = 0L;
   private static final List<String> glitchedMessages = List.of(
      "なにｱ#@!?あれ、do you see the star∽∽",
      "イテ…音がウルサｲ",
      "He said 'follow', but no way back.",
      "エラー#@文字化け…",
      "hElp m3. ﾐﾐﾐﾐﾐ",
      "どこに行けばいい？",
      "Nothing is real!!!@#%",
      "ERROR: ENTITY_███",
      "影…見えた？",
      "夢だった気がｽる",
      "目が覚めなｲ",
      "私、記憶が変になってる",
      "ShadowEnder..何をしたの",
      "笑ってる...あれは人じゃない",
      "█̛̍͢You ᵃʳᵉ ⁿᵒᵗ ˢᵃᶠᵉ█",
      "Are you... broken too?",
      "ウワァ~ glitchglitchglitch",
      "msg@##lost##user::",
      "do y0u s33 it?",
      "Z̸̢͖͕͙̗͙͙̰͖̩̓̇͋̋̏̐̉͂͛̆͛̚͜͠͝ȩ̶̨̜̟͍̬͖̳̟͓̦̪̻̩̬̲͙̞͊̎͐͊̃͌́́̍͊̂͝ͅn̴̡̤̦͙͙̖̱͉̞̱͓̻̯̠̩͓̾̏̓̀̐͆̓͛̐̍̀̚ͅ",
      "目を合わせないで",
      "誰か…？",
      "ゐゑゑゑ…",
      "█̷̢̛̩̻̙̩̟̬͍̼̩̹̬̄̒̈́͊̒̓̆̀͐͐͊̌̐̆̕̚̚͝͝ͅ",
      "Haha... funny error",
      "He’s in the blocks. In between.",
      "あなたはまだ生きてる？",
      "҉W҉H҉E҉R҉E҉ ̵͙̥͎̙̘̯̺̲͎̘̲̹̬̗̜͊̓͊͋͂̋̍͝I̵͔̗̖͙͈̯͖̲̤͓͇͈̠̞͐͑̈́̀͂͆̆̈͝ͅȘ̶̠͔̞̲̜̓͑͂̈̿̈̕͠͠",
      "ココニイタハズ…",
      "Look behind you",
      "W̵͖̳̬͎̻̝͌̅̉͋͐̓̓͐̀̋̈́̕͝͝H̴͎͎͎̪̙͖̖͖͉͉̮̬̺̿̋͌̓̋̎͒̆͘͜͜ͅA̷̛͎̦͍̺͉͓̐͒̎̋́̿̐͘̚̚͠T̵̡̛̜̳̮̹̰̞̾̅̒̓̐̿̚͝",
      "He glitch3d me :)",
      "こんなはずじゃなかった",
      "█████████"
   );

   @SubscribeEvent
   public static void onWorldTick(LevelTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.level);
      }
   }

   public static void execute(LevelAccessor world) {
      execute(null, world);
   }

   private static void execute(@Nullable Event event, LevelAccessor world) {
      if (InsideTheSystemModVariables.MapVariables.get(world).eventfollover) {
         long currentTick = world.m_8044_();
         if (currentTick - lastTick >= 500L) {
            lastTick = currentTick;
            Random random = new Random();
            String message = glitchedMessages.get(random.nextInt(glitchedMessages.size()));
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<???§k303§r> " + message), false);
            }
         }
      }
   }
}
