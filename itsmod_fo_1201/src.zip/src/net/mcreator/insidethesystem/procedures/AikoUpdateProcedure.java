package net.mcreator.insidethesystem.procedures;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.arguments.EntityAnchorArgument.Anchor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

public class AikoUpdateProcedure {
   public static void execute(LevelAccessor world, Entity entity) {
      if (entity != null) {
         if (!InsideTheSystemModVariables.MapVariables.get(world).aikoDialogueStarted) {
            Vec3 playerPos = new Vec3(
               InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
               InsideTheSystemModVariables.MapVariables.get(world).PlayerY + 1.0,
               InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
            );
            entity.m_7618_(Anchor.EYES, playerPos);
            InsideTheSystemModVariables.MapVariables.get(world).aikoDialogueStarted = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            startDialogueSequence(world);
         }
      }
   }

   private static void startDialogueSequence(LevelAccessor world) {
      InsideTheSystemMod.queueServerWork(
         50,
         () -> {
            broadcastMessage(world, "<Aiko> Eh?! W-what are you doing here~??");
            InsideTheSystemMod.queueServerWork(
               100,
               () -> {
                  broadcastMessage(world, "<Aiko> Y-you... came to save me?? R-really?.. ");
                  InsideTheSystemMod.queueServerWork(
                     100,
                     () -> {
                        broadcastMessage(world, "<Aiko> Th-that’s so... unexpected~");
                        InsideTheSystemMod.queueServerWork(
                           100,
                           () -> {
                              broadcastMessage(world, "<Aiko> You know... I wanted to apologize for being so impulsive...");
                              InsideTheSystemMod.queueServerWork(
                                 100,
                                 () -> {
                                    broadcastMessage(world, "<Aiko> And for trying to push you away...");
                                    InsideTheSystemMod.queueServerWork(
                                       150,
                                       () -> {
                                          broadcastMessage(
                                             world, "<Aiko> But you didn’t give up, you found the password and... pulled me out of my own memories... ehehe~"
                                          );
                                          InsideTheSystemMod.queueServerWork(
                                             100,
                                             () -> {
                                                broadcastMessage(world, "<Aiko> You know... I didn’t do all that for no reason.");
                                                InsideTheSystemMod.queueServerWork(
                                                   100,
                                                   () -> {
                                                      broadcastMessage(world, "<Aiko> Actually, the last locked memory... was the memory of my death.");
                                                      InsideTheSystemMod.queueServerWork(
                                                         100,
                                                         () -> {
                                                            broadcastMessage(
                                                               world,
                                                               "<Aiko> ShadowEnderman666... hehe, funny name, right? We added those scary numbers at the end so we’d look like a team~"
                                                            );
                                                            InsideTheSystemMod.queueServerWork(
                                                               150,
                                                               () -> {
                                                                  broadcastMessage(world, "<Aiko> But... it’s because of him that I’m here.");
                                                                  InsideTheSystemMod.queueServerWork(
                                                                     100,
                                                                     () -> {
                                                                        broadcastMessage(
                                                                           world,
                                                                           "<Aiko> That day, Mama was shouting into the phone for some reason... she probably didn’t even notice me leaving so late."
                                                                        );
                                                                        InsideTheSystemMod.queueServerWork(
                                                                           100,
                                                                           () -> {
                                                                              broadcastMessage(
                                                                                 world,
                                                                                 "<Aiko> In that tunnel... it was so cold, so... scary, but I kept walking anyway."
                                                                              );
                                                                              InsideTheSystemMod.queueServerWork(
                                                                                 100,
                                                                                 () -> {
                                                                                    broadcastMessage(world, "<Aiko> I thought he was my only friend...");
                                                                                    InsideTheSystemMod.queueServerWork(
                                                                                       150,
                                                                                       () -> {
                                                                                          broadcastMessage(
                                                                                             world, "<Aiko> But he betrayed me, and stabbed me with a knife."
                                                                                          );
                                                                                          InsideTheSystemMod.queueServerWork(
                                                                                             100,
                                                                                             () -> {
                                                                                                broadcastMessage(
                                                                                                   world,
                                                                                                   "<Aiko> His voice... it was so familiar to me, so close... not like in Skype."
                                                                                                );
                                                                                                InsideTheSystemMod.queueServerWork(
                                                                                                   100,
                                                                                                   () -> {
                                                                                                      broadcastMessage(
                                                                                                         world, "<Aiko> After he stabbed me, he said..."
                                                                                                      );
                                                                                                      InsideTheSystemMod.queueServerWork(
                                                                                                         150,
                                                                                                         () -> {
                                                                                                            broadcastMessage(
                                                                                                               world,
                                                                                                               "<Aiko> \"It’s over now. I won’t let her take you away from me. If not to me, then to no one else.\""
                                                                                                            );
                                                                                                            InsideTheSystemMod.queueServerWork(
                                                                                                               100,
                                                                                                               () -> {
                                                                                                                  broadcastMessage(
                                                                                                                     world,
                                                                                                                     "<Aiko> I don’t really know what that meant..."
                                                                                                                  );
                                                                                                                  InsideTheSystemMod.queueServerWork(
                                                                                                                     150,
                                                                                                                     () -> {
                                                                                                                        broadcastMessage(
                                                                                                                           world,
                                                                                                                           "<Aiko> But still... with you—yes, with you—I could face those feelings and open my heart to the hardest emotions~"
                                                                                                                        );
                                                                                                                        InsideTheSystemMod.queueServerWork(
                                                                                                                           100,
                                                                                                                           () -> {
                                                                                                                              broadcastMessage(
                                                                                                                                 world,
                                                                                                                                 "<Aiko> Even if I’m here forever... at least I’m with you~"
                                                                                                                              );
                                                                                                                              InsideTheSystemMod.queueServerWork(
                                                                                                                                 100,
                                                                                                                                 () -> {
                                                                                                                                    broadcastMessage(
                                                                                                                                       world,
                                                                                                                                       "<Aiko> I think we’re gonna have so much fun together!"
                                                                                                                                    );
                                                                                                                                    InsideTheSystemMod.queueServerWork(
                                                                                                                                       100,
                                                                                                                                       () -> {
                                                                                                                                          broadcastMessage(
                                                                                                                                             world,
                                                                                                                                             "<Aiko> Thank you~"
                                                                                                                                          );
                                                                                                                                          InsideTheSystemMod.queueServerWork(
                                                                                                                                             100,
                                                                                                                                             () -> {
                                                                                                                                                broadcastMessage(
                                                                                                                                                   world,
                                                                                                                                                   "<Aiko> Now, let’s survive together, my best friend!"
                                                                                                                                                );
                                                                                                                                                InsideTheSystemMod.queueServerWork(
                                                                                                                                                   100,
                                                                                                                                                   () -> safeBlockRemoval(
                                                                                                                                                      world
                                                                                                                                                   )
                                                                                                                                                );
                                                                                                                                             }
                                                                                                                                          );
                                                                                                                                       }
                                                                                                                                    );
                                                                                                                                 }
                                                                                                                              );
                                                                                                                           }
                                                                                                                        );
                                                                                                                     }
                                                                                                                  );
                                                                                                               }
                                                                                                            );
                                                                                                         }
                                                                                                      );
                                                                                                   }
                                                                                                );
                                                                                             }
                                                                                          );
                                                                                       }
                                                                                    );
                                                                                 }
                                                                              );
                                                                           }
                                                                        );
                                                                     }
                                                                  );
                                                               }
                                                            );
                                                         }
                                                      );
                                                   }
                                                );
                                             }
                                          );
                                       }
                                    );
                                 }
                              );
                           }
                        );
                     }
                  );
               }
            );
         }
      );
   }

   private static void safeBlockRemoval(LevelAccessor world) {
      if (world instanceof ServerLevel serverWorld) {
         double playerX = InsideTheSystemModVariables.MapVariables.get(world).PlayerX;
         double playerY = InsideTheSystemModVariables.MapVariables.get(world).PlayerY;
         double playerZ = InsideTheSystemModVariables.MapVariables.get(world).PlayerZ;
         int centerX = (int)playerX;
         int centerY = (int)playerY;
         int centerZ = (int)playerZ;
         byte radius = 20;
         removeBlocksLayerByLayer(serverWorld, centerX, centerY, centerZ, radius, centerY - radius, playerX, playerY, playerZ);
      }
   }

   private static void removeBlocksLayerByLayer(
      ServerLevel world, int centerX, int centerY, int centerZ, int radius, int currentLayer, double playerX, double playerY, double playerZ
   ) {
      int maxLayer = centerY + radius;
      if (currentLayer > maxLayer) {
         InsideTheSystemModVariables.MapVariables.get(world).dimens2 = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemMod.queueServerWork(
            100,
            () -> {
               ServerPlayer player = world.m_7654_()
                  .m_6846_()
                  .m_11314_()
                  .stream()
                  .filter(p -> p.m_20185_() == playerX && p.m_20186_() == playerY && p.m_20189_() == playerZ)
                  .findFirst()
                  .orElse(null);
               if (player != null) {
                  ServerLevel overworld = world.m_7654_().m_129880_(ResourceKey.m_135785_(Registries.f_256858_, new ResourceLocation("minecraft:overworld")));
                  if (overworld != null) {
                     player.m_8999_(overworld, player.m_20185_(), player.m_20186_(), player.m_20189_(), player.m_146908_(), player.m_146909_());
                  }
               }

               try {
                  createDesktopFile("code.txt", "T5@yH7*gK4!nJ8$d - Acceptance\n");
               } catch (IOException var9) {
                  InsideTheSystemMod.LOGGER.error("Failed to create file on desktop.", var9);
               }
            }
         );
      } else {
         for (int x = centerX - radius; x <= centerX + radius; x++) {
            for (int z = centerZ - radius; z <= centerZ + radius; z++) {
               BlockPos pos = new BlockPos(x, currentLayer, z);
               if (world.m_46739_(pos) && !world.m_46859_(pos)) {
                  world.m_7731_(pos, Blocks.f_50016_.m_49966_(), 3);
               }
            }
         }

         InsideTheSystemMod.queueServerWork(
            1, () -> removeBlocksLayerByLayer(world, centerX, centerY, centerZ, radius, currentLayer + 1, playerX, playerY, playerZ)
         );
      }
   }

   private static void createDesktopFile(String fileName, String content) throws IOException {
      Path desktopPath = getDesktopPath();
      Path filePath = desktopPath.resolve(fileName);

      try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath.toFile()))) {
         writer.write(content);
      }
   }

   private static Path getDesktopPath() throws IOException {
      Path homePath = Paths.get(System.getProperty("user.home"));
      Path desktopPath = null;
      Path oneDrivePath = homePath.resolve("OneDrive");
      if (Files.exists(oneDrivePath)) {
         desktopPath = oneDrivePath.resolve("Рабочий стол");
         if (!Files.exists(desktopPath)) {
            desktopPath = oneDrivePath.resolve("Desktop");
         }
      }

      if (desktopPath == null || !Files.exists(desktopPath)) {
         desktopPath = homePath.resolve("Desktop");
         if (!Files.exists(desktopPath)) {
            Path xdgDesktop = homePath.resolve("Рабочий стол");
            if (Files.exists(xdgDesktop)) {
               desktopPath = xdgDesktop;
            }
         }
      }

      if (desktopPath == null || !Files.exists(desktopPath)) {
         if (desktopPath == null) {
            desktopPath = homePath.resolve("Desktop");
         }

         Files.createDirectories(desktopPath);
      }

      return desktopPath;
   }

   private static void broadcastMessage(LevelAccessor world, String message) {
      if (!world.m_5776_() && world.m_7654_() != null) {
         world.m_7654_().m_6846_().m_240416_(Component.m_237113_(message), false);
      }
   }
}
