package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.init.InsideTheSystemModItems;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundGameEventPacket;
import net.minecraft.network.protocol.game.ClientboundLevelEventPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerAbilitiesPacket;
import net.minecraft.network.protocol.game.ClientboundUpdateMobEffectPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

public class DoorActivateProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (InsideTheSystemModVariables.MapVariables.get(world).endinga) {
            world.m_7731_(BlockPos.m_274561_(x, y, z), Blocks.f_50016_.m_49966_(), 3);
            world.m_7731_(BlockPos.m_274561_(x + 1.0, y, z), Blocks.f_50016_.m_49966_(), 3);
            world.m_7731_(BlockPos.m_274561_(x - 1.0, y, z), Blocks.f_50016_.m_49966_(), 3);
            world.m_7731_(BlockPos.m_274561_(x, y, z - 1.0), Blocks.f_50016_.m_49966_(), 3);
            world.m_7731_(BlockPos.m_274561_(x, y, z + 1.0), Blocks.f_50016_.m_49966_(), 3);
            if (world instanceof Level _level) {
               if (!_level.m_5776_()) {
                  _level.m_5594_(
                     null,
                     BlockPos.m_274561_(x, y, z),
                     (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:titles")),
                     SoundSource.NEUTRAL,
                     1.0F,
                     1.0F
                  );
               } else {
                  _level.m_7785_(
                     x,
                     y,
                     z,
                     (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:titles")),
                     SoundSource.NEUTRAL,
                     1.0F,
                     1.0F,
                     false
                  );
               }
            }

            InsideTheSystemMod.queueServerWork(
               10,
               () -> {
                  if (entity instanceof LivingEntity _entityxx && !_entityxx.m_9236_().m_5776_()) {
                     _entityxx.m_7292_(new MobEffectInstance(MobEffects.f_19597_, 9999, 20, false, false));
                  }

                  if (entity instanceof LivingEntity _entityx && !_entityx.m_9236_().m_5776_()) {
                     _entityx.m_7292_(new MobEffectInstance(MobEffects.f_19610_, 9999, 20, false, false));
                  }

                  InsideTheSystemMod.queueServerWork(
                     80,
                     () -> {
                        if (!world.m_5776_() && world.m_7654_() != null) {
                           world.m_7654_()
                              .m_6846_()
                              .m_240416_(Component.m_237113_("<Mom> Ah... Aiko... is it true...? Was he the one behind everything... all along...?"), false);
                        }

                        InsideTheSystemMod.queueServerWork(
                           80,
                           () -> {
                              if (!world.m_5776_() && world.m_7654_() != null) {
                                 world.m_7654_()
                                    .m_6846_()
                                    .m_240416_(Component.m_237113_("<Mom> How blind was I... how could I let it happen right before my eyes...!"), false);
                              }

                              InsideTheSystemMod.queueServerWork(
                                 80,
                                 () -> {
                                    if (!world.m_5776_() && world.m_7654_() != null) {
                                       world.m_7654_()
                                          .m_6846_()
                                          .m_240416_(Component.m_237113_("<Mom> Why... why didn’t I protect her... why didn’t I save my own child...!"), false);
                                    }

                                    InsideTheSystemMod.queueServerWork(
                                       600,
                                       () -> {
                                          if (world instanceof ServerLevel _levelx) {
                                             _levelx.m_7654_()
                                                .m_129892_()
                                                .m_230957_(
                                                   new CommandSourceStack(
                                                         CommandSource.f_80164_,
                                                         new Vec3(x, y, z),
                                                         Vec2.f_82462_,
                                                         _levelx,
                                                         4,
                                                         "",
                                                         Component.m_237113_(""),
                                                         _levelx.m_7654_(),
                                                         null
                                                      )
                                                      .m_81324_(),
                                                   "/title @a times 20 60 20"
                                                );
                                          }

                                          if (world instanceof ServerLevel _levelx) {
                                             _levelx.m_7654_()
                                                .m_129892_()
                                                .m_230957_(
                                                   new CommandSourceStack(
                                                         CommandSource.f_80164_,
                                                         new Vec3(x, y, z),
                                                         Vec2.f_82462_,
                                                         _levelx,
                                                         4,
                                                         "",
                                                         Component.m_237113_(""),
                                                         _levelx.m_7654_(),
                                                         null
                                                      )
                                                      .m_81324_(),
                                                   "/title @a subtitle {\"text\":\"The end\",\"italic\":true,\"color\":\"#DADADA\"}"
                                                );
                                          }

                                          if (world instanceof ServerLevel _levelx) {
                                             _levelx.m_7654_()
                                                .m_129892_()
                                                .m_230957_(
                                                   new CommandSourceStack(
                                                         CommandSource.f_80164_,
                                                         new Vec3(x, y, z),
                                                         Vec2.f_82462_,
                                                         _levelx,
                                                         4,
                                                         "",
                                                         Component.m_237113_(""),
                                                         _levelx.m_7654_(),
                                                         null
                                                      )
                                                      .m_81324_(),
                                                   "/title @a title {\"text\":\"Ending A\"}"
                                                );
                                          }

                                          InsideTheSystemMod.queueServerWork(
                                             100,
                                             () -> {
                                                if (world instanceof ServerLevel _levelxx) {
                                                   _levelxx.m_7654_()
                                                      .m_129892_()
                                                      .m_230957_(
                                                         new CommandSourceStack(
                                                               CommandSource.f_80164_,
                                                               new Vec3(x, y, z),
                                                               Vec2.f_82462_,
                                                               _levelxx,
                                                               4,
                                                               "",
                                                               Component.m_237113_(""),
                                                               _levelxx.m_7654_(),
                                                               null
                                                            )
                                                            .m_81324_(),
                                                         "/title @a times 20 60 20"
                                                      );
                                                }

                                                if (world instanceof ServerLevel _levelx) {
                                                   _levelx.m_7654_()
                                                      .m_129892_()
                                                      .m_230957_(
                                                         new CommandSourceStack(
                                                               CommandSource.f_80164_,
                                                               new Vec3(x, y, z),
                                                               Vec2.f_82462_,
                                                               _levelx,
                                                               4,
                                                               "",
                                                               Component.m_237113_(""),
                                                               _levelx.m_7654_(),
                                                               null
                                                            )
                                                            .m_81324_(),
                                                         "/title @a title {\"text\":\"Mod author DregIr\"}"
                                                      );
                                                }

                                                InsideTheSystemMod.queueServerWork(
                                                   100,
                                                   () -> {
                                                      if (world instanceof ServerLevel _levelxxxx) {
                                                         _levelxxxx.m_7654_()
                                                            .m_129892_()
                                                            .m_230957_(
                                                               new CommandSourceStack(
                                                                     CommandSource.f_80164_,
                                                                     new Vec3(x, y, z),
                                                                     Vec2.f_82462_,
                                                                     _levelxxxx,
                                                                     4,
                                                                     "",
                                                                     Component.m_237113_(""),
                                                                     _levelxxxx.m_7654_(),
                                                                     null
                                                                  )
                                                                  .m_81324_(),
                                                               "/title @a times 20 60 20"
                                                            );
                                                      }

                                                      if (world instanceof ServerLevel _levelxxx) {
                                                         _levelxxx.m_7654_()
                                                            .m_129892_()
                                                            .m_230957_(
                                                               new CommandSourceStack(
                                                                     CommandSource.f_80164_,
                                                                     new Vec3(x, y, z),
                                                                     Vec2.f_82462_,
                                                                     _levelxxx,
                                                                     4,
                                                                     "",
                                                                     Component.m_237113_(""),
                                                                     _levelxxx.m_7654_(),
                                                                     null
                                                                  )
                                                                  .m_81324_(),
                                                               "/title @a title {\"text\":Long two months..\"}"
                                                            );
                                                      }

                                                      InsideTheSystemMod.queueServerWork(
                                                         100,
                                                         () -> {
                                                            if (world instanceof ServerLevel _levelxxxxxx) {
                                                               _levelxxxxxx.m_7654_()
                                                                  .m_129892_()
                                                                  .m_230957_(
                                                                     new CommandSourceStack(
                                                                           CommandSource.f_80164_,
                                                                           new Vec3(x, y, z),
                                                                           Vec2.f_82462_,
                                                                           _levelxxxxxx,
                                                                           4,
                                                                           "",
                                                                           Component.m_237113_(""),
                                                                           _levelxxxxxx.m_7654_(),
                                                                           null
                                                                        )
                                                                        .m_81324_(),
                                                                     "/title @a times 20 60 20"
                                                                  );
                                                            }

                                                            if (world instanceof ServerLevel _levelxxxxx) {
                                                               _levelxxxxx.m_7654_()
                                                                  .m_129892_()
                                                                  .m_230957_(
                                                                     new CommandSourceStack(
                                                                           CommandSource.f_80164_,
                                                                           new Vec3(x, y, z),
                                                                           Vec2.f_82462_,
                                                                           _levelxxxxx,
                                                                           4,
                                                                           "",
                                                                           Component.m_237113_(""),
                                                                           _levelxxxxx.m_7654_(),
                                                                           null
                                                                        )
                                                                        .m_81324_(),
                                                                     "/title @a title {\"text\":\"Special thanks to:\"}"
                                                                  );
                                                            }

                                                            InsideTheSystemMod.queueServerWork(
                                                               100,
                                                               () -> {
                                                                  if (world instanceof ServerLevel _levelxxxxxxxx) {
                                                                     _levelxxxxxxxx.m_7654_()
                                                                        .m_129892_()
                                                                        .m_230957_(
                                                                           new CommandSourceStack(
                                                                                 CommandSource.f_80164_,
                                                                                 new Vec3(x, y, z),
                                                                                 Vec2.f_82462_,
                                                                                 _levelxxxxxxxx,
                                                                                 4,
                                                                                 "",
                                                                                 Component.m_237113_(""),
                                                                                 _levelxxxxxxxx.m_7654_(),
                                                                                 null
                                                                              )
                                                                              .m_81324_(),
                                                                           "/title @a times 20 60 20"
                                                                        );
                                                                  }

                                                                  if (world instanceof ServerLevel _levelxxxxxxx) {
                                                                     _levelxxxxxxx.m_7654_()
                                                                        .m_129892_()
                                                                        .m_230957_(
                                                                           new CommandSourceStack(
                                                                                 CommandSource.f_80164_,
                                                                                 new Vec3(x, y, z),
                                                                                 Vec2.f_82462_,
                                                                                 _levelxxxxxxx,
                                                                                 4,
                                                                                 "",
                                                                                 Component.m_237113_(""),
                                                                                 _levelxxxxxxx.m_7654_(),
                                                                                 null
                                                                              )
                                                                              .m_81324_(),
                                                                           "/title @a title {\"text\":\"NeoKefus\"}"
                                                                        );
                                                                  }

                                                                  InsideTheSystemMod.queueServerWork(
                                                                     100,
                                                                     () -> {
                                                                        if (world instanceof ServerLevel _levelxxxxxxxxxx) {
                                                                           _levelxxxxxxxxxx.m_7654_()
                                                                              .m_129892_()
                                                                              .m_230957_(
                                                                                 new CommandSourceStack(
                                                                                       CommandSource.f_80164_,
                                                                                       new Vec3(x, y, z),
                                                                                       Vec2.f_82462_,
                                                                                       _levelxxxxxxxxxx,
                                                                                       4,
                                                                                       "",
                                                                                       Component.m_237113_(""),
                                                                                       _levelxxxxxxxxxx.m_7654_(),
                                                                                       null
                                                                                    )
                                                                                    .m_81324_(),
                                                                                 "/title @a times 20 60 20"
                                                                              );
                                                                        }

                                                                        if (world instanceof ServerLevel _levelxxxxxxxxx) {
                                                                           _levelxxxxxxxxx.m_7654_()
                                                                              .m_129892_()
                                                                              .m_230957_(
                                                                                 new CommandSourceStack(
                                                                                       CommandSource.f_80164_,
                                                                                       new Vec3(x, y, z),
                                                                                       Vec2.f_82462_,
                                                                                       _levelxxxxxxxxx,
                                                                                       4,
                                                                                       "",
                                                                                       Component.m_237113_(""),
                                                                                       _levelxxxxxxxxx.m_7654_(),
                                                                                       null
                                                                                    )
                                                                                    .m_81324_(),
                                                                                 "/title @a title {\"text\":\"Itszhaba\"}"
                                                                              );
                                                                        }

                                                                        InsideTheSystemMod.queueServerWork(
                                                                           100,
                                                                           () -> {
                                                                              if (world instanceof ServerLevel _levelxxxxxxxxxxxx) {
                                                                                 _levelxxxxxxxxxxxx.m_7654_()
                                                                                    .m_129892_()
                                                                                    .m_230957_(
                                                                                       new CommandSourceStack(
                                                                                             CommandSource.f_80164_,
                                                                                             new Vec3(x, y, z),
                                                                                             Vec2.f_82462_,
                                                                                             _levelxxxxxxxxxxxx,
                                                                                             4,
                                                                                             "",
                                                                                             Component.m_237113_(""),
                                                                                             _levelxxxxxxxxxxxx.m_7654_(),
                                                                                             null
                                                                                          )
                                                                                          .m_81324_(),
                                                                                       "/title @a times 20 60 20"
                                                                                    );
                                                                              }

                                                                              if (world instanceof ServerLevel _levelxxxxxxxxxxx) {
                                                                                 _levelxxxxxxxxxxx.m_7654_()
                                                                                    .m_129892_()
                                                                                    .m_230957_(
                                                                                       new CommandSourceStack(
                                                                                             CommandSource.f_80164_,
                                                                                             new Vec3(x, y, z),
                                                                                             Vec2.f_82462_,
                                                                                             _levelxxxxxxxxxxx,
                                                                                             4,
                                                                                             "",
                                                                                             Component.m_237113_(""),
                                                                                             _levelxxxxxxxxxxx.m_7654_(),
                                                                                             null
                                                                                          )
                                                                                          .m_81324_(),
                                                                                       "/title @a title {\"text\":\"Martshet\"}"
                                                                                    );
                                                                              }

                                                                              InsideTheSystemMod.queueServerWork(
                                                                                 100,
                                                                                 () -> {
                                                                                    if (world instanceof ServerLevel _levelxxxxxxxxxxxxxx) {
                                                                                       _levelxxxxxxxxxxxxxx.m_7654_()
                                                                                          .m_129892_()
                                                                                          .m_230957_(
                                                                                             new CommandSourceStack(
                                                                                                   CommandSource.f_80164_,
                                                                                                   new Vec3(x, y, z),
                                                                                                   Vec2.f_82462_,
                                                                                                   _levelxxxxxxxxxxxxxx,
                                                                                                   4,
                                                                                                   "",
                                                                                                   Component.m_237113_(""),
                                                                                                   _levelxxxxxxxxxxxxxx.m_7654_(),
                                                                                                   null
                                                                                                )
                                                                                                .m_81324_(),
                                                                                             "/title @a times 20 60 20"
                                                                                          );
                                                                                    }

                                                                                    if (world instanceof ServerLevel _levelxxxxxxxxxxxxx) {
                                                                                       _levelxxxxxxxxxxxxx.m_7654_()
                                                                                          .m_129892_()
                                                                                          .m_230957_(
                                                                                             new CommandSourceStack(
                                                                                                   CommandSource.f_80164_,
                                                                                                   new Vec3(x, y, z),
                                                                                                   Vec2.f_82462_,
                                                                                                   _levelxxxxxxxxxxxxx,
                                                                                                   4,
                                                                                                   "",
                                                                                                   Component.m_237113_(""),
                                                                                                   _levelxxxxxxxxxxxxx.m_7654_(),
                                                                                                   null
                                                                                                )
                                                                                                .m_81324_(),
                                                                                             "/title @a title {\"text\":\"And all creators\"}"
                                                                                          );
                                                                                    }

                                                                                    InsideTheSystemMod.queueServerWork(
                                                                                       100,
                                                                                       () -> {
                                                                                          if (world instanceof ServerLevel _levelxxxxxxxxxxxxxxxx) {
                                                                                             _levelxxxxxxxxxxxxxxxx.m_7654_()
                                                                                                .m_129892_()
                                                                                                .m_230957_(
                                                                                                   new CommandSourceStack(
                                                                                                         CommandSource.f_80164_,
                                                                                                         new Vec3(x, y, z),
                                                                                                         Vec2.f_82462_,
                                                                                                         _levelxxxxxxxxxxxxxxxx,
                                                                                                         4,
                                                                                                         "",
                                                                                                         Component.m_237113_(""),
                                                                                                         _levelxxxxxxxxxxxxxxxx.m_7654_(),
                                                                                                         null
                                                                                                      )
                                                                                                      .m_81324_(),
                                                                                                   "/title @a times 20 60 20"
                                                                                                );
                                                                                          }

                                                                                          if (world instanceof ServerLevel _levelxxxxxxxxxxxxxxx) {
                                                                                             _levelxxxxxxxxxxxxxxx.m_7654_()
                                                                                                .m_129892_()
                                                                                                .m_230957_(
                                                                                                   new CommandSourceStack(
                                                                                                         CommandSource.f_80164_,
                                                                                                         new Vec3(x, y, z),
                                                                                                         Vec2.f_82462_,
                                                                                                         _levelxxxxxxxxxxxxxxx,
                                                                                                         4,
                                                                                                         "",
                                                                                                         Component.m_237113_(""),
                                                                                                         _levelxxxxxxxxxxxxxxx.m_7654_(),
                                                                                                         null
                                                                                                      )
                                                                                                      .m_81324_(),
                                                                                                   "/title @a title {\"text\":\"Especially Vix\"}"
                                                                                                );
                                                                                          }

                                                                                          InsideTheSystemMod.queueServerWork(
                                                                                             100,
                                                                                             () -> {
                                                                                                if (world instanceof ServerLevel _levelxxxxxxxxxxxxxxxxxx) {
                                                                                                   _levelxxxxxxxxxxxxxxxxxx.m_7654_()
                                                                                                      .m_129892_()
                                                                                                      .m_230957_(
                                                                                                         new CommandSourceStack(
                                                                                                               CommandSource.f_80164_,
                                                                                                               new Vec3(x, y, z),
                                                                                                               Vec2.f_82462_,
                                                                                                               _levelxxxxxxxxxxxxxxxxxx,
                                                                                                               4,
                                                                                                               "",
                                                                                                               Component.m_237113_(""),
                                                                                                               _levelxxxxxxxxxxxxxxxxxx.m_7654_(),
                                                                                                               null
                                                                                                            )
                                                                                                            .m_81324_(),
                                                                                                         "/title @a times 20 60 20"
                                                                                                      );
                                                                                                }

                                                                                                if (world instanceof ServerLevel _levelxxxxxxxxxxxxxxxxx) {
                                                                                                   _levelxxxxxxxxxxxxxxxxx.m_7654_()
                                                                                                      .m_129892_()
                                                                                                      .m_230957_(
                                                                                                         new CommandSourceStack(
                                                                                                               CommandSource.f_80164_,
                                                                                                               new Vec3(x, y, z),
                                                                                                               Vec2.f_82462_,
                                                                                                               _levelxxxxxxxxxxxxxxxxx,
                                                                                                               4,
                                                                                                               "",
                                                                                                               Component.m_237113_(""),
                                                                                                               _levelxxxxxxxxxxxxxxxxx.m_7654_(),
                                                                                                               null
                                                                                                            )
                                                                                                            .m_81324_(),
                                                                                                         "/title @a title {\"text\":\"Thank you for playing\"}"
                                                                                                      );
                                                                                                }
                                                                                             }
                                                                                          );
                                                                                       }
                                                                                    );
                                                                                 }
                                                                              );
                                                                           }
                                                                        );
                                                                     }
                                                                  );
                                                               }
                                                            );
                                                         }
                                                      );
                                                   }
                                                );
                                             }
                                          );
                                       }
                                    );
                                 }
                              );
                           }
                        );
                     }
                  );
               }
            );
         } else {
            world.m_46961_(
               BlockPos.m_274561_(
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerY - 1.0,
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
               ),
               false
            );
            world.m_46961_(
               BlockPos.m_274561_(
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerY - 2.0,
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
               ),
               false
            );
            world.m_46961_(
               BlockPos.m_274561_(
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerY - 3.0,
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
               ),
               false
            );
            if (entity instanceof LivingEntity _entity) {
               _entity.m_21195_(MobEffects.f_19591_);
            }

            InsideTheSystemMod.queueServerWork(
               40,
               () -> {
                  if (entity instanceof Player _playerHasItem
                     && _playerHasItem.m_150109_().m_36063_(new ItemStack((ItemLike)InsideTheSystemModItems.STAROF_MEMORIES.get()))) {
                     if (!world.m_5776_() && world.m_7654_() != null) {
                        world.m_7654_().m_6846_().m_240416_(Component.m_237113_("The story begins now..."), false);
                     }

                     InsideTheSystemModVariables.MapVariables.get(world).endinga = true;
                     InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
                     if (entity instanceof ServerPlayer _player && !_player.m_9236_().m_5776_()) {
                        ResourceKey<Level> destinationType = ResourceKey.m_135785_(Registries.f_256858_, new ResourceLocation("inside_the_system:home"));
                        if (_player.m_9236_().m_46472_() == destinationType) {
                           return;
                        }

                        ServerLevel nextLevel = _player.f_8924_.m_129880_(destinationType);
                        if (nextLevel != null) {
                           _player.f_8906_.m_9829_(new ClientboundGameEventPacket(ClientboundGameEventPacket.f_132157_, 0.0F));
                           _player.m_8999_(nextLevel, _player.m_20185_(), _player.m_20186_(), _player.m_20189_(), _player.m_146908_(), _player.m_146909_());
                           _player.f_8906_.m_9829_(new ClientboundPlayerAbilitiesPacket(_player.m_150110_()));

                           for (MobEffectInstance _effectinstance : _player.m_21220_()) {
                              _player.f_8906_.m_9829_(new ClientboundUpdateMobEffectPacket(_player.m_19879_(), _effectinstance));
                           }

                           _player.f_8906_.m_9829_(new ClientboundLevelEventPacket(1032, BlockPos.f_121853_, 0, false));
                        }
                     }
                  } else {
                     if (!world.m_5776_() && world.m_7654_() != null) {
                        world.m_7654_().m_6846_().m_240416_(Component.m_237113_("That's the end of the story..."), false);
                     }

                     if (entity instanceof ServerPlayer _player && !_player.m_9236_().m_5776_()) {
                        ResourceKey<Level> destinationTypex = ResourceKey.m_135785_(Registries.f_256858_, new ResourceLocation("inside_the_system:home"));
                        if (_player.m_9236_().m_46472_() == destinationTypex) {
                           return;
                        }

                        ServerLevel nextLevel = _player.f_8924_.m_129880_(destinationTypex);
                        if (nextLevel != null) {
                           _player.f_8906_.m_9829_(new ClientboundGameEventPacket(ClientboundGameEventPacket.f_132157_, 0.0F));
                           _player.m_8999_(nextLevel, _player.m_20185_(), _player.m_20186_(), _player.m_20189_(), _player.m_146908_(), _player.m_146909_());
                           _player.f_8906_.m_9829_(new ClientboundPlayerAbilitiesPacket(_player.m_150110_()));

                           for (MobEffectInstance _effectinstance : _player.m_21220_()) {
                              _player.f_8906_.m_9829_(new ClientboundUpdateMobEffectPacket(_player.m_19879_(), _effectinstance));
                           }

                           _player.f_8906_.m_9829_(new ClientboundLevelEventPacket(1032, BlockPos.f_121853_, 0, false));
                        }
                     }
                  }
               }
            );
         }
      }
   }
}
