package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.init.InsideTheSystemModEntities;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;

public class EnterProcedure {
   public static void execute(LevelAccessor world, Entity entity) {
      if (entity != null) {
         if (world instanceof ServerLevel _serverworld) {
            StructureTemplate template = _serverworld.m_215082_().m_230359_(new ResourceLocation("inside_the_system", "parkour"));
            if (template != null) {
               template.m_230328_(
                  _serverworld,
                  new BlockPos(10, 10, 10),
                  new BlockPos(10, 10, 10),
                  new StructurePlaceSettings().m_74379_(Rotation.NONE).m_74377_(Mirror.NONE).m_74392_(false),
                  _serverworld.f_46441_,
                  3
               );
            }
         }

         entity.m_6021_(44.0, 12.0, 13.0);
         if (entity instanceof ServerPlayer _serverPlayer) {
            _serverPlayer.f_8906_.m_9774_(44.0, 12.0, 13.0, entity.m_146908_(), entity.m_146909_());
         }

         if (world instanceof ServerLevel _level) {
            _level.m_7654_()
               .m_129892_()
               .m_230957_(
                  new CommandSourceStack(
                        CommandSource.f_80164_, new Vec3(44.0, 12.0, 13.0), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                     )
                     .m_81324_(),
                  "spawnpoint @a"
               );
         }

         InsideTheSystemModVariables.MapVariables.get(world).buildblock = false;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         if (!InsideTheSystemModVariables.MapVariables.get(world).Spawnlost) {
            if (world instanceof ServerLevel _level) {
               Entity entityToSpawn = ((EntityType)InsideTheSystemModEntities.LOST.get())
                  .m_262496_(_level, new BlockPos(25, 37, 13), MobSpawnType.MOB_SUMMONED);
               if (entityToSpawn != null) {
                  entityToSpawn.m_146922_(world.m_213780_().m_188501_() * 360.0F);
               }
            }

            InsideTheSystemModVariables.MapVariables.get(world).Spawnlost = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }
      }
   }
}
