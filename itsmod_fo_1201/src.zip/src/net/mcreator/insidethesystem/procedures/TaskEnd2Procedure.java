package net.mcreator.insidethesystem.procedures;

import java.io.IOException;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class TaskEnd2Procedure {
   private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(10);
   private static final Random random = new Random();

   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_());
      }
   }

   public static void execute(LevelAccessor world) {
      execute(null, world);
   }

   private static void execute(@Nullable Event event, LevelAccessor world) {
      if (InsideTheSystemModVariables.MapVariables.get(world).TaskEnd2) {
         if (!world.m_5776_() && world.m_7654_() != null) {
            world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> Hey..."), false);
         }

         InsideTheSystemMod.queueServerWork(80, () -> {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> Something… not… good… my head… "), false);
            }

            InsideTheSystemMod.queueServerWork(80, () -> {
               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> I… like thoughts… disappearing… "), false);
               }

               InsideTheSystemMod.queueServerWork(80, () -> {
                  if (!world.m_5776_() && world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> Argh… help me… find last bits… memory… "), false);
                  }

                  InsideTheSystemMod.queueServerWork(80, () -> {
                     if (!world.m_5776_() && world.m_7654_() != null) {
                        world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> aыv… brk…"), false);
                     }

                     InsideTheSystemMod.queueServerWork(80, () -> {
                        if (!world.m_5776_() && world.m_7654_() != null) {
                           world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> どこに行けば……? "), false);
                        }

                        InsideTheSystemMod.queueServerWork(100, () -> executeHorrorSequence());
                     });
                  });
               });
            });
         });
         InsideTheSystemModVariables.MapVariables.get(world).TaskEnd2 = false;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }
   }

   private static void executeHorrorSequence() {
      try {
         minimizeAllWindows();
         InsideTheSystemMod.queueServerWork(60, () -> {
            startVoiceSequence();
            InsideTheSystemMod.queueServerWork(2400, () -> showSystemRestoreNotification());
         });
      } catch (IOException var1) {
         var1.printStackTrace();
      }
   }

   private static void minimizeAllWindows() throws IOException {
      String minimizeCommand = "Add-Type -AssemblyName Microsoft.VisualBasic; [Microsoft.VisualBasic.Interaction]::AppActivate('Program Manager'); Start-Sleep -Milliseconds 100; Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('{LWIN}d')";
      Runtime.getRuntime().exec("powershell -WindowStyle Hidden -command \"" + minimizeCommand + "\"");
   }

   private static void startVoiceSequence() {
      try {
         String firstVoiceCommand = "Add-Type -AssemblyName System.Speech; $voice = New-Object System.Speech.Synthesis.SpeechSynthesizer; $voice.SelectVoiceByHints('Female'); $voice.Rate = -3; $voice.Volume = 100; $voice.Speak('Can you hear me?'); Start-Sleep -Seconds 3; $voice.Speak('Can you see me?'); $voice.Dispose()";
         Runtime.getRuntime().exec("powershell -WindowStyle Hidden -command \"" + firstVoiceCommand + "\"");
         InsideTheSystemMod.queueServerWork(200, () -> startJapaneseVoiceSequence());
      } catch (IOException var1) {
         var1.printStackTrace();
      }
   }

   private static void startJapaneseVoiceSequence() {
      try {
         String japaneseVoiceCommand = "Add-Type -AssemblyName System.Speech; $voice = New-Object System.Speech.Synthesis.SpeechSynthesizer; try {     $voice.SelectVoiceByHints('Female'); } catch {     $voice.SelectVoice($voice.GetInstalledVoices()[0].VoiceInfo.Name); } $voice.Rate = -4; $voice.Volume = 100; Start-Sleep -Seconds 2; $voice.Speak('Watashi wa... anata no kokoro no naka ni iru'); Start-Sleep -Seconds 4; $voice.Speak('Anata no tamashii wa... watashi no mono'); Start-Sleep -Seconds 4; $voice.Speak('Nigeru koto wa... dekinai'); Start-Sleep -Seconds 4; $voice.Speak('Watashi to... issho ni ite'); Start-Sleep -Seconds 3; $voice.Rate = -6; $voice.Speak('Eien ni...'); $voice.Dispose()";
         Runtime.getRuntime().exec("powershell -WindowStyle Hidden -command \"" + japaneseVoiceCommand + "\"");
         showHorrorVisuals();
      } catch (IOException var1) {
         var1.printStackTrace();
      }
   }

   private static void showHorrorVisuals() {
      try {
         String horrorWindowCommand = "Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; $form = New-Object System.Windows.Forms.Form; $form.Text = ''; $form.Size = New-Object System.Drawing.Size(600, 400); $form.StartPosition = 'CenterScreen'; $form.TopMost = $true; $form.BackColor = 'Black'; $form.ForeColor = 'Red'; $form.FormBorderStyle = 'None'; $form.WindowState = 'Maximized'; $label = New-Object System.Windows.Forms.Label; $label.Text = '私はあなたを見ています`n`n私はあなたを知っています`n`n私はあなたの中にいます`n`nあなたは逃げることはできません`n`n私と一緒にいてください`n`n永遠に...'; $label.Font = New-Object System.Drawing.Font('MS Gothic', 32, [System.Drawing.FontStyle]::Bold); $label.Dock = 'Fill'; $label.TextAlign = 'MiddleCenter'; $form.Controls.Add($label); $timer = New-Object System.Windows.Forms.Timer; $timer.Interval = 300; $visible = $true; $timer.Add_Tick({     $visible = -not $visible;     if ($visible) {         $form.BackColor = 'Black';         $label.ForeColor = 'Red';     } else {         $form.BackColor = 'DarkRed';         $label.ForeColor = 'White';     } }); $timer.Start(); $closeTimer = New-Object System.Windows.Forms.Timer; $closeTimer.Interval = 90000; $closeTimer.Add_Tick({     $timer.Stop();     $timer.Dispose();     $closeTimer.Stop();     $closeTimer.Dispose();     $form.Close(); }); $closeTimer.Start(); $form.Add_KeyDown({     if ($_.KeyCode -eq 'Escape') {         $timer.Stop();         $timer.Dispose();         $closeTimer.Stop();         $closeTimer.Dispose();         $form.Close();     } }); $form.KeyPreview = $true; $form.ShowDialog(); $form.Dispose()";
         Runtime.getRuntime().exec("powershell -command \"" + horrorWindowCommand + "\"");
      } catch (IOException var1) {
         var1.printStackTrace();
      }
   }

   private static void showSystemRestoreNotification() {
      try {
         String restoreNotificationCommand = "Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; $form = New-Object System.Windows.Forms.Form; $form.Text = 'System Recovery Alert'; $form.Size = New-Object System.Drawing.Size(500, 280); $form.StartPosition = 'CenterScreen'; $form.TopMost = $true; $form.BackColor = 'DarkBlue'; $form.ForeColor = 'White'; $form.FormBorderStyle = 'FixedDialog'; $form.MaximizeBox = $false; $form.MinimizeBox = $false; $titleLabel = New-Object System.Windows.Forms.Label; $titleLabel.Text = '⚠️ PARANORMAL ACTIVITY DETECTED ⚠️'; $titleLabel.Font = New-Object System.Drawing.Font('Arial', 14, [System.Drawing.FontStyle]::Bold); $titleLabel.ForeColor = 'Yellow'; $titleLabel.AutoSize = $true; $titleLabel.Location = New-Object System.Drawing.Point(60, 20); $form.Controls.Add($titleLabel); $messageLabel = New-Object System.Windows.Forms.Label; $messageLabel.Text = 'Unusual supernatural activity has been detected on your system.`n`nAn unknown entity attempted to communicate through your speakers.`n`nYour system has been isolated from the entity.`n`nClick PURIFY to cleanse your system and restore normal operation.`n`nDo not ignore this warning.'; $messageLabel.Font = New-Object System.Drawing.Font('Arial', 10); $messageLabel.Size = New-Object System.Drawing.Size(460, 140); $messageLabel.Location = New-Object System.Drawing.Point(20, 60); $form.Controls.Add($messageLabel); $purifyButton = New-Object System.Windows.Forms.Button; $purifyButton.Text = '✨ PURIFY SYSTEM'; $purifyButton.Size = New-Object System.Drawing.Size(150, 40); $purifyButton.Location = New-Object System.Drawing.Point(100, 210); $purifyButton.BackColor = 'Purple'; $purifyButton.ForeColor = 'White'; $purifyButton.Font = New-Object System.Drawing.Font('Arial', 10, [System.Drawing.FontStyle]::Bold); $purifyButton.Add_Click({     $form.Hide();     $progressForm = New-Object System.Windows.Forms.Form;     $progressForm.Text = 'Purifying System...';     $progressForm.Size = New-Object System.Drawing.Size(400, 120);     $progressForm.StartPosition = 'CenterScreen'; $progressForm.TopMost = $true;     $progressForm.BackColor = 'Purple';     $progressForm.ForeColor = 'White';     $progressForm.FormBorderStyle = 'FixedDialog';     $progressForm.MaximizeBox = $false;     $progressForm.MinimizeBox = $false;         $progressLabel = New-Object System.Windows.Forms.Label;     $progressLabel.Text = 'Banishing supernatural entities...';     $progressLabel.Location = New-Object System.Drawing.Point(20, 20);     $progressLabel.Size = New-Object System.Drawing.Size(350, 20);     $progressLabel.ForeColor = 'White';     $progressForm.Controls.Add($progressLabel);         $progressBar = New-Object System.Windows.Forms.ProgressBar;     $progressBar.Location = New-Object System.Drawing.Point(20, 50);     $progressBar.Size = New-Object System.Drawing.Size(350, 20);     $progressBar.Style = 'Continuous';     $progressForm.Controls.Add($progressBar);         $progressForm.Show();         for($i=0; $i -le 100; $i+=5) {         $progressBar.Value = $i;         Start-Sleep -Milliseconds 150;         $progressForm.Refresh();     }         $progressForm.Close();     $progressForm.Dispose();         Get-Process | Where-Object {$_.ProcessName -like '*powershell*'} | Where-Object {$_.CommandLine -like '*Speech*'} | Stop-Process -Force -ErrorAction SilentlyContinue;         [System.Windows.Forms.MessageBox]::Show('System has been successfully purified.`n`nAll supernatural entities have been banished.`n`nYour system is now safe and protected.`n`nRecommendation: Avoid playing horror games late at night.', 'System Purified', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information);     $form.Close(); }); $form.Controls.Add($purifyButton); $ignoreButton = New-Object System.Windows.Forms.Button; $ignoreButton.Text = '\ud83d\udc7b IGNORE'; $ignoreButton.Size = New-Object System.Drawing.Size(120, 40); $ignoreButton.Location = New-Object System.Drawing.Point(270, 210); $ignoreButton.BackColor = 'DarkRed'; $ignoreButton.ForeColor = 'White'; $ignoreButton.Font = New-Object System.Drawing.Font('Arial', 10, [System.Drawing.FontStyle]::Bold); $ignoreButton.Add_Click({ $form.Close() }); $form.Controls.Add($ignoreButton); $form.ShowDialog(); $form.Dispose()";
         Runtime.getRuntime().exec("powershell -command \"" + restoreNotificationCommand + "\"");
      } catch (IOException var1) {
         var1.printStackTrace();
      }
   }
}
