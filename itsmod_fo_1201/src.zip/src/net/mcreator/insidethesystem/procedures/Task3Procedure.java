package net.mcreator.insidethesystem.procedures;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class Task3Procedure {
   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_());
      }
   }

   public static void execute(LevelAccessor world) {
      execute(null, world);
   }

   private static void execute(@Nullable Event event, LevelAccessor world) {
      if (InsideTheSystemModVariables.MapVariables.get(world).Task3) {
         if (!world.m_5776_() && world.m_7654_() != null) {
            world.m_7654_().m_6846_().m_240416_(Component.m_237113_("RUN"), false);
            executeLoadingSequence(world);
         }

         InsideTheSystemModVariables.MapVariables.get(world).Task3 = false;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }
   }

   private static void executeLoadingSequence(LevelAccessor world) {
      ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
      List<Runnable> sequence = new ArrayList<>();
      sequence.add(() -> sendMessage(world, "INTRODUCTION TO THE SYSTEM"));
      sequence.add(() -> sendMessage(world, "Python 3.11.4 (main, Jul 5 2023, 13:45:01) [MSC v.1916 64 bit (AMD64)]"));
      sequence.add(() -> sendMessage(world, ">>> import sys"));
      sequence.add(() -> sendMessage(world, ">>> import numpy as np"));
      sequence.add(() -> sendMessage(world, "Collecting numpy==1.24.3"));
      sequence.add(() -> sendMessage(world, " Downloading numpy-1.24.3-cp311-cp311-win_amd64.whl (14.8 MB)"));
      sequence.add(() -> sendMessage(world, " ████████████████████████████████ 14.8/14.8 MB 2.1 MB/s eta 0:00:00"));
      sequence.add(() -> sendMessage(world, "Successfully installed numpy-1.24.3"));
      sequence.add(() -> sendMessage(world, ">>> import pandas as pd"));
      sequence.add(() -> sendMessage(world, "Collecting pandas==2.0.3"));
      sequence.add(() -> sendMessage(world, " Downloading pandas-2.0.3-cp311-cp311-win_amd64.whl (11.6 MB)"));
      sequence.add(() -> sendMessage(world, " ████████████████████████████████ 11.6/11.6 MB 1.8 MB/s eta 0:00:00"));
      sequence.add(() -> sendMessage(world, "Successfully installed pandas-2.0.3"));
      sequence.add(() -> sendMessage(world, ">>> import tensorflow as tf"));
      sequence.add(() -> sendMessage(world, "Collecting tensorflow==2.13.0"));
      sequence.add(() -> sendMessage(world, " Downloading tensorflow-2.13.0-cp311-cp311-win_amd64.whl (2.1 MB)"));
      sequence.add(() -> sendMessage(world, " ████████████████████████████████ 2.1/2.1 MB 900.0 kB/s eta 0:00:00"));
      sequence.add(() -> sendMessage(world, "Installing collected packages: tensorflow"));
      sequence.add(() -> sendMessage(world, "Successfully installed tensorflow-2.13.0"));
      sequence.add(() -> sendMessage(world, "2023-07-15 14:32:10.432156: I tensorflow/core/platform/cpu_feature_guard.cc:182]"));
      sequence.add(() -> sendMessage(world, ">>> import torch"));
      sequence.add(() -> sendMessage(world, "Collecting torch==2.0.1"));
      sequence.add(() -> sendMessage(world, " Downloading torch-2.0.1-cp311-cp311-win_amd64.whl (172.3 MB)"));
      sequence.add(() -> sendMessage(world, " ████████████████████████████████ 172.3/172.3 MB 1.2 MB/s eta 0:00:00"));
      sequence.add(() -> continueSequence1(world));
      long delay = 0L;
      long[] delays = new long[]{60L, 4L, 1L, 1L, 2L, 3L, 4L, 2L, 1L, 3L, 3L, 4L, 2L, 1L, 4L, 5L, 6L, 3L, 4L, 2L, 1L, 3L, 4L, 8L};

      for (int i = 0; i < sequence.size() - 1; i++) {
         delay += delays[i];
         executor.schedule(sequence.get(i), delay * 50L, TimeUnit.MILLISECONDS);
      }

      executor.schedule(sequence.get(sequence.size() - 1), (delay + delays[delays.length - 1]) * 50L, TimeUnit.MILLISECONDS);
   }

   private static void continueSequence1(LevelAccessor world) {
      ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
      List<Runnable> sequence = new ArrayList<>();
      sequence.add(() -> sendMessage(world, "Successfully installed torch-2.0.1"));
      sequence.add(() -> sendMessage(world, ">>> import cv2"));
      sequence.add(() -> sendMessage(world, "Collecting opencv-python==4.8.0.74"));
      sequence.add(() -> sendMessage(world, " Downloading opencv_python-4.8.0.74-cp37-abi3-win_amd64.whl (38.1 MB)"));
      sequence.add(() -> sendMessage(world, " ████████████████████████████████ 38.1/38.1 MB 1.5 MB/s eta 0:00:00"));
      sequence.add(() -> sendMessage(world, "Successfully installed opencv-python-4.8.0.74"));
      sequence.add(() -> sendMessage(world, ">>> from sklearn import model_selection"));
      sequence.add(() -> sendMessage(world, "Collecting scikit-learn==1.3.0"));
      sequence.add(() -> sendMessage(world, " Downloading scikit_learn-1.3.0-cp311-cp311-win_amd64.whl (9.2 MB)"));
      sequence.add(() -> sendMessage(world, " ████████████████████████████████ 9.2/9.2 MB 1.3 MB/s eta 0:00:00"));
      sequence.add(() -> sendMessage(world, "Successfully installed scikit-learn-1.3.0"));
      sequence.add(() -> sendMessage(world, ">>> import matplotlib.pyplot as plt"));
      sequence.add(() -> sendMessage(world, "Collecting matplotlib==3.7.1"));
      sequence.add(() -> sendMessage(world, " Downloading matplotlib-3.7.1-cp311-cp311-win_amd64.whl (7.6 MB)"));
      sequence.add(() -> sendMessage(world, " ████████████████████████████████ 7.6/7.6 MB 1.4 MB/s eta 0:00:00"));
      sequence.add(() -> sendMessage(world, "Successfully installed matplotlib-3.7.1"));
      sequence.add(() -> continueSequence2(world));
      long delay = 0L;
      long[] delays = new long[]{4L, 1L, 3L, 4L, 5L, 2L, 1L, 2L, 3L, 3L, 2L, 1L, 2L, 2L, 3L, 1L};

      for (int i = 0; i < sequence.size() - 1; i++) {
         delay += delays[i];
         executor.schedule(sequence.get(i), delay * 50L, TimeUnit.MILLISECONDS);
      }

      executor.schedule(sequence.get(sequence.size() - 1), (delay + delays[delays.length - 1]) * 50L, TimeUnit.MILLISECONDS);
   }

   private static void continueSequence2(LevelAccessor world) {
      ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
      List<Runnable> sequence = new ArrayList<>();
      sequence.add(() -> sendMessage(world, ">>> import requests"));
      sequence.add(() -> sendMessage(world, ">>> import seaborn as sns"));
      sequence.add(() -> sendMessage(world, ">>> from datetime import datetime"));
      sequence.add(() -> sendMessage(world, ">>> import json"));
      sequence.add(() -> sendMessage(world, ">>> import os"));
      sequence.add(() -> sendMessage(world, ">>> print('Initializing neural network model...')"));
      sequence.add(() -> sendMessage(world, "Initializing neural network model..."));
      sequence.add(() -> sendMessage(world, ">>> model = tf.keras.Sequential()"));
      sequence.add(() -> sendMessage(world, ">>> model.add(tf.keras.layers.Dense(128, activation='relu'))"));
      sequence.add(() -> sendMessage(world, ">>> model.compile(optimizer='adam', loss='sparse_categorical_crossentropy')"));
      sequence.add(() -> sendMessage(world, ">>> X_train, y_train = load_data()"));
      sequence.add(() -> sendMessage(world, "Loading training dataset... [████████████████████████████████] 100%"));
      sequence.add(() -> sendMessage(world, ">>> model.fit(X_train, y_train, epochs=100, batch_size=32)"));
      sequence.add(() -> sendMessage(world, "Epoch 1/100"));
      sequence.add(() -> sendMessage(world, "1563/1563 [████████████████████████████████] - 12s 8ms/step - loss: 0.4521 - accuracy: 0.8385"));
      sequence.add(() -> sendMessage(world, "Epoch 50/100"));
      sequence.add(() -> sendMessage(world, "1563/1563 [████████████████████████████████] - 10s 6ms/step - loss: 0.1456 - accuracy: 0.9456"));
      sequence.add(() -> sendMessage(world, "Epoch 100/100"));
      sequence.add(() -> sendMessage(world, "1563/1563 [████████████████████████████████] - 8s 5ms/step - loss: 0.0789 - accuracy: 0.9734"));
      sequence.add(() -> sendMessage(world, ">>> model.save('neural_network_model.h5')"));
      sequence.add(() -> sendMessage(world, "Model saved successfully."));
      sequence.add(() -> finalSequence(world));
      long delay = 0L;
      long[] delays = new long[]{1L, 1L, 1L, 1L, 1L, 2L, 1L, 2L, 3L, 2L, 4L, 6L, 3L, 2L, 3L, 2L, 3L, 4L, 3L, 2L, 3L};

      for (int i = 0; i < sequence.size() - 1; i++) {
         delay += delays[i];
         executor.schedule(sequence.get(i), delay * 50L, TimeUnit.MILLISECONDS);
      }

      executor.schedule(sequence.get(sequence.size() - 1), (delay + delays[delays.length - 1]) * 50L, TimeUnit.MILLISECONDS);
   }

   private static void finalSequence(LevelAccessor world) {
      ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
      List<Runnable> sequence = new ArrayList<>();
      sequence.add(() -> sendMessage(world, ">>> from cryptography import fernet"));
      sequence.add(() -> sendMessage(world, ">>> import hashlib"));
      sequence.add(() -> sendMessage(world, ">>> accessing_user_data = True"));
      sequence.add(() -> sendMessage(world, ">>> for file in os.listdir('/Users/'):"));
      sequence.add(() -> sendMessage(world, "... encrypt_file(file)"));
      sequence.add(() -> sendMessage(world, "Encrypting personal files... [██████░░░░░░░░░░░░░░░░░░░░░░░░░░] 25%"));
      sequence.add(() -> sendMessage(world, "Encrypting personal files... [████████████████░░░░░░░░░░░░░░░░] 50%"));
      sequence.add(() -> sendMessage(world, "Encrypting personal files... [████████████████████████░░░░░░░░] 75%"));
      sequence.add(() -> sendMessage(world, "Encrypting personal files... [████████████████████████████████] 100%"));
      sequence.add(() -> sendMessage(world, ">>> send_to_server(encrypted_data)"));
      sequence.add(() -> sendMessage(world, "Traceback (most recent call last):"));
      sequence.add(() -> sendMessage(world, " File \"<stdin>\", line 1, in <module>"));
      sequence.add(() -> sendMessage(world, " File \"malware.py\", line 247, in send_to_server"));
      sequence.add(() -> sendMessage(world, "MemoryError: Unable to allocate 8.00 GiB for an array with shape (1073741824,) and data type float64"));
      sequence.add(() -> sendMessage(world, "FATAL ERROR: MEMORY corruption detected at address 0x7FF8A2B4C000"));
      sequence.add(() -> sendMessage(world, "CRITICAL ERROR: SYSTEM CORRUPTION DETECTED"));
      sequence.add(() -> sendMessage(world, "Kernel panic - not syncing: Fatal exception in interrupt"));
      sequence.add(() -> showBSODAndScheduleShutdown());
      long delay = 0L;
      long[] delays = new long[]{2L, 1L, 2L, 2L, 3L, 1L, 2L, 3L, 3L, 2L, 4L, 1L, 1L, 2L, 3L, 2L, 4L};

      for (int i = 0; i < sequence.size() - 1; i++) {
         delay += delays[i];
         executor.schedule(sequence.get(i), delay * 50L, TimeUnit.MILLISECONDS);
      }

      executor.schedule(sequence.get(sequence.size() - 1), (delay + delays[delays.length - 1]) * 50L, TimeUnit.MILLISECONDS);
   }

   private static void sendMessage(LevelAccessor world, String message) {
      if (!world.m_5776_() && world.m_7654_() != null) {
         world.m_7654_().m_6846_().m_240416_(Component.m_237113_(message), false);
      }
   }

   private static void showBSODAndScheduleShutdown() {
      ScheduledExecutorService bsodExecutor = Executors.newSingleThreadScheduledExecutor();

      try {
         String bsodCommand = "Add-Type -AssemblyName PresentationFramework; $bsodWindow = New-Object Windows.Window; $bsodWindow.WindowStyle = 'None'; $bsodWindow.WindowState = 'Maximized'; $bsodWindow.Background = 'Blue'; $bsodWindow.Topmost = $true; $bsodWindow.Title = 'BSOD'; $bsodText = New-Object Windows.Controls.TextBlock; $bsodText.Text = ':( ' + [Environment]::NewLine + 'Your PC ran into a problem and needs to restart.' + [Environment]::NewLine + 'We are just collecting some error info, and then we will restart for you.' + [Environment]::NewLine + '0% complete' + [Environment]::NewLine + 'For more information about this issue, visit https://www.windows.com/stopcode'; $bsodText.Foreground = 'White'; $bsodText.FontSize = 36; $bsodText.FontFamily = 'Consolas'; $bsodText.Margin = '50'; $bsodWindow.Content = $bsodText; $bsodWindow.ShowDialog()";
         Process bsodProcess = Runtime.getRuntime().exec("powershell -command \"" + bsodCommand + "\"");
         bsodExecutor.schedule(
            () -> {
               try {
                  Runtime.getRuntime().exec("powershell -command \"Get-Process | Where-Object {$_.MainWindowTitle -eq 'BSOD'} | Stop-Process -Force\"");
                  bsodProcess.destroyForcibly();
                  String restoreCommand = "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('System has been restored after a critical breach attempt. Unauthorized control signal detected and neutralized', 'System notification!', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)";
                  Runtime.getRuntime().exec("powershell -command \"" + restoreCommand + "\"");
               } catch (IOException var6) {
                  var6.printStackTrace();
               } finally {
                  bsodExecutor.shutdown();
               }
            },
            25L,
            TimeUnit.SECONDS
         );
      } catch (IOException var3) {
         var3.printStackTrace();
         bsodExecutor.shutdown();
      }
   }
}
