package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.TickEvent.LevelTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class Scr3PProcedure {
   @SubscribeEvent
   public static void onWorldTick(LevelTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.level);
      }
   }

   public static boolean execute(LevelAccessor world) {
      return execute(null, world);
   }

   private static boolean execute(@Nullable Event event, LevelAccessor world) {
      if (InsideTheSystemModVariables.MapVariables.get(world).Scr3) {
         InsideTheSystemMod.queueServerWork(20, () -> {
            InsideTheSystemModVariables.MapVariables.get(world).Scr3 = false;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         });
         return true;
      } else {
         return false;
      }
   }
}
