package net.mcreator.insidethesystem.procedures;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import net.mcreator.insidethesystem.entity.CoolPlayer303Entity;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.ServerTickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class TooManyPlayersProcedure {
   private static final Map<UUID, Integer> playerTimers = new HashMap<>();
   private static final int DELAY_TICKS = 100;

   @SubscribeEvent
   public static void onPlayerLoggedIn(PlayerLoggedInEvent event) {
      if (event.getEntity() instanceof ServerPlayer && !(event.getEntity() instanceof FakePlayer)) {
         ServerPlayer player = (ServerPlayer)event.getEntity();
         playerTimers.put(player.m_20148_(), 100);
      }
   }

   @SubscribeEvent
   public static void onServerTick(ServerTickEvent event) {
      if (event.phase == Phase.END) {
         Map<UUID, Integer> copy = new HashMap<>(playerTimers);

         for (Entry<UUID, Integer> entry : copy.entrySet()) {
            int remaining = entry.getValue() - 1;
            if (remaining <= 0) {
               playerTimers.remove(entry.getKey());
               ServerPlayer player = event.getServer().m_6846_().m_11259_(entry.getKey());
               if (player != null) {
                  checkAndRemoveExtraEntities(player);
               }
            } else {
               playerTimers.put(entry.getKey(), remaining);
            }
         }
      }
   }

   private static void checkAndRemoveExtraEntities(ServerPlayer player) {
      if (player.m_9236_() instanceof ServerLevel serverLevel) {
         List<CoolPlayer303Entity> entities = serverLevel.m_45976_(
            CoolPlayer303Entity.class,
            new AABB(
               player.m_20185_() - 100.0,
               player.m_20186_() - 100.0,
               player.m_20189_() - 100.0,
               player.m_20185_() + 100.0,
               player.m_20186_() + 100.0,
               player.m_20189_() + 100.0
            )
         );
         if (entities.size() > 1) {
            int removedCount = 0;

            for (int i = 1; i < entities.size(); i++) {
               entities.get(i).m_146870_();
               removedCount++;
            }

            player.m_213846_(Component.m_237113_("ATTENTION " + removedCount + " CONFLICTING AIKO, REMOVAL IS IN PROGRESS"));
         }
      }
   }
}
