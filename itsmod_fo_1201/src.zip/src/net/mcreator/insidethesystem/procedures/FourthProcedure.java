package net.mcreator.insidethesystem.procedures;

import java.util.Random;
import javax.annotation.Nullable;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.event.TickEvent.LevelTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class FourthProcedure {
   private static int tickCounter = 0;

   @SubscribeEvent
   public static void onWorldTick(LevelTickEvent event) {
      if (event.phase == Phase.END) {
         tickCounter++;
         if (tickCounter >= 2000) {
            tickCounter = 0;
            execute(event, event.level);
         }
      }
   }

   public static void execute(LevelAccessor world) {
      execute(null, world);
   }

   private static void execute(@Nullable Event event, LevelAccessor world) {
      if (InsideTheSystemModVariables.MapVariables.get(world).Fourth) {
         int centerX = (int)InsideTheSystemModVariables.MapVariables.get(world).PlayerX;
         int centerY = (int)InsideTheSystemModVariables.MapVariables.get(world).PlayerY;
         int centerZ = (int)InsideTheSystemModVariables.MapVariables.get(world).PlayerZ;
         Random random = new Random();
         int chunkRadius = 5;
         int randomChunkX = centerX + (random.nextInt(chunkRadius * 2 + 1) - chunkRadius) * 16;
         int randomChunkZ = centerZ + (random.nextInt(chunkRadius * 2 + 1) - chunkRadius) * 16;

         for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
               for (int y = 0; y < 300; y++) {
                  world.m_7731_(new BlockPos(randomChunkX + x, y, randomChunkZ + z), Blocks.f_50016_.m_49966_(), 3);
               }
            }
         }
      }
   }
}
