package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.world.level.LevelAccessor;

public class FamilyphotoAgreeProcedure {
   public static boolean execute(LevelAccessor world) {
      return InsideTheSystemModVariables.MapVariables.get(world).Family;
   }
}
