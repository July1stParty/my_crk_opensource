package net.mcreator.insidethesystem.procedures;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.entity.CoolPlayer303Entity;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.living.LivingEvent.LivingTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class CoolPlayerTooFarProcedure {
   private static final Map<UUID, Boolean> waitingForResponse = new HashMap<>();
   private static final Map<UUID, Boolean> hasAskedBefore = new HashMap<>();
   private static final Map<UUID, UUID> coolPlayerToPlayerMap = new HashMap<>();
   private static final double TELEPORT_DISTANCE = 60.0;

   @SubscribeEvent
   public static void onEntityTick(LivingTickEvent event) {
      execute(event, event.getEntity().m_9236_(), event.getEntity());
   }

   @SubscribeEvent
   public static void onChat(ServerChatEvent event) {
      Player player = event.getPlayer();
      String rawMessage = event.getRawText();
      handleChatResponse(player, rawMessage);
   }

   public static void execute(LevelAccessor world, Entity entity) {
      execute(null, world, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
      if (entity != null && !world.m_5776_()) {
         if (entity instanceof CoolPlayer303Entity coolPlayer) {
            UUID coolPlayerId = coolPlayer.m_20148_();
            Player nearestPlayer = world.m_45924_(coolPlayer.m_20185_(), coolPlayer.m_20186_(), coolPlayer.m_20189_(), -1.0, false);
            if (nearestPlayer == null) {
               return;
            }

            UUID playerId = nearestPlayer.m_20148_();
            double distance = coolPlayer.m_20270_(nearestPlayer);
            if (waitingForResponse.getOrDefault(coolPlayerId, false) && distance <= 60.0) {
               UUID expectedPlayerId = coolPlayerToPlayerMap.get(coolPlayerId);
               if (expectedPlayerId != null && expectedPlayerId.equals(playerId)) {
                  waitingForResponse.put(coolPlayerId, false);
                  coolPlayerToPlayerMap.remove(coolPlayerId);
                  broadcastMessage(world, "<CoolPlayer303> Oh, you're back! Never mind then");
                  return;
               }
            }

            if (distance > 60.0 && !waitingForResponse.getOrDefault(coolPlayerId, false) && !hasAskedBefore.getOrDefault(coolPlayerId, false)) {
               askForTeleport(world, coolPlayerId, playerId);
            }
         }
      }
   }

   private static void askForTeleport(LevelAccessor world, UUID coolPlayerId, UUID playerId) {
      waitingForResponse.put(coolPlayerId, true);
      hasAskedBefore.put(coolPlayerId, true);
      coolPlayerToPlayerMap.put(coolPlayerId, playerId);
      broadcastMessage(world, "<CoolPlayer303> Hey, I think I lost you... You're too far away!");
      InsideTheSystemMod.queueServerWork(
         40,
         () -> {
            if (waitingForResponse.getOrDefault(coolPlayerId, false)) {
               broadcastMessage(world, "<CoolPlayer303> Can I teleport to you? Just say 'yes' or 'no' in chat!");
               broadcastMessage(
                  world, "<CoolPlayer303> You can also just say 'tp for me' anytime, but DON'T go too far, or I'll get unloaded and can't teleport!"
               );
            }
         }
      );
   }

   private static void handleChatResponse(Player player, String message) {
      if (player instanceof ServerPlayer serverPlayer && message != null) {
         String cleanMessage = message.toLowerCase().trim();
         UUID playerId = serverPlayer.m_20148_();
         UUID waitingCoolPlayerId = null;

         for (Entry<UUID, UUID> entry : coolPlayerToPlayerMap.entrySet()) {
            if (entry.getValue().equals(playerId) && waitingForResponse.getOrDefault(entry.getKey(), false)) {
               waitingCoolPlayerId = entry.getKey();
               break;
            }
         }

         if (waitingCoolPlayerId != null) {
            CoolPlayer303Entity coolPlayer = findCoolPlayerById(serverPlayer.m_9236_(), waitingCoolPlayerId);
            if (coolPlayer == null) {
               return;
            }

            if (cleanMessage.equals("yes") || cleanMessage.equals("y")) {
               performTeleport(serverPlayer, coolPlayer, waitingCoolPlayerId, true);
               return;
            }

            if (cleanMessage.equals("no") || cleanMessage.equals("n")) {
               waitingForResponse.put(waitingCoolPlayerId, false);
               coolPlayerToPlayerMap.remove(waitingCoolPlayerId);
               InsideTheSystemMod.queueServerWork(
                  20, () -> broadcastMessage(serverPlayer.m_9236_(), "<CoolPlayer303> Okay, I'll wait here then. Let me know if you change your mind!")
               );
               return;
            }
         }

         if (cleanMessage.equals("тп фор ми") || cleanMessage.equals("tp for me")) {
            UUID coolPlayerUUID = findClosestCoolPlayerUUID(serverPlayer.m_9236_(), serverPlayer.m_20148_());
            if (coolPlayerUUID != null) {
               CoolPlayer303Entity coolPlayerx = findCoolPlayerById(serverPlayer.m_9236_(), coolPlayerUUID);
               if (coolPlayerx != null) {
                  waitingForResponse.put(coolPlayerx.m_20148_(), false);
                  coolPlayerToPlayerMap.remove(coolPlayerx.m_20148_());
                  performTeleport(serverPlayer, coolPlayerx, coolPlayerx.m_20148_(), false);
               } else {
                  serverPlayer.m_213846_(Component.m_237113_("§7[System] ERROR: CoolPlayer303 not found or is too far and unloaded."));
               }
            } else {
               serverPlayer.m_213846_(Component.m_237113_("§7[System] ERROR: CoolPlayer303 not found or is too far and unloaded."));
            }
         }
      }
   }

   private static UUID findClosestCoolPlayerUUID(LevelAccessor world, UUID playerId) {
      if (world instanceof ServerLevel serverLevel) {
         List<CoolPlayer303Entity> entities = serverLevel.m_45976_(CoolPlayer303Entity.class, new AABB(-3.0E7, -256.0, -3.0E7, 3.0E7, 320.0, 3.0E7));
         return entities.isEmpty() ? null : entities.stream().findFirst().<UUID>map(Entity::m_20148_).orElse(null);
      } else {
         return null;
      }
   }

   private static void performTeleport(ServerPlayer serverPlayer, CoolPlayer303Entity coolPlayer, UUID coolPlayerId, boolean requestedByAnswer) {
      waitingForResponse.put(coolPlayerId, false);
      coolPlayerToPlayerMap.remove(coolPlayerId);
      InsideTheSystemMod.queueServerWork(20, () -> {
         broadcastMessage(serverPlayer.m_9236_(), "<CoolPlayer303> Thank you! Teleporting to you now!");
         InsideTheSystemMod.queueServerWork(20, () -> {
            if (coolPlayer != null && !coolPlayer.m_213877_() && serverPlayer != null && !serverPlayer.m_213877_()) {
               coolPlayer.m_6021_(serverPlayer.m_20185_(), serverPlayer.m_20186_(), serverPlayer.m_20189_());
               if (requestedByAnswer) {
                  broadcastMessage(serverPlayer.m_9236_(), "<CoolPlayer303> Thank you, I won't ask again");
               } else {
                  broadcastMessage(serverPlayer.m_9236_(), "<CoolPlayer303> TP accepted. I'm teleporting now");
               }
            }
         });
      });
   }

   private static CoolPlayer303Entity findCoolPlayerById(LevelAccessor world, UUID coolPlayerId) {
      if (world instanceof ServerLevel serverLevel) {
         List<CoolPlayer303Entity> entities = serverLevel.m_6443_(
            CoolPlayer303Entity.class, new AABB(-3.0E7, -256.0, -3.0E7, 3.0E7, 320.0, 3.0E7), entity -> entity.m_20148_().equals(coolPlayerId)
         );
         return entities.stream().findFirst().orElse(null);
      } else {
         return null;
      }
   }

   private static void broadcastMessage(LevelAccessor world, String message) {
      if (world instanceof ServerLevel serverLevel) {
         serverLevel.m_7654_().m_6846_().m_240416_(Component.m_237113_(message), false);
      }
   }
}
