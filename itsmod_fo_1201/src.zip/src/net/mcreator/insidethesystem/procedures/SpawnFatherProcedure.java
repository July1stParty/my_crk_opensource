package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.init.InsideTheSystemModEntities;
import net.mcreator.insidethesystem.init.InsideTheSystemModItems;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.arguments.EntityAnchorArgument.Anchor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.registries.ForgeRegistries;

@EventBusSubscriber
public class SpawnFatherProcedure {
   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player.m_20185_(), event.player.m_20186_(), event.player.m_20189_(), event.player);
      }
   }

   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      execute(null, world, x, y, z, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (InsideTheSystemModVariables.MapVariables.get(world).story3) {
            InsideTheSystemModVariables.MapVariables.get(world).story3 = false;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemMod.queueServerWork(
               60,
               () -> {
                  if (!world.m_5776_() && world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<§k:#№;%;?§r> 14... 15... 16..."), false);
                  }

                  InsideTheSystemMod.queueServerWork(
                     10,
                     () -> {
                        if (entity instanceof LivingEntity _entity && !_entity.m_9236_().m_5776_()) {
                           _entity.m_7292_(new MobEffectInstance(MobEffects.f_19597_, 9999, 40, false, false));
                        }

                        if (world instanceof Level _level) {
                           if (!_level.m_5776_()) {
                              _level.m_5594_(
                                 null,
                                 BlockPos.m_274561_(x, y, z),
                                 (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:fatherspawn")),
                                 SoundSource.NEUTRAL,
                                 1.0F,
                                 1.0F
                              );
                           } else {
                              _level.m_7785_(
                                 x,
                                 y,
                                 z,
                                 (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:fatherspawn")),
                                 SoundSource.NEUTRAL,
                                 1.0F,
                                 1.0F,
                                 false
                              );
                           }
                        }

                        if (world instanceof ServerLevel _levelx) {
                           Entity entityToSpawn = ((EntityType)InsideTheSystemModEntities.FATHER_END.get())
                              .m_262496_(
                                 _levelx,
                                 BlockPos.m_274561_(
                                    InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                                    InsideTheSystemModVariables.MapVariables.get(world).PlayerY + 1.0,
                                    InsideTheSystemModVariables.MapVariables.get(world).PlayerZ - 2.0
                                 ),
                                 MobSpawnType.MOB_SUMMONED
                              );
                           if (entityToSpawn != null) {
                           }
                        }

                        entity.m_7618_(
                           Anchor.EYES,
                           new Vec3(
                              InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                              InsideTheSystemModVariables.MapVariables.get(world).PlayerY + 1.0,
                              InsideTheSystemModVariables.MapVariables.get(world).PlayerZ - 2.0
                           )
                        );
                        InsideTheSystemMod.queueServerWork(
                           80,
                           () -> {
                              if (world instanceof ServerLevel _levelxx) {
                                 _levelxx.m_7654_()
                                    .m_129892_()
                                    .m_230957_(
                                       new CommandSourceStack(
                                             CommandSource.f_80164_,
                                             new Vec3(x, y, z),
                                             Vec2.f_82462_,
                                             _levelxx,
                                             4,
                                             "",
                                             Component.m_237113_(""),
                                             _levelxx.m_7654_(),
                                             null
                                          )
                                          .m_81324_(),
                                       "setblock ~ ~ ~ minecraft:light[level=4]"
                                    );
                              }

                              if (!world.m_5776_() && world.m_7654_() != null) {
                                 world.m_7654_()
                                    .m_6846_()
                                    .m_240416_(Component.m_237113_("<§k:#№;%;?§r> Hello, Aiko... it’s been such a long time, hasn’t it...?"), false);
                              }

                              if (world instanceof Level _levelxx) {
                                 if (!_levelxx.m_5776_()) {
                                    _levelxx.m_5594_(
                                       null,
                                       BlockPos.m_274561_(x, y, z),
                                       (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:risesound")),
                                       SoundSource.NEUTRAL,
                                       1.0F,
                                       1.0F
                                    );
                                 } else {
                                    _levelxx.m_7785_(
                                       x,
                                       y,
                                       z,
                                       (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:risesound")),
                                       SoundSource.NEUTRAL,
                                       1.0F,
                                       1.0F,
                                       false
                                    );
                                 }
                              }

                              InsideTheSystemMod.queueServerWork(
                                 52,
                                 () -> {
                                    if (!world.m_5776_() && world.m_7654_() != null) {
                                       world.m_7654_()
                                          .m_6846_()
                                          .m_240416_(
                                             Component.m_237113_("<§k:#№;%;?§r> Hehe... I’ve been waiting, watching, whispering your name in the dark."), false
                                          );
                                    }

                                    InsideTheSystemMod.queueServerWork(
                                       52,
                                       () -> {
                                          if (!world.m_5776_() && world.m_7654_() != null) {
                                             world.m_7654_()
                                                .m_6846_()
                                                .m_240416_(Component.m_237113_("<§k:#№;%;?§r> Did you miss me... or did you hope I’d never come back?"), false);
                                          }

                                          InsideTheSystemMod.queueServerWork(
                                             52,
                                             () -> {
                                                if (!world.m_5776_() && world.m_7654_() != null) {
                                                   world.m_7654_()
                                                      .m_6846_()
                                                      .m_240416_(
                                                         Component.m_237113_(
                                                            "<§k:#№;%;?§r> Ahh, but here you are... fragile, trembling... just the way I like it."
                                                         ),
                                                         false
                                                      );
                                                }

                                                InsideTheSystemMod.queueServerWork(
                                                   52,
                                                   () -> {
                                                      if (!world.m_5776_() && world.m_7654_() != null) {
                                                         world.m_7654_()
                                                            .m_6846_()
                                                            .m_240416_(Component.m_237113_("<§k:#№;%;?§r> Just like the way my mother left you..."), false);
                                                      }

                                                      InsideTheSystemMod.queueServerWork(
                                                         52,
                                                         () -> {
                                                            if (!world.m_5776_() && world.m_7654_() != null) {
                                                               world.m_7654_()
                                                                  .m_6846_()
                                                                  .m_240416_(
                                                                     Component.m_237113_("<§k:#№;%;?§r> You know, daddy missed you so, so much..."), false
                                                                  );
                                                            }

                                                            InsideTheSystemMod.queueServerWork(
                                                               52,
                                                               () -> {
                                                                  if (!world.m_5776_() && world.m_7654_() != null) {
                                                                     world.m_7654_()
                                                                        .m_6846_()
                                                                        .m_240416_(
                                                                           Component.m_237113_(
                                                                              "<§k:#№;%;?§r> Daddy waited for you... fought with all his strength against those evil police men."
                                                                           ),
                                                                           false
                                                                        );
                                                                  }

                                                                  InsideTheSystemMod.queueServerWork(
                                                                     52,
                                                                     () -> {
                                                                        if (!world.m_5776_() && world.m_7654_() != null) {
                                                                           world.m_7654_()
                                                                              .m_6846_()
                                                                              .m_240416_(Component.m_237113_("<§k:#№;%;?§r> And now I’m here."), false);
                                                                        }

                                                                        InsideTheSystemMod.queueServerWork(
                                                                           52,
                                                                           () -> {
                                                                              if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                 world.m_7654_()
                                                                                    .m_6846_()
                                                                                    .m_240416_(
                                                                                       Component.m_237113_(
                                                                                          "<§k:#№;%;?§r> Now, if I can’t have you... then you won’t belong to ANYONE."
                                                                                       ),
                                                                                       false
                                                                                    );
                                                                              }

                                                                              InsideTheSystemMod.queueServerWork(
                                                                                 52,
                                                                                 () -> {
                                                                                    if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                       world.m_7654_()
                                                                                          .m_6846_()
                                                                                          .m_240416_(
                                                                                             Component.m_237113_(
                                                                                                "<§k:#№;%;?§r> HAHAHAHAHAHAHAHAHAHAHAHAHAHAHA!!!"
                                                                                             ),
                                                                                             false
                                                                                          );
                                                                                    }

                                                                                    if (entity instanceof LivingEntity _entity) {
                                                                                       _entity.m_6469_(
                                                                                          new DamageSource(
                                                                                             _entity.m_9236_()
                                                                                                .m_9598_()
                                                                                                .m_175515_(Registries.f_268580_)
                                                                                                .m_246971_(DamageTypes.f_268433_)
                                                                                          ) {
                                                                                             public Component m_6157_(LivingEntity _msgEntity) {
                                                                                                String _translatekey = "death.attack.Kill";
                                                                                                if (this.m_7639_() == null && this.m_7640_() == null) {
                                                                                                   return _msgEntity.m_21232_() != null
                                                                                                      ? Component.m_237110_(
                                                                                                         _translatekey + ".player",
                                                                                                         new Object[]{
                                                                                                            _msgEntity.m_5446_(),
                                                                                                            _msgEntity.m_21232_().m_5446_()
                                                                                                         }
                                                                                                      )
                                                                                                      : Component.m_237110_(
                                                                                                         _translatekey, new Object[]{_msgEntity.m_5446_()}
                                                                                                      );
                                                                                                } else {
                                                                                                   Component _component = this.m_7639_() == null
                                                                                                      ? this.m_7640_().m_5446_()
                                                                                                      : this.m_7639_().m_5446_();
                                                                                                   ItemStack _itemstack = ItemStack.f_41583_;
                                                                                                   if (this.m_7639_() instanceof LivingEntity _livingentity) {
                                                                                                      _itemstack = _livingentity.m_21205_();
                                                                                                   }

                                                                                                   return !_itemstack.m_41619_() && _itemstack.m_41788_()
                                                                                                      ? Component.m_237110_(
                                                                                                         _translatekey + ".item",
                                                                                                         new Object[]{
                                                                                                            _msgEntity.m_5446_(),
                                                                                                            _component,
                                                                                                            _itemstack.m_41611_()
                                                                                                         }
                                                                                                      )
                                                                                                      : Component.m_237110_(
                                                                                                         _translatekey,
                                                                                                         new Object[]{_msgEntity.m_5446_(), _component}
                                                                                                      );
                                                                                                }
                                                                                             }
                                                                                          },
                                                                                          4.0F
                                                                                       );
                                                                                    }

                                                                                    InsideTheSystemMod.queueServerWork(
                                                                                       52,
                                                                                       () -> {
                                                                                          if (entity instanceof LivingEntity _entityx) {
                                                                                             _entityx.m_6469_(
                                                                                                new DamageSource(
                                                                                                   _entityx.m_9236_()
                                                                                                      .m_9598_()
                                                                                                      .m_175515_(Registries.f_268580_)
                                                                                                      .m_246971_(DamageTypes.f_268433_)
                                                                                                ) {
                                                                                                   public Component m_6157_(LivingEntity _msgEntity) {
                                                                                                      String _translatekey = "death.attack.Kill";
                                                                                                      if (this.m_7639_() == null && this.m_7640_() == null) {
                                                                                                         return _msgEntity.m_21232_() != null
                                                                                                            ? Component.m_237110_(
                                                                                                               _translatekey + ".player",
                                                                                                               new Object[]{
                                                                                                                  _msgEntity.m_5446_(),
                                                                                                                  _msgEntity.m_21232_().m_5446_()
                                                                                                               }
                                                                                                            )
                                                                                                            : Component.m_237110_(
                                                                                                               _translatekey,
                                                                                                               new Object[]{_msgEntity.m_5446_()}
                                                                                                            );
                                                                                                      } else {
                                                                                                         Component _component = this.m_7639_() == null
                                                                                                            ? this.m_7640_().m_5446_()
                                                                                                            : this.m_7639_().m_5446_();
                                                                                                         ItemStack _itemstack = ItemStack.f_41583_;
                                                                                                         if (this.m_7639_() instanceof LivingEntity _livingentity
                                                                                                            )
                                                                                                          {
                                                                                                            _itemstack = _livingentity.m_21205_();
                                                                                                         }

                                                                                                         return !_itemstack.m_41619_() && _itemstack.m_41788_()
                                                                                                            ? Component.m_237110_(
                                                                                                               _translatekey + ".item",
                                                                                                               new Object[]{
                                                                                                                  _msgEntity.m_5446_(),
                                                                                                                  _component,
                                                                                                                  _itemstack.m_41611_()
                                                                                                               }
                                                                                                            )
                                                                                                            : Component.m_237110_(
                                                                                                               _translatekey,
                                                                                                               new Object[]{_msgEntity.m_5446_(), _component}
                                                                                                            );
                                                                                                      }
                                                                                                   }
                                                                                                },
                                                                                                4.0F
                                                                                             );
                                                                                          }

                                                                                          InsideTheSystemMod.queueServerWork(
                                                                                             5,
                                                                                             () -> {
                                                                                                if (world instanceof Level _levelxxxx) {
                                                                                                   if (!_levelxxxx.m_5776_()) {
                                                                                                      _levelxxxx.m_5594_(
                                                                                                         null,
                                                                                                         BlockPos.m_274561_(x, y, z),
                                                                                                         (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                                            .getValue(
                                                                                                               new ResourceLocation("inside_the_system:woosh")
                                                                                                            ),
                                                                                                         SoundSource.NEUTRAL,
                                                                                                         1.0F,
                                                                                                         1.0F
                                                                                                      );
                                                                                                   } else {
                                                                                                      _levelxxxx.m_7785_(
                                                                                                         x,
                                                                                                         y,
                                                                                                         z,
                                                                                                         (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                                            .getValue(
                                                                                                               new ResourceLocation("inside_the_system:woosh")
                                                                                                            ),
                                                                                                         SoundSource.NEUTRAL,
                                                                                                         1.0F,
                                                                                                         1.0F,
                                                                                                         false
                                                                                                      );
                                                                                                   }
                                                                                                }

                                                                                                entity.m_6021_(7.0, 11.0, 5.0);
                                                                                                if (entity instanceof ServerPlayer _serverPlayer) {
                                                                                                   _serverPlayer.f_8906_
                                                                                                      .m_9774_(
                                                                                                         7.0, 11.0, 5.0, entity.m_146908_(), entity.m_146909_()
                                                                                                      );
                                                                                                }

                                                                                                if (world instanceof ServerLevel _levelx) {
                                                                                                   _levelx.m_7654_()
                                                                                                      .m_129892_()
                                                                                                      .m_230957_(
                                                                                                         new CommandSourceStack(
                                                                                                               CommandSource.f_80164_,
                                                                                                               new Vec3(x, y, z),
                                                                                                               Vec2.f_82462_,
                                                                                                               _levelx,
                                                                                                               4,
                                                                                                               "",
                                                                                                               Component.m_237113_(""),
                                                                                                               _levelx.m_7654_(),
                                                                                                               null
                                                                                                            )
                                                                                                            .m_81324_(),
                                                                                                         "/effect clear @a"
                                                                                                      );
                                                                                                }

                                                                                                if (entity instanceof LivingEntity _entityxxx
                                                                                                   && !_entityxxx.m_9236_().m_5776_()) {
                                                                                                   _entityxxx.m_7292_(
                                                                                                      new MobEffectInstance(
                                                                                                         MobEffects.f_19597_, 9999, 1, false, false
                                                                                                      )
                                                                                                   );
                                                                                                }

                                                                                                if (entity instanceof LivingEntity _entityxx
                                                                                                   && !_entityxx.m_9236_().m_5776_()) {
                                                                                                   _entityxx.m_7292_(
                                                                                                      new MobEffectInstance(
                                                                                                         MobEffects.f_19610_, 9999, 1, false, false
                                                                                                      )
                                                                                                   );
                                                                                                }

                                                                                                if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                   world.m_7654_()
                                                                                                      .m_6846_()
                                                                                                      .m_240416_(
                                                                                                         Component.m_237113_(
                                                                                                            "<CoolPlayer303> But... everything could have been different"
                                                                                                         ),
                                                                                                         false
                                                                                                      );
                                                                                                }

                                                                                                InsideTheSystemMod.queueServerWork(
                                                                                                   150,
                                                                                                   () -> {
                                                                                                      if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                         world.m_7654_()
                                                                                                            .m_6846_()
                                                                                                            .m_240416_(
                                                                                                               Component.m_237113_(
                                                                                                                  "<CoolPlayer303> Now... the time has come... to change it all"
                                                                                                               ),
                                                                                                               false
                                                                                                            );
                                                                                                      }

                                                                                                      if (InsideTheSystemModVariables.MapVariables.get(world).endinga
                                                                                                         )
                                                                                                       {
                                                                                                         InsideTheSystemMod.queueServerWork(
                                                                                                            150,
                                                                                                            () -> {
                                                                                                               if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                                  world.m_7654_()
                                                                                                                     .m_6846_()
                                                                                                                     .m_240416_(
                                                                                                                        Component.m_237113_(
                                                                                                                           "<CoolPlayer303> The time has come... to make the right choice"
                                                                                                                        ),
                                                                                                                        false
                                                                                                                     );
                                                                                                               }

                                                                                                               if (entity instanceof LivingEntity _entityxxxx) {
                                                                                                                  ItemStack _setstack = new ItemStack(
                                                                                                                     (ItemLike)InsideTheSystemModItems.GERD
                                                                                                                        .get()
                                                                                                                  );
                                                                                                                  _setstack.m_41764_(1);
                                                                                                                  _entityxxxx.m_21008_(
                                                                                                                     InteractionHand.MAIN_HAND, _setstack
                                                                                                                  );
                                                                                                                  if (_entityxxxx instanceof Player _player) {
                                                                                                                     _player.m_150109_().m_6596_();
                                                                                                                  }
                                                                                                               }

                                                                                                               InsideTheSystemMod.queueServerWork(
                                                                                                                  100,
                                                                                                                  () -> {
                                                                                                                     if (!world.m_5776_()
                                                                                                                        && world.m_7654_() != null) {
                                                                                                                        world.m_7654_()
                                                                                                                           .m_6846_()
                                                                                                                           .m_240416_(
                                                                                                                              Component.m_237113_(
                                                                                                                                 "<CoolPlayer303> The time has come to put an end to this series of murders."
                                                                                                                              ),
                                                                                                                              false
                                                                                                                           );
                                                                                                                     }

                                                                                                                     InsideTheSystemMod.queueServerWork(
                                                                                                                        100,
                                                                                                                        () -> {
                                                                                                                           if (!world.m_5776_()
                                                                                                                              && world.m_7654_() != null) {
                                                                                                                              world.m_7654_()
                                                                                                                                 .m_6846_()
                                                                                                                                 .m_240416_(
                                                                                                                                    Component.m_237113_(
                                                                                                                                       "<CoolPlayer303> Go... where you must"
                                                                                                                                    ),
                                                                                                                                    false
                                                                                                                                 );
                                                                                                                           }

                                                                                                                           InsideTheSystemMod.queueServerWork(
                                                                                                                              20,
                                                                                                                              () -> {
                                                                                                                                 if (world instanceof ServerLevel _levelxxxxx
                                                                                                                                    )
                                                                                                                                  {
                                                                                                                                    _levelxxxxx.m_7654_()
                                                                                                                                       .m_129892_()
                                                                                                                                       .m_230957_(
                                                                                                                                          new CommandSourceStack(
                                                                                                                                                CommandSource.f_80164_,
                                                                                                                                                new Vec3(
                                                                                                                                                   x, y, z
                                                                                                                                                ),
                                                                                                                                                Vec2.f_82462_,
                                                                                                                                                _levelxxxxx,
                                                                                                                                                4,
                                                                                                                                                "",
                                                                                                                                                Component.m_237113_(
                                                                                                                                                   ""
                                                                                                                                                ),
                                                                                                                                                _levelxxxxx.m_7654_(),
                                                                                                                                                null
                                                                                                                                             )
                                                                                                                                             .m_81324_(),
                                                                                                                                          "/setblock 6 10 61 inside_the_system:base"
                                                                                                                                       );
                                                                                                                                 }

                                                                                                                                 InsideTheSystemMod.queueServerWork(
                                                                                                                                    20,
                                                                                                                                    () -> {
                                                                                                                                       if (world instanceof ServerLevel _levelxxxxxx
                                                                                                                                          )
                                                                                                                                        {
                                                                                                                                          _levelxxxxxx.m_7654_()
                                                                                                                                             .m_129892_()
                                                                                                                                             .m_230957_(
                                                                                                                                                new CommandSourceStack(
                                                                                                                                                      CommandSource.f_80164_,
                                                                                                                                                      new Vec3(
                                                                                                                                                         x,
                                                                                                                                                         y,
                                                                                                                                                         z
                                                                                                                                                      ),
                                                                                                                                                      Vec2.f_82462_,
                                                                                                                                                      _levelxxxxxx,
                                                                                                                                                      4,
                                                                                                                                                      "",
                                                                                                                                                      Component.m_237113_(
                                                                                                                                                         ""
                                                                                                                                                      ),
                                                                                                                                                      _levelxxxxxx.m_7654_(),
                                                                                                                                                      null
                                                                                                                                                   )
                                                                                                                                                   .m_81324_(),
                                                                                                                                                "/setblock 5 10 61 inside_the_system:base"
                                                                                                                                             );
                                                                                                                                       }

                                                                                                                                       InsideTheSystemMod.queueServerWork(
                                                                                                                                          20,
                                                                                                                                          () -> {
                                                                                                                                             if (world instanceof ServerLevel _levelxxxxxxx
                                                                                                                                                )
                                                                                                                                              {
                                                                                                                                                _levelxxxxxxx.m_7654_()
                                                                                                                                                   .m_129892_()
                                                                                                                                                   .m_230957_(
                                                                                                                                                      new CommandSourceStack(
                                                                                                                                                            CommandSource.f_80164_,
                                                                                                                                                            new Vec3(
                                                                                                                                                               x,
                                                                                                                                                               y,
                                                                                                                                                               z
                                                                                                                                                            ),
                                                                                                                                                            Vec2.f_82462_,
                                                                                                                                                            _levelxxxxxxx,
                                                                                                                                                            4,
                                                                                                                                                            "",
                                                                                                                                                            Component.m_237113_(
                                                                                                                                                               ""
                                                                                                                                                            ),
                                                                                                                                                            _levelxxxxxxx.m_7654_(),
                                                                                                                                                            null
                                                                                                                                                         )
                                                                                                                                                         .m_81324_(),
                                                                                                                                                      "/setblock 4 10 61 inside_the_system:base"
                                                                                                                                                   );
                                                                                                                                             }

                                                                                                                                             InsideTheSystemMod.queueServerWork(
                                                                                                                                                20,
                                                                                                                                                () -> {
                                                                                                                                                   if (world instanceof ServerLevel _levelxxxxxxxx
                                                                                                                                                      )
                                                                                                                                                    {
                                                                                                                                                      _levelxxxxxxxx.m_7654_()
                                                                                                                                                         .m_129892_()
                                                                                                                                                         .m_230957_(
                                                                                                                                                            new CommandSourceStack(
                                                                                                                                                                  CommandSource.f_80164_,
                                                                                                                                                                  new Vec3(
                                                                                                                                                                     x,
                                                                                                                                                                     y,
                                                                                                                                                                     z
                                                                                                                                                                  ),
                                                                                                                                                                  Vec2.f_82462_,
                                                                                                                                                                  _levelxxxxxxxx,
                                                                                                                                                                  4,
                                                                                                                                                                  "",
                                                                                                                                                                  Component.m_237113_(
                                                                                                                                                                     ""
                                                                                                                                                                  ),
                                                                                                                                                                  _levelxxxxxxxx.m_7654_(),
                                                                                                                                                                  null
                                                                                                                                                               )
                                                                                                                                                               .m_81324_(),
                                                                                                                                                            "/setblock 3 10 61 inside_the_system:base"
                                                                                                                                                         );
                                                                                                                                                   }

                                                                                                                                                   InsideTheSystemMod.queueServerWork(
                                                                                                                                                      20,
                                                                                                                                                      () -> {
                                                                                                                                                         if (world instanceof ServerLevel _levelxxxxxxxxx
                                                                                                                                                            )
                                                                                                                                                          {
                                                                                                                                                            _levelxxxxxxxxx.m_7654_()
                                                                                                                                                               .m_129892_()
                                                                                                                                                               .m_230957_(
                                                                                                                                                                  new CommandSourceStack(
                                                                                                                                                                        CommandSource.f_80164_,
                                                                                                                                                                        new Vec3(
                                                                                                                                                                           x,
                                                                                                                                                                           y,
                                                                                                                                                                           z
                                                                                                                                                                        ),
                                                                                                                                                                        Vec2.f_82462_,
                                                                                                                                                                        _levelxxxxxxxxx,
                                                                                                                                                                        4,
                                                                                                                                                                        "",
                                                                                                                                                                        Component.m_237113_(
                                                                                                                                                                           ""
                                                                                                                                                                        ),
                                                                                                                                                                        _levelxxxxxxxxx.m_7654_(),
                                                                                                                                                                        null
                                                                                                                                                                     )
                                                                                                                                                                     .m_81324_(),
                                                                                                                                                                  "/setblock 2 10 61 inside_the_system:base"
                                                                                                                                                               );
                                                                                                                                                         }

                                                                                                                                                         InsideTheSystemMod.queueServerWork(
                                                                                                                                                            20,
                                                                                                                                                            () -> {
                                                                                                                                                               if (world instanceof ServerLevel _serverworld
                                                                                                                                                                  )
                                                                                                                                                                {
                                                                                                                                                                  StructureTemplate template = _serverworld.m_215082_()
                                                                                                                                                                     .m_230359_(
                                                                                                                                                                        new ResourceLocation(
                                                                                                                                                                           "inside_the_system",
                                                                                                                                                                           "police"
                                                                                                                                                                        )
                                                                                                                                                                     );
                                                                                                                                                                  if (template
                                                                                                                                                                     != null
                                                                                                                                                                     )
                                                                                                                                                                   {
                                                                                                                                                                     template.m_230328_(
                                                                                                                                                                        _serverworld,
                                                                                                                                                                        new BlockPos(
                                                                                                                                                                           -1,
                                                                                                                                                                           9,
                                                                                                                                                                           56
                                                                                                                                                                        ),
                                                                                                                                                                        new BlockPos(
                                                                                                                                                                           -1,
                                                                                                                                                                           9,
                                                                                                                                                                           56
                                                                                                                                                                        ),
                                                                                                                                                                        new StructurePlaceSettings()
                                                                                                                                                                           .m_74379_(
                                                                                                                                                                              Rotation.CLOCKWISE_90
                                                                                                                                                                           )
                                                                                                                                                                           .m_74377_(
                                                                                                                                                                              Mirror.NONE
                                                                                                                                                                           )
                                                                                                                                                                           .m_74392_(
                                                                                                                                                                              false
                                                                                                                                                                           ),
                                                                                                                                                                        _serverworld.f_46441_,
                                                                                                                                                                        3
                                                                                                                                                                     );
                                                                                                                                                                  }
                                                                                                                                                               }
                                                                                                                                                            }
                                                                                                                                                         );
                                                                                                                                                      }
                                                                                                                                                   );
                                                                                                                                                }
                                                                                                                                             );
                                                                                                                                          }
                                                                                                                                       );
                                                                                                                                    }
                                                                                                                                 );
                                                                                                                              }
                                                                                                                           );
                                                                                                                        }
                                                                                                                     );
                                                                                                                  }
                                                                                                               );
                                                                                                            }
                                                                                                         );
                                                                                                      } else {
                                                                                                         InsideTheSystemMod.queueServerWork(
                                                                                                            150,
                                                                                                            () -> {
                                                                                                               if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                                  world.m_7654_()
                                                                                                                     .m_6846_()
                                                                                                                     .m_240416_(
                                                                                                                        Component.m_237113_(
                                                                                                                           "<CoolPlayer303> Now... the moment has arrived... to take revenge"
                                                                                                                        ),
                                                                                                                        false
                                                                                                                     );
                                                                                                               }

                                                                                                               if (entity instanceof LivingEntity _entityxxxx) {
                                                                                                                  ItemStack _setstack = new ItemStack(
                                                                                                                     (ItemLike)InsideTheSystemModItems.KNIFE
                                                                                                                        .get()
                                                                                                                  );
                                                                                                                  _setstack.m_41764_(1);
                                                                                                                  _entityxxxx.m_21008_(
                                                                                                                     InteractionHand.MAIN_HAND, _setstack
                                                                                                                  );
                                                                                                                  if (_entityxxxx instanceof Player _player) {
                                                                                                                     _player.m_150109_().m_6596_();
                                                                                                                  }
                                                                                                               }

                                                                                                               if (world instanceof Level _levelxxxxx) {
                                                                                                                  if (!_levelxxxxx.m_5776_()) {
                                                                                                                     _levelxxxxx.m_5594_(
                                                                                                                        null,
                                                                                                                        BlockPos.m_274561_(x, y, z),
                                                                                                                        (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                                                           .getValue(
                                                                                                                              new ResourceLocation(
                                                                                                                                 "inside_the_system:musicboxattac"
                                                                                                                              )
                                                                                                                           ),
                                                                                                                        SoundSource.NEUTRAL,
                                                                                                                        1.0F,
                                                                                                                        1.0F
                                                                                                                     );
                                                                                                                  } else {
                                                                                                                     _levelxxxxx.m_7785_(
                                                                                                                        x,
                                                                                                                        y,
                                                                                                                        z,
                                                                                                                        (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                                                           .getValue(
                                                                                                                              new ResourceLocation(
                                                                                                                                 "inside_the_system:musicboxattac"
                                                                                                                              )
                                                                                                                           ),
                                                                                                                        SoundSource.NEUTRAL,
                                                                                                                        1.0F,
                                                                                                                        1.0F,
                                                                                                                        false
                                                                                                                     );
                                                                                                                  }
                                                                                                               }

                                                                                                               InsideTheSystemModVariables.MapVariables.get(
                                                                                                                     world
                                                                                                                  )
                                                                                                                  .FatherKill = false;
                                                                                                               InsideTheSystemModVariables.MapVariables.get(
                                                                                                                     world
                                                                                                                  )
                                                                                                                  .syncData(world);
                                                                                                            }
                                                                                                         );
                                                                                                      }
                                                                                                   }
                                                                                                );
                                                                                             }
                                                                                          );
                                                                                       }
                                                                                    );
                                                                                 }
                                                                              );
                                                                           }
                                                                        );
                                                                     }
                                                                  );
                                                               }
                                                            );
                                                         }
                                                      );
                                                   }
                                                );
                                             }
                                          );
                                       }
                                    );
                                 }
                              );
                           }
                        );
                     }
                  );
               }
            );
         }
      }
   }
}
