package net.mcreator.insidethesystem.procedures;

import io.netty.buffer.Unpooled;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.mcreator.insidethesystem.world.inventory.Survey2Menu;
import net.mcreator.insidethesystem.world.inventory.Survey3Menu;
import net.mcreator.insidethesystem.world.inventory.Survey4Menu;
import net.mcreator.insidethesystem.world.inventory.Survey5Menu;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.registries.ForgeRegistries;

public class SurveysProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (entity instanceof Player _player) {
            _player.m_6915_();
         }

         InsideTheSystemMod.queueServerWork(
            70,
            () -> {
               if (InsideTheSystemModVariables.MapVariables.get(world).NumberOpen == 0.0) {
                  if (entity instanceof ServerPlayer _ent) {
                     final BlockPos _bpos = BlockPos.m_274561_(x, y, z);
                     NetworkHooks.openScreen(_ent, new MenuProvider() {
                        public Component m_5446_() {
                           return Component.m_237113_("Survey2");
                        }

                        public AbstractContainerMenu m_7208_(int id, Inventory inventory, Player player) {
                           return new Survey2Menu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).m_130064_(_bpos));
                        }
                     }, _bpos);
                  }

                  InsideTheSystemModVariables.MapVariables.get(world).NumberOpen = 1.0;
                  InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
               } else if (InsideTheSystemModVariables.MapVariables.get(world).NumberOpen == 1.0) {
                  if (entity instanceof ServerPlayer _ent) {
                     final BlockPos _bpos = BlockPos.m_274561_(x, y, z);
                     NetworkHooks.openScreen(_ent, new MenuProvider() {
                        public Component m_5446_() {
                           return Component.m_237113_("Survey3");
                        }

                        public AbstractContainerMenu m_7208_(int id, Inventory inventory, Player player) {
                           return new Survey3Menu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).m_130064_(_bpos));
                        }
                     }, _bpos);
                  }

                  InsideTheSystemModVariables.MapVariables.get(world).NumberOpen = 2.0;
                  InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
               } else if (InsideTheSystemModVariables.MapVariables.get(world).NumberOpen == 2.0) {
                  if (entity instanceof ServerPlayer _ent) {
                     final BlockPos _bpos = BlockPos.m_274561_(x, y, z);
                     NetworkHooks.openScreen(_ent, new MenuProvider() {
                        public Component m_5446_() {
                           return Component.m_237113_("Survey4");
                        }

                        public AbstractContainerMenu m_7208_(int id, Inventory inventory, Player player) {
                           return new Survey4Menu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).m_130064_(_bpos));
                        }
                     }, _bpos);
                  }

                  InsideTheSystemModVariables.MapVariables.get(world).NumberOpen = 3.0;
                  InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
               } else if (InsideTheSystemModVariables.MapVariables.get(world).NumberOpen == 3.0) {
                  if (entity instanceof ServerPlayer _ent) {
                     final BlockPos _bpos = BlockPos.m_274561_(x, y, z);
                     NetworkHooks.openScreen(_ent, new MenuProvider() {
                        public Component m_5446_() {
                           return Component.m_237113_("Survey5");
                        }

                        public AbstractContainerMenu m_7208_(int id, Inventory inventory, Player player) {
                           return new Survey5Menu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).m_130064_(_bpos));
                        }
                     }, _bpos);
                  }

                  InsideTheSystemModVariables.MapVariables.get(world).NumberOpen = 4.0;
                  InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
               } else if (InsideTheSystemModVariables.MapVariables.get(world).NumberOpen == 4.0) {
                  if (world instanceof Level _level) {
                     if (!_level.m_5776_()) {
                        _level.m_5594_(
                           null,
                           BlockPos.m_274561_(x, y, z),
                           (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:shagi")),
                           SoundSource.NEUTRAL,
                           1.0F,
                           1.0F
                        );
                     } else {
                        _level.m_7785_(
                           x,
                           y,
                           z,
                           (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:shagi")),
                           SoundSource.NEUTRAL,
                           1.0F,
                           1.0F,
                           false
                        );
                     }
                  }

                  InsideTheSystemModVariables.MapVariables.get(world).NumberOpen = 5.0;
                  InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
               }
            }
         );
      }
   }
}
