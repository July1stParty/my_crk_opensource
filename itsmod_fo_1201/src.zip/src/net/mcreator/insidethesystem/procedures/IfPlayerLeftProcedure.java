package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class IfPlayerLeftProcedure {
   @SubscribeEvent
   public static void onPlayerLoggedOut(PlayerLoggedOutEvent event) {
      execute(event, event.getEntity().m_9236_());
   }

   public static void execute(LevelAccessor world) {
      execute(null, world);
   }

   private static void execute(@Nullable Event event, LevelAccessor world) {
      InsideTheSystemModVariables.MapVariables.get(world).Inworld = false;
      InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      InsideTheSystemModVariables.MapVariables.get(world).worldDiedTemp = InsideTheSystemModVariables.MapVariables.get(world).WorldDied;
      InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      InsideTheSystemModVariables.MapVariables.get(world).WorldLifeTemp = InsideTheSystemModVariables.MapVariables.get(world).WorldLife;
      InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
   }
}
