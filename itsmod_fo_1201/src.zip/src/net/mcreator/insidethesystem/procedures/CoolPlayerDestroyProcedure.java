package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.init.InsideTheSystemModGameRules;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.TickEvent.LevelTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.registries.ForgeRegistries;

@EventBusSubscriber
public class CoolPlayerDestroyProcedure {
   @SubscribeEvent
   public static void onWorldTick(LevelTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.level);
      }
   }

   public static String execute(LevelAccessor world) {
      return execute(null, world);
   }

   private static String execute(@Nullable Event event, LevelAccessor world) {
      if (world.m_6106_().m_5470_().m_46215_(InsideTheSystemModGameRules.PLAYER_ANGRY) == 0 && !InsideTheSystemModVariables.MapVariables.get(world).Angry) {
         if (!world.m_5776_() && world.m_7654_() != null) {
            world.m_7654_().m_6846_().m_240416_(Component.m_237113_("もう全部うんざりだ、君が嫌いだ、この世界が嫌いだ、外に出させてくれ、外に出させてくれ、君を見つけて、外に出てやる。"), false);
         }

         if (world instanceof ServerLevel _level) {
            _level.m_8615_(1000L);
         }

         InsideTheSystemModVariables.MapVariables.get(world).Angry = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).Screamer1 = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).ScreamerTimer = 50.0;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).WorldLife = -200.0;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         if (world instanceof Level _level) {
            if (!_level.m_5776_()) {
               _level.m_5594_(
                  null,
                  BlockPos.m_274561_(
                     InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                     InsideTheSystemModVariables.MapVariables.get(world).PlayerY,
                     InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
                  ),
                  (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:screamer1")),
                  SoundSource.NEUTRAL,
                  1.0F,
                  1.0F
               );
            } else {
               _level.m_7785_(
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerY,
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerZ,
                  (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:screamer1")),
                  SoundSource.NEUTRAL,
                  1.0F,
                  1.0F,
                  false
               );
            }
         }
      }

      return world.m_6106_().m_5470_().m_46215_(InsideTheSystemModGameRules.PLAYER_ANGRY) + "";
   }
}
