package net.mcreator.insidethesystem.procedures;

import java.util.concurrent.atomic.AtomicInteger;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.init.InsideTheSystemModBlocks;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoorHingeSide;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

public class FinalDimensEnterProcedure {
   private static boolean isChecking = false;
   private static final int NO_NEIGHBOR_UPDATE_FLAG = 2;

   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null && world instanceof ServerLevel serverWorld) {
         if (entity instanceof LivingEntity livingEntity) {
            livingEntity.m_7292_(new MobEffectInstance(MobEffects.f_19591_, 99999, 3, false, false));
         }

         StructureTemplate template = serverWorld.m_215082_().m_230359_(new ResourceLocation("inside_the_system", "memory"));
         if (template != null) {
            template.m_230328_(
               serverWorld,
               new BlockPos(0, 100, 0),
               new BlockPos(0, 100, 0),
               new StructurePlaceSettings().m_74379_(Rotation.NONE).m_74377_(Mirror.NONE).m_74392_(false),
               serverWorld.f_46441_,
               2
            );
         }

         entity.m_6021_(9.0, 103.0, 6.0);
         if (entity instanceof ServerPlayer sp) {
            sp.f_8906_.m_9774_(9.0, 103.0, 6.0, entity.m_146908_(), entity.m_146909_());
         }

         double entX = entity.m_20185_();
         double entY = entity.m_20186_();
         double entZ = entity.m_20189_();
         runCommand(serverWorld, entX, entY, entZ, "/title @a times 20 60 20");
         runCommand(serverWorld, entX, entY, entZ, "/title @a subtitle {\"text\":\"Remember Everything\",\"italic\":true,\"color\":\"#DADADA\"}");
         InsideTheSystemMod.queueServerWork(80, () -> runCommand(serverWorld, entX, entY, entZ, "/title @a title {\"text\":\"ACT III\"}"));
         if (!isChecking) {
            isChecking = true;
            checkForBlocksAndStrikeRepeatedly(serverWorld, 3600);
         }
      }
   }

   private static void checkForBlocksAndStrikeRepeatedly(final ServerLevel world, final int durationTicks) {
      int checkInterval = 40;
      final Block targetBlock = (Block)InsideTheSystemModBlocks.ACTIVATE_GATE.get();
      int requiredCount = 4;
      int radius = 30;
      final BlockPos center = new BlockPos(10, 101, 6);
      final BlockPos doorPos = new BlockPos(10, 101, 16);
      final AtomicInteger ticksPassed = new AtomicInteger(0);
      Runnable repeatingTask = new Runnable() {
         @Override
         public void run() {
            if (world.m_7654_() != null && !world.m_7654_().m_129918_()) {
               if (ticksPassed.get() >= durationTicks) {
                  FinalDimensEnterProcedure.placeModDoor(world, doorPos);
                  FinalDimensEnterProcedure.isChecking = false;
               } else {
                  int count = 0;

                  for (int dx = -30; dx <= 30; dx++) {
                     for (int dy = -30; dy <= 30; dy++) {
                        for (int dz = -30; dz <= 30; dz++) {
                           BlockPos pos = center.m_7918_(dx, dy, dz);
                           if (world.m_8055_(pos).m_60713_(targetBlock)) {
                              count++;
                           }
                        }
                     }
                  }

                  if (count >= 4) {
                     FinalDimensEnterProcedure.strike(world, center);
                     FinalDimensEnterProcedure.placeModDoor(world, doorPos);
                     FinalDimensEnterProcedure.isChecking = false;
                  } else {
                     ticksPassed.addAndGet(40);
                     InsideTheSystemMod.queueServerWork(40, this);
                  }
               }
            } else {
               FinalDimensEnterProcedure.isChecking = false;
            }
         }
      };
      InsideTheSystemMod.queueServerWork(40, repeatingTask);
   }

   private static void strike(ServerLevel world, BlockPos center) {
      LightningBolt lightning = (LightningBolt)EntityType.f_20465_.m_20615_(world);
      if (lightning != null) {
         lightning.m_20219_(Vec3.m_82539_(center));
         lightning.m_20874_(false);
         world.m_7967_(lightning);
      }

      BlockState chestState = Blocks.f_50087_.m_49966_();
      world.m_46597_(center, chestState);
      if (world.m_7702_(center) instanceof ChestBlockEntity chest) {
         for (int i = 0; i < chest.m_6643_(); i++) {
            chest.m_6836_(i, ItemStack.f_41583_);
         }

         ResourceLocation starLocation = new ResourceLocation("inside_the_system", "starof_memories");
         ItemStack star = new ItemStack((ItemLike)ForgeRegistries.ITEMS.getValue(starLocation));
         star.m_41764_(1);
         chest.m_6836_(13, star);
         chest.m_6596_();
      }
   }

   private static void placeModDoor(ServerLevel world, BlockPos pos) {
      BlockState baseState = ((Block)InsideTheSystemModBlocks.MEMORY_DOORS.get()).m_49966_();
      BlockState lowerDoorState = (BlockState)((BlockState)((BlockState)baseState.m_61124_(DoorBlock.f_52730_, DoubleBlockHalf.LOWER))
            .m_61124_(DoorBlock.f_52726_, Direction.SOUTH))
         .m_61124_(DoorBlock.f_52728_, DoorHingeSide.LEFT);
      world.m_46597_(pos, lowerDoorState);
      BlockState upperDoorState = (BlockState)((BlockState)((BlockState)baseState.m_61124_(DoorBlock.f_52730_, DoubleBlockHalf.UPPER))
            .m_61124_(DoorBlock.f_52726_, Direction.SOUTH))
         .m_61124_(DoorBlock.f_52728_, DoorHingeSide.LEFT);
      world.m_46597_(pos.m_7494_(), upperDoorState);
      world.m_6263_(
         null,
         pos.m_123341_() + 0.5,
         pos.m_123342_() + 0.5,
         pos.m_123343_() + 0.5,
         (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:accept")),
         SoundSource.HOSTILE,
         1.0F,
         1.0F
      );
   }

   private static void runCommand(ServerLevel world, double x, double y, double z, String command) {
      world.m_7654_()
         .m_129892_()
         .m_230957_(
            new CommandSourceStack(CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, world, 4, "", Component.m_237119_(), world.m_7654_(), null)
               .m_81324_(),
            command
         );
   }
}
