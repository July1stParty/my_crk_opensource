package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.init.InsideTheSystemModItems;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.LevelAccessor;

public class SkipProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z) {
      if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife > 550000.0) {
         InsideTheSystemModVariables.MapVariables.get(world).WorldLife = 550000.0;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         if (world instanceof ServerLevel _level) {
            ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack((ItemLike)InsideTheSystemModItems.TIPS.get()));
            entityToSpawn.m_32010_(10);
            _level.m_7967_(entityToSpawn);
         }
      } else if (!world.m_5776_() && world.m_7654_() != null) {
         world.m_7654_().m_6846_().m_240416_(Component.m_237113_("§cThe introduction has already ended§r"), false);
      }
   }
}
