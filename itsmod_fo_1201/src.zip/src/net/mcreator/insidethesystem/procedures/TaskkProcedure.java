package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class TaskkProcedure {
   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_());
      }
   }

   public static void execute(LevelAccessor world) {
      execute(null, world);
   }

   private static void execute(@Nullable Event event, LevelAccessor world) {
      if (InsideTheSystemModVariables.MapVariables.get(world).Taskk) {
         InsideTheSystemMod.queueServerWork(
            1200,
            () -> {
               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> I just remembered something else... please listen"), false);
               }

               InsideTheSystemMod.queueServerWork(
                  70,
                  () -> {
                     if (!world.m_5776_() && world.m_7654_() != null) {
                        world.m_7654_()
                           .m_6846_()
                           .m_240416_(
                              Component.m_237113_("<CoolPlayer303> For some reason, I remember my mother... one day, she gave me something very important"),
                              false
                           );
                     }

                     InsideTheSystemMod.queueServerWork(
                        70,
                        () -> {
                           if (!world.m_5776_() && world.m_7654_() != null) {
                              world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> I think it was an amulet—yes, that’s it!!"), false);
                           }

                           InsideTheSystemMod.queueServerWork(
                              70,
                              () -> {
                                 if (!world.m_5776_() && world.m_7654_() != null) {
                                    world.m_7654_()
                                       .m_6846_()
                                       .m_240416_(
                                          Component.m_237113_("<CoolPlayer303> Please, if it’s not too much trouble... could you find it or make one for me?"),
                                          false
                                       );
                                 }

                                 InsideTheSystemMod.queueServerWork(
                                    70,
                                    () -> {
                                       if (!world.m_5776_() && world.m_7654_() != null) {
                                          world.m_7654_()
                                             .m_6846_()
                                             .m_240416_(
                                                Component.m_237113_("<CoolPlayer303> I would be so grateful... it might help me get my memories back"), false
                                             );
                                       }

                                       InsideTheSystemMod.queueServerWork(
                                          70,
                                          () -> {
                                             if (!world.m_5776_() && world.m_7654_() != null) {
                                                world.m_7654_()
                                                   .m_6846_()
                                                   .m_240416_(
                                                      Component.m_237113_("<CoolPlayer303> I think it was made of a nautilus shell and some threads"), false
                                                   );
                                             }
                                          }
                                       );
                                    }
                                 );
                              }
                           );
                        }
                     );
                  }
               );
            }
         );
         InsideTheSystemModVariables.MapVariables.get(world).Taskk = false;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }
   }
}
