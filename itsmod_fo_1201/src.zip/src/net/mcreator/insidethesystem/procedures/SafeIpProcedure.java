package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.LevelAccessor;

public class SafeIpProcedure {
   public static void execute(LevelAccessor world) {
      if (!InsideTheSystemModVariables.MapVariables.get(world).safeip) {
         InsideTheSystemModVariables.MapVariables.get(world).safeip = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         if (!world.m_5776_() && world.m_7654_() != null) {
            world.m_7654_().m_6846_().m_240416_(Component.m_237113_("Safe Ip Enabled"), false);
         }
      } else {
         InsideTheSystemModVariables.MapVariables.get(world).safeip = false;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         if (!world.m_5776_() && world.m_7654_() != null) {
            world.m_7654_().m_6846_().m_240416_(Component.m_237113_("Safe Ip Disabled"), false);
         }
      }
   }
}
