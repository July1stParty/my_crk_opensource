package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundGameEventPacket;
import net.minecraft.network.protocol.game.ClientboundLevelEventPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerAbilitiesPacket;
import net.minecraft.network.protocol.game.ClientboundUpdateMobEffectPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class PlayerUpdateProcedure {
   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player.m_20185_(), event.player.m_20186_(), event.player.m_20189_(), event.player);
      }
   }

   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      execute(null, world, x, y, z, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         InsideTheSystemModVariables.MapVariables.get(world).PlayerX = entity.m_20185_();
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).PlayerY = entity.m_20186_();
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).PlayerZ = entity.m_20189_();
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         if (InsideTheSystemModVariables.MapVariables.get(world).dimens && entity instanceof ServerPlayer _player && !_player.m_9236_().m_5776_()) {
            ResourceKey<Level> destinationType = ResourceKey.m_135785_(Registries.f_256858_, new ResourceLocation("inside_the_system:password"));
            if (_player.m_9236_().m_46472_() == destinationType) {
               return;
            }

            ServerLevel nextLevel = _player.f_8924_.m_129880_(destinationType);
            if (nextLevel != null) {
               _player.f_8906_.m_9829_(new ClientboundGameEventPacket(ClientboundGameEventPacket.f_132157_, 0.0F));
               _player.m_8999_(nextLevel, _player.m_20185_(), _player.m_20186_(), _player.m_20189_(), _player.m_146908_(), _player.m_146909_());
               _player.f_8906_.m_9829_(new ClientboundPlayerAbilitiesPacket(_player.m_150110_()));

               for (MobEffectInstance _effectinstance : _player.m_21220_()) {
                  _player.f_8906_.m_9829_(new ClientboundUpdateMobEffectPacket(_player.m_19879_(), _effectinstance));
               }

               _player.f_8906_.m_9829_(new ClientboundLevelEventPacket(1032, BlockPos.f_121853_, 0, false));
            }
         }

         if (InsideTheSystemModVariables.MapVariables.get(world).DialogueNum == 4.0) {
            if (world instanceof ServerLevel _level) {
               _level.m_7654_()
                  .m_129892_()
                  .m_230957_(
                     new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                        )
                        .m_81324_(),
                     "/title @a times 20 60 20"
                  );
            }

            if (world instanceof ServerLevel _level) {
               _level.m_7654_()
                  .m_129892_()
                  .m_230957_(
                     new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                        )
                        .m_81324_(),
                     "/title @a subtitle {\"text\":\"Mental confusion\",\"italic\":true,\"color\":\"#DADADA\"}"
                  );
            }

            if (world instanceof ServerLevel _level) {
               _level.m_7654_()
                  .m_129892_()
                  .m_230957_(
                     new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                        )
                        .m_81324_(),
                     "/title @a title {\"text\":\"Ending D\"}"
                  );
            }

            InsideTheSystemModVariables.MapVariables.get(world).DialogueNum = 20.0;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }

         if (InsideTheSystemModVariables.MapVariables.get(world).AllItems) {
            InsideTheSystemModVariables.MapVariables.get(world).WorldLife = -200.0;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }
      }
   }
}
