package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.init.InsideTheSystemModGameRules;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameRules.IntegerValue;
import net.minecraftforge.event.TickEvent.LevelTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class WorldLifeProcedure {
   @SubscribeEvent
   public static void onWorldTick(LevelTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.level);
      }
   }

   public static String execute(LevelAccessor world) {
      return execute(null, world);
   }

   private static String execute(@Nullable Event event, LevelAccessor world) {
      if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife <= 600000.0
         && !InsideTheSystemModVariables.MapVariables.get(world).Angry
         && InsideTheSystemModVariables.MapVariables.get(world).WorldLife != 0.0) {
         InsideTheSystemModVariables.MapVariables.get(world).WorldLife--;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife == 575000.0) {
         InsideTheSystemModVariables.MapVariables.get(world).Tips = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife == 550000.0) {
         InsideTheSystemModVariables.MapVariables.get(world).Task = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).Task1T = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife == 500000.0) {
         InsideTheSystemModVariables.MapVariables.get(world).Steam = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife == 450000.0 && !InsideTheSystemModVariables.MapVariables.get(world).quest1) {
         InsideTheSystemModVariables.MapVariables.get(world).Times = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife == 400000.0) {
         if (!InsideTheSystemModVariables.MapVariables.get(world).quest1) {
            InsideTheSystemModVariables.MapVariables.get(world).Task1 = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemModVariables.MapVariables.get(world).Task1SEC = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemModVariables.MapVariables.get(world).Taskkk = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemModVariables.MapVariables.get(world).Task2T = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         } else {
            InsideTheSystemModVariables.MapVariables.get(world).Taskkk = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemModVariables.MapVariables.get(world).Task2T = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife == 350000.0) {
         InsideTheSystemModVariables.MapVariables.get(world).BlockDialogue = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife == 300000.0 && !InsideTheSystemModVariables.MapVariables.get(world).quest2) {
         InsideTheSystemModVariables.MapVariables.get(world).Times = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife == 250000.0) {
         if (!InsideTheSystemModVariables.MapVariables.get(world).quest2) {
            InsideTheSystemModVariables.MapVariables.get(world).Task2 = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemModVariables.MapVariables.get(world).Taskk = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemModVariables.MapVariables.get(world).Task3T = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         } else {
            InsideTheSystemModVariables.MapVariables.get(world).Taskk = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemModVariables.MapVariables.get(world).Task3T = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife == 200000.0) {
         InsideTheSystemModVariables.MapVariables.get(world).Change = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife == 150000.0 && !InsideTheSystemModVariables.MapVariables.get(world).quest3) {
         InsideTheSystemModVariables.MapVariables.get(world).Times = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife == 100000.0 && !InsideTheSystemModVariables.MapVariables.get(world).quest3) {
         InsideTheSystemModVariables.MapVariables.get(world).Task3 = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife == 50000.0) {
         InsideTheSystemModVariables.MapVariables.get(world).Survey = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldLife == 0.0) {
         InsideTheSystemModVariables.MapVariables.get(world).WorldLife = -200.0;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         if (!InsideTheSystemModVariables.MapVariables.get(world).quest3
            && !InsideTheSystemModVariables.MapVariables.get(world).quest2
            && !InsideTheSystemModVariables.MapVariables.get(world).quest1) {
            InsideTheSystemModVariables.MapVariables.get(world).TaskEnd3 = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemModVariables.MapVariables.get(world).TaskDialogue = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            ((IntegerValue)world.m_6106_().m_5470_().m_46170_(InsideTheSystemModGameRules.PLAYER_ANGRY)).m_151489_(26, world.m_7654_());
         } else if ((InsideTheSystemModVariables.MapVariables.get(world).quest3 || InsideTheSystemModVariables.MapVariables.get(world).quest2)
            && (InsideTheSystemModVariables.MapVariables.get(world).quest3 || InsideTheSystemModVariables.MapVariables.get(world).quest1)
            && (InsideTheSystemModVariables.MapVariables.get(world).quest1 || InsideTheSystemModVariables.MapVariables.get(world).quest2)) {
            if (!InsideTheSystemModVariables.MapVariables.get(world).quest3
               || !InsideTheSystemModVariables.MapVariables.get(world).quest2
               || !InsideTheSystemModVariables.MapVariables.get(world).quest1) {
               InsideTheSystemModVariables.MapVariables.get(world).TaskEnd1 = true;
               InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            }
         } else {
            InsideTheSystemModVariables.MapVariables.get(world).TaskEnd2 = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            ((IntegerValue)world.m_6106_().m_5470_().m_46170_(InsideTheSystemModGameRules.PLAYER_ANGRY)).m_151489_(26, world.m_7654_());
            InsideTheSystemModVariables.MapVariables.get(world).TaskDialogue = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }
      }

      return InsideTheSystemModVariables.MapVariables.get(world).WorldLife + "";
   }
}
