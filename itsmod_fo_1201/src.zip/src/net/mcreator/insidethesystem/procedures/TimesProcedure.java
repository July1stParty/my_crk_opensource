package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class TimesProcedure {
   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_());
      }
   }

   public static void execute(LevelAccessor world) {
      execute(null, world);
   }

   private static void execute(@Nullable Event event, LevelAccessor world) {
      if (InsideTheSystemModVariables.MapVariables.get(world).Times) {
         InsideTheSystemModVariables.MapVariables.get(world).Times = false;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).TimerN = 1.0;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         if (!world.m_5776_() && world.m_7654_() != null) {
            world.m_7654_().m_6846_().m_240416_(Component.m_237113_("The execution time is coming to an end..."), false);
         }

         InsideTheSystemMod.queueServerWork(80, () -> {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("IT is coming..."), false);
            }
         });
      } else if (InsideTheSystemModVariables.MapVariables.get(world).Times && InsideTheSystemModVariables.MapVariables.get(world).TimerN == 1.0) {
         InsideTheSystemModVariables.MapVariables.get(world).Times = false;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).TimerN = 2.0;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         if (!world.m_5776_() && world.m_7654_() != null) {
            world.m_7654_().m_6846_().m_240416_(Component.m_237113_("The execution time is coming to an end..."), false);
         }

         InsideTheSystemMod.queueServerWork(80, () -> {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("Turn around.."), false);
            }
         });
      } else if (InsideTheSystemModVariables.MapVariables.get(world).Times && InsideTheSystemModVariables.MapVariables.get(world).TimerN == 2.0) {
         InsideTheSystemModVariables.MapVariables.get(world).Times = false;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).TimerN = 3.0;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         if (!world.m_5776_() && world.m_7654_() != null) {
            world.m_7654_().m_6846_().m_240416_(Component.m_237113_("The execution time is coming to an end..."), false);
         }

         InsideTheSystemMod.queueServerWork(80, () -> {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("...."), false);
            }
         });
      }
   }
}
