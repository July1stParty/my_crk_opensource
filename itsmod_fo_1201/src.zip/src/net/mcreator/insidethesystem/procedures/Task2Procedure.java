package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.entity.Father2Entity;
import net.mcreator.insidethesystem.init.InsideTheSystemModEntities;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.arguments.EntityAnchorArgument.Anchor;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.registries.ForgeRegistries;

@EventBusSubscriber
public class Task2Procedure {
   private static volatile boolean dialogTriggered = false;

   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player.m_20185_(), event.player.m_20186_(), event.player.m_20189_(), event.player);
      }
   }

   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      execute(null, world, x, y, z, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (InsideTheSystemModVariables.MapVariables.get(world).Task2 && !dialogTriggered) {
            dialogTriggered = true;
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_(";*?)%?"), false);
            }

            InsideTheSystemMod.queueServerWork(
               20,
               () -> {
                  if (!world.m_5776_() && world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("HE TAKES CONTROL"), false);
                  }

                  InsideTheSystemMod.queueServerWork(
                     20,
                     () -> {
                        if (world instanceof Level _level) {
                           if (!_level.m_5776_()) {
                              _level.m_5594_(
                                 null,
                                 new BlockPos((int)x, (int)y, (int)z),
                                 (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:thesun")),
                                 SoundSource.NEUTRAL,
                                 1.0F,
                                 1.0F
                              );
                           } else {
                              _level.m_7785_(
                                 x,
                                 y,
                                 z,
                                 (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:thesun")),
                                 SoundSource.NEUTRAL,
                                 1.0F,
                                 1.0F,
                                 false
                              );
                           }
                        }

                        if (world instanceof ServerLevel _levelx) {
                           _levelx.m_7654_()
                              .m_129892_()
                              .m_230957_(
                                 new CommandSourceStack(
                                       CommandSource.f_80164_,
                                       new Vec3(x, y, z),
                                       Vec2.f_82462_,
                                       _levelx,
                                       4,
                                       "",
                                       Component.m_237113_(""),
                                       _levelx.m_7654_(),
                                       null
                                    )
                                    .m_81324_(),
                                 "time set night"
                              );
                        }

                        InsideTheSystemMod.queueServerWork(
                           50,
                           () -> {
                              if (world instanceof ServerLevel _levelx) {
                                 _levelx.m_7654_()
                                    .m_129892_()
                                    .m_230957_(
                                       new CommandSourceStack(
                                             CommandSource.f_80164_,
                                             new Vec3(x, y, z),
                                             Vec2.f_82462_,
                                             _levelx,
                                             4,
                                             "",
                                             Component.m_237113_(""),
                                             _levelx.m_7654_(),
                                             null
                                          )
                                          .m_81324_(),
                                       "time set day"
                                    );
                              }

                              InsideTheSystemMod.queueServerWork(
                                 45,
                                 () -> {
                                    if (world instanceof ServerLevel _levelxx) {
                                       _levelxx.m_7654_()
                                          .m_129892_()
                                          .m_230957_(
                                             new CommandSourceStack(
                                                   CommandSource.f_80164_,
                                                   new Vec3(x, y, z),
                                                   Vec2.f_82462_,
                                                   _levelxx,
                                                   4,
                                                   "",
                                                   Component.m_237113_(""),
                                                   _levelxx.m_7654_(),
                                                   null
                                                )
                                                .m_81324_(),
                                             "time set night"
                                          );
                                    }

                                    InsideTheSystemMod.queueServerWork(
                                       40,
                                       () -> {
                                          if (world instanceof ServerLevel _levelxxx) {
                                             _levelxxx.m_7654_()
                                                .m_129892_()
                                                .m_230957_(
                                                   new CommandSourceStack(
                                                         CommandSource.f_80164_,
                                                         new Vec3(x, y, z),
                                                         Vec2.f_82462_,
                                                         _levelxxx,
                                                         4,
                                                         "",
                                                         Component.m_237113_(""),
                                                         _levelxxx.m_7654_(),
                                                         null
                                                      )
                                                      .m_81324_(),
                                                   "time set day"
                                                );
                                          }

                                          InsideTheSystemMod.queueServerWork(
                                             35,
                                             () -> {
                                                if (world instanceof ServerLevel _levelxxxx) {
                                                   _levelxxxx.m_7654_()
                                                      .m_129892_()
                                                      .m_230957_(
                                                         new CommandSourceStack(
                                                               CommandSource.f_80164_,
                                                               new Vec3(x, y, z),
                                                               Vec2.f_82462_,
                                                               _levelxxxx,
                                                               4,
                                                               "",
                                                               Component.m_237113_(""),
                                                               _levelxxxx.m_7654_(),
                                                               null
                                                            )
                                                            .m_81324_(),
                                                         "time set night"
                                                      );
                                                }

                                                InsideTheSystemMod.queueServerWork(
                                                   30,
                                                   () -> {
                                                      if (world instanceof ServerLevel _levelxxxxx) {
                                                         _levelxxxxx.m_7654_()
                                                            .m_129892_()
                                                            .m_230957_(
                                                               new CommandSourceStack(
                                                                     CommandSource.f_80164_,
                                                                     new Vec3(x, y, z),
                                                                     Vec2.f_82462_,
                                                                     _levelxxxxx,
                                                                     4,
                                                                     "",
                                                                     Component.m_237113_(""),
                                                                     _levelxxxxx.m_7654_(),
                                                                     null
                                                                  )
                                                                  .m_81324_(),
                                                               "time set day"
                                                            );
                                                      }

                                                      InsideTheSystemMod.queueServerWork(
                                                         25,
                                                         () -> {
                                                            if (world instanceof ServerLevel _levelxxxxxx) {
                                                               _levelxxxxxx.m_7654_()
                                                                  .m_129892_()
                                                                  .m_230957_(
                                                                     new CommandSourceStack(
                                                                           CommandSource.f_80164_,
                                                                           new Vec3(x, y, z),
                                                                           Vec2.f_82462_,
                                                                           _levelxxxxxx,
                                                                           4,
                                                                           "",
                                                                           Component.m_237113_(""),
                                                                           _levelxxxxxx.m_7654_(),
                                                                           null
                                                                        )
                                                                        .m_81324_(),
                                                                     "time set night"
                                                                  );
                                                            }

                                                            InsideTheSystemMod.queueServerWork(
                                                               20,
                                                               () -> {
                                                                  if (world instanceof ServerLevel _levelxxxxxxx) {
                                                                     _levelxxxxxxx.m_7654_()
                                                                        .m_129892_()
                                                                        .m_230957_(
                                                                           new CommandSourceStack(
                                                                                 CommandSource.f_80164_,
                                                                                 new Vec3(x, y, z),
                                                                                 Vec2.f_82462_,
                                                                                 _levelxxxxxxx,
                                                                                 4,
                                                                                 "",
                                                                                 Component.m_237113_(""),
                                                                                 _levelxxxxxxx.m_7654_(),
                                                                                 null
                                                                              )
                                                                              .m_81324_(),
                                                                           "time set day"
                                                                        );
                                                                  }

                                                                  InsideTheSystemMod.queueServerWork(
                                                                     15,
                                                                     () -> {
                                                                        if (world instanceof ServerLevel _levelxxxxxxxx) {
                                                                           _levelxxxxxxxx.m_7654_()
                                                                              .m_129892_()
                                                                              .m_230957_(
                                                                                 new CommandSourceStack(
                                                                                       CommandSource.f_80164_,
                                                                                       new Vec3(x, y, z),
                                                                                       Vec2.f_82462_,
                                                                                       _levelxxxxxxxx,
                                                                                       4,
                                                                                       "",
                                                                                       Component.m_237113_(""),
                                                                                       _levelxxxxxxxx.m_7654_(),
                                                                                       null
                                                                                    )
                                                                                    .m_81324_(),
                                                                                 "time set night"
                                                                              );
                                                                        }

                                                                        InsideTheSystemMod.queueServerWork(
                                                                           10,
                                                                           () -> {
                                                                              if (world instanceof ServerLevel _levelxxxxxxxxx) {
                                                                                 _levelxxxxxxxxx.m_7654_()
                                                                                    .m_129892_()
                                                                                    .m_230957_(
                                                                                       new CommandSourceStack(
                                                                                             CommandSource.f_80164_,
                                                                                             new Vec3(x, y, z),
                                                                                             Vec2.f_82462_,
                                                                                             _levelxxxxxxxxx,
                                                                                             4,
                                                                                             "",
                                                                                             Component.m_237113_(""),
                                                                                             _levelxxxxxxxxx.m_7654_(),
                                                                                             null
                                                                                          )
                                                                                          .m_81324_(),
                                                                                       "time set day"
                                                                                    );
                                                                              }

                                                                              InsideTheSystemMod.queueServerWork(
                                                                                 5,
                                                                                 () -> {
                                                                                    if (world instanceof ServerLevel _levelxxxxxxxxxxx) {
                                                                                       _levelxxxxxxxxxxx.m_7654_()
                                                                                          .m_129892_()
                                                                                          .m_230957_(
                                                                                             new CommandSourceStack(
                                                                                                   CommandSource.f_80164_,
                                                                                                   new Vec3(x, y, z),
                                                                                                   Vec2.f_82462_,
                                                                                                   _levelxxxxxxxxxxx,
                                                                                                   4,
                                                                                                   "",
                                                                                                   Component.m_237113_(""),
                                                                                                   _levelxxxxxxxxxxx.m_7654_(),
                                                                                                   null
                                                                                                )
                                                                                                .m_81324_(),
                                                                                             "time set night"
                                                                                          );
                                                                                    }

                                                                                    if (entity instanceof LivingEntity _entity && !_entity.m_9236_().m_5776_()) {
                                                                                       _entity.m_7292_(
                                                                                          new MobEffectInstance(MobEffects.f_19610_, 2000, 3, false, false)
                                                                                       );
                                                                                    }

                                                                                    if (entity instanceof LivingEntity _entity && !_entity.m_9236_().m_5776_()) {
                                                                                       _entity.m_7292_(
                                                                                          new MobEffectInstance(MobEffects.f_19597_, 2000, 3, false, false)
                                                                                       );
                                                                                    }

                                                                                    if (world instanceof ServerLevel _levelxxxxxxxxxx) {
                                                                                       Entity entityToSpawn = new Father2Entity(
                                                                                          (EntityType<Father2Entity>)InsideTheSystemModEntities.FATHER_2.get(),
                                                                                          _levelxxxxxxxxxx
                                                                                       );
                                                                                       entityToSpawn.m_7678_(
                                                                                          x, y, z + 2.0, world.m_213780_().m_188501_() * 360.0F, 0.0F
                                                                                       );
                                                                                       if (entityToSpawn instanceof Mob _mobToSpawn) {
                                                                                          _mobToSpawn.m_6518_(
                                                                                             _levelxxxxxxxxxx,
                                                                                             world.m_6436_(entityToSpawn.m_20183_()),
                                                                                             MobSpawnType.MOB_SUMMONED,
                                                                                             null,
                                                                                             null
                                                                                          );
                                                                                       }

                                                                                       world.m_7967_(entityToSpawn);
                                                                                    }

                                                                                    entity.m_7618_(Anchor.EYES, new Vec3(x, y + 1.0, z + 2.0));
                                                                                    InsideTheSystemMod.queueServerWork(
                                                                                       20,
                                                                                       () -> {
                                                                                          if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                             world.m_7654_()
                                                                                                .m_6846_()
                                                                                                .m_240416_(
                                                                                                   Component.m_237113_("<§k:#№;%;?§r> Well, well… hello there…"),
                                                                                                   false
                                                                                                );
                                                                                          }

                                                                                          InsideTheSystemMod.queueServerWork(
                                                                                             80,
                                                                                             () -> {
                                                                                                if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                   world.m_7654_()
                                                                                                      .m_6846_()
                                                                                                      .m_240416_(
                                                                                                         Component.m_237113_(
                                                                                                            "<§k:#№;%;?§r> I see you’ve failed the second task too?"
                                                                                                         ),
                                                                                                         false
                                                                                                      );
                                                                                                }

                                                                                                InsideTheSystemMod.queueServerWork(
                                                                                                   80,
                                                                                                   () -> {
                                                                                                      if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                         world.m_7654_()
                                                                                                            .m_6846_()
                                                                                                            .m_240416_(
                                                                                                               Component.m_237113_(
                                                                                                                  "<§k:#№;%;?§r> Thank you… SHE keeps losing her memory, piece by piece… and that allows me to slip further into this world."
                                                                                                               ),
                                                                                                               false
                                                                                                            );
                                                                                                      }

                                                                                                      InsideTheSystemMod.queueServerWork(
                                                                                                         80,
                                                                                                         () -> {
                                                                                                            if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                               world.m_7654_()
                                                                                                                  .m_6846_()
                                                                                                                  .m_240416_(
                                                                                                                     Component.m_237113_(
                                                                                                                        "<§k:#№;%;?§r> I have an offer for you…"
                                                                                                                     ),
                                                                                                                     false
                                                                                                                  );
                                                                                                            }

                                                                                                            InsideTheSystemMod.queueServerWork(
                                                                                                               80,
                                                                                                               () -> {
                                                                                                                  if (!world.m_5776_()
                                                                                                                     && world.m_7654_() != null) {
                                                                                                                     world.m_7654_()
                                                                                                                        .m_6846_()
                                                                                                                        .m_240416_(
                                                                                                                           Component.m_237113_(
                                                                                                                              "<§k:#№;%;?§r> Fail every task… make her forget who she really is."
                                                                                                                           ),
                                                                                                                           false
                                                                                                                        );
                                                                                                                  }

                                                                                                                  InsideTheSystemMod.queueServerWork(
                                                                                                                     80,
                                                                                                                     () -> {
                                                                                                                        if (!world.m_5776_()
                                                                                                                           && world.m_7654_() != null) {
                                                                                                                           world.m_7654_()
                                                                                                                              .m_6846_()
                                                                                                                              .m_240416_(
                                                                                                                                 Component.m_237113_(
                                                                                                                                    "<§k:#№;%;?§r> And then…"
                                                                                                                                 ),
                                                                                                                                 false
                                                                                                                              );
                                                                                                                        }

                                                                                                                        InsideTheSystemModVariables.MapVariables.get(
                                                                                                                              world
                                                                                                                           )
                                                                                                                           .OBS = true;
                                                                                                                        InsideTheSystemModVariables.MapVariables.get(
                                                                                                                              world
                                                                                                                           )
                                                                                                                           .syncData(world);
                                                                                                                     }
                                                                                                                  );
                                                                                                               }
                                                                                                            );
                                                                                                         }
                                                                                                      );
                                                                                                   }
                                                                                                );
                                                                                             }
                                                                                          );
                                                                                       }
                                                                                    );
                                                                                    InsideTheSystemModVariables.MapVariables.get(world).Task2 = false;
                                                                                    InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
                                                                                    dialogTriggered = false;
                                                                                 }
                                                                              );
                                                                           }
                                                                        );
                                                                     }
                                                                  );
                                                               }
                                                            );
                                                         }
                                                      );
                                                   }
                                                );
                                             }
                                          );
                                       }
                                    );
                                 }
                              );
                           }
                        );
                     }
                  );
               }
            );
         }
      }
   }
}
