package net.mcreator.insidethesystem.procedures;

import java.util.Arrays;
import javax.annotation.Nullable;
import net.mcreator.insidethesystem.entity.CoolPlayer303Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class PlayerDiedProcedure {
   @SubscribeEvent
   public static void onEntityDeath(LivingDeathEvent event) {
      if (event != null && event.getEntity() != null) {
         execute(event, event.getEntity().m_9236_(), event.getEntity());
      }
   }

   public static void execute(LevelAccessor world, Entity entity) {
      execute(null, world, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
      if (entity != null) {
         if (entity instanceof CoolPlayer303Entity) {
            dropAllEquipment((CoolPlayer303Entity)entity);
         }
      }
   }

   private static void dropAllEquipment(CoolPlayer303Entity entity) {
      if (entity.m_9236_() instanceof ServerLevel) {
         for (EquipmentSlot slot : Arrays.asList(
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND
         )) {
            ItemStack stack = entity.m_6844_(slot);
            if (!stack.m_41619_()) {
               Vec3 pos = entity.m_20182_();
               ItemEntity itemEntity = new ItemEntity(entity.m_9236_(), pos.m_7096_(), pos.m_7098_() + 0.5, pos.m_7094_(), stack.m_41777_());
               itemEntity.m_32010_(10);
               entity.m_9236_().m_7967_(itemEntity);
               entity.m_8061_(slot, ItemStack.f_41583_);
            }
         }
      }
   }
}
