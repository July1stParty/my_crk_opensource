package net.mcreator.insidethesystem.procedures;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;

public class PswEnterProcedure {
   public static void execute(LevelAccessor world, Entity entity) {
      if (entity != null) {
         if (world instanceof ServerLevel _serverworld) {
            StructureTemplate template = _serverworld.m_215082_().m_230359_(new ResourceLocation("inside_the_system", "tunnel"));
            if (template != null) {
               template.m_230328_(
                  _serverworld,
                  new BlockPos(0, 0, 0),
                  new BlockPos(0, 0, 0),
                  new StructurePlaceSettings().m_74379_(Rotation.NONE).m_74377_(Mirror.NONE).m_74392_(false),
                  _serverworld.f_46441_,
                  3
               );
            }
         }

         entity.m_6021_(4.0, 1.0, 1.0);
         if (entity instanceof ServerPlayer _serverPlayer) {
            _serverPlayer.f_8906_.m_9774_(4.0, 1.0, 1.0, entity.m_146908_(), entity.m_146909_());
         }
      }
   }
}
