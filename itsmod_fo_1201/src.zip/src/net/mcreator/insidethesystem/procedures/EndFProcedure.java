package net.mcreator.insidethesystem.procedures;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Collections;
import javax.annotation.Nullable;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class EndFProcedure {
   private static int tickCounter = 0;
   private static boolean isCounting = false;

   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player.m_20185_(), event.player.m_20186_(), event.player.m_20189_());
      }
   }

   public static void execute(LevelAccessor world, double x, double y, double z) {
      execute(null, world, x, y, z);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z) {
      if (InsideTheSystemModVariables.MapVariables.get(world).Endingf) {
         if (!isCounting) {
            isCounting = true;
            tickCounter = 0;
         }

         tickCounter++;
         if (tickCounter >= 300 && world instanceof ServerLevel _level) {
            isCounting = false;
            tickCounter = 0;
            InsideTheSystemModVariables.MapVariables.get(world).kick = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            _level.m_7654_()
               .m_129892_()
               .m_230957_(
                  new CommandSourceStack(
                        CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                     )
                     .m_81324_(),
                  "kick @a"
               );
            if (System.getProperty("os.name").toLowerCase().contains("win")) {
               try {
                  Runtime.getRuntime().exec("powershell -command \"(New-Object -ComObject Shell.Application).MinimizeAll()\"");
               } catch (IOException var13) {
                  var13.printStackTrace();
               }
            }

            try {
               Path desktopPath = getDesktopPath();
               Path codeFile = desktopPath.resolve("code.txt");
               String codeText = "7H#j9K!p2@Qm5*W - Betrayal\n";
               if (Files.exists(codeFile)) {
                  Files.write(codeFile, Collections.singletonList(codeText), StandardOpenOption.APPEND);
               } else {
                  Files.write(codeFile, Collections.singletonList(codeText));
               }
            } catch (IOException var12) {
               var12.printStackTrace();
            }

            InsideTheSystemModVariables.MapVariables.get(world).Endingf = false;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }
      } else {
         isCounting = false;
         tickCounter = 0;
      }
   }

   private static Path getDesktopPath() throws IOException {
      Path homePath = Paths.get(System.getProperty("user.home"));
      Path oneDrivePath = homePath.resolve("OneDrive");
      Path desktopPath;
      if (Files.exists(oneDrivePath)) {
         desktopPath = oneDrivePath.resolve("Рабочий стол");
         if (!Files.exists(desktopPath)) {
            desktopPath = oneDrivePath.resolve("Desktop");
         }
      } else {
         desktopPath = homePath.resolve("Desktop");
         if (!Files.exists(desktopPath)) {
            Path xdgDesktop = homePath.resolve("Рабочий стол");
            if (Files.exists(xdgDesktop)) {
               desktopPath = xdgDesktop;
            }
         }
      }

      if (!Files.exists(desktopPath)) {
         Files.createDirectories(desktopPath);
      }

      return desktopPath;
   }
}
