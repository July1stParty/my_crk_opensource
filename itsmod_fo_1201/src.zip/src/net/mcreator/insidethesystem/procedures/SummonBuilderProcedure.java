package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.init.InsideTheSystemModEntities;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.TickEvent.LevelTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class SummonBuilderProcedure {
   @SubscribeEvent
   public static void onWorldTick(LevelTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.level);
      }
   }

   public static void execute(LevelAccessor world) {
      execute(null, world);
   }

   private static void execute(@Nullable Event event, LevelAccessor world) {
      if (InsideTheSystemModVariables.MapVariables.get(world).summon) {
         if (InsideTheSystemModVariables.MapVariables.get(world).isBlockEmpty) {
            if (world instanceof ServerLevel _level) {
               Entity entityToSpawn = ((EntityType)InsideTheSystemModEntities.ANGRY_BUILDER.get())
                  .m_262496_(
                     _level,
                     BlockPos.m_274561_(
                        InsideTheSystemModVariables.MapVariables.get(world).PlayerX + 3.0,
                        InsideTheSystemModVariables.MapVariables.get(world).PlayerY,
                        InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
                     ),
                     MobSpawnType.MOB_SUMMONED
                  );
               if (entityToSpawn != null) {
                  entityToSpawn.m_146922_(world.m_213780_().m_188501_() * 360.0F);
               }
            }

            InsideTheSystemModVariables.MapVariables.get(world).builderLook = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemModVariables.MapVariables.get(world).summon = false;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         } else {
            if (world instanceof ServerLevel _levelx) {
               Entity entityToSpawn = ((EntityType)InsideTheSystemModEntities.ANGRY_BUILDER.get())
                  .m_262496_(
                     _levelx,
                     BlockPos.m_274561_(
                        InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                        InsideTheSystemModVariables.MapVariables.get(world).PlayerY,
                        InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
                     ),
                     MobSpawnType.MOB_SUMMONED
                  );
               if (entityToSpawn != null) {
                  entityToSpawn.m_146922_(world.m_213780_().m_188501_() * 360.0F);
               }
            }

            InsideTheSystemModVariables.MapVariables.get(world).builderLook = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemModVariables.MapVariables.get(world).summon = false;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }
      }
   }
}
