package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.entity.CoolPlayer303Entity;
import net.mcreator.insidethesystem.init.InsideTheSystemModGameRules;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.entity.living.LivingEvent.LivingTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class AllItemsProcedure {
   @SubscribeEvent
   public static void onEntityTick(LivingTickEvent event) {
      execute(event, event.getEntity().m_9236_(), event.getEntity());
   }

   public static void execute(LevelAccessor world, Entity entity) {
      execute(null, world, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
      if (!world.m_5776_()) {
         if (entity != null) {
            if (InsideTheSystemModVariables.MapVariables.get(world).AllItems && entity instanceof CoolPlayer303Entity) {
               if (InsideTheSystemModVariables.MapVariables.get(world).HasPlayedDialog) {
                  return;
               }

               InsideTheSystemModVariables.MapVariables.get(world).HasPlayedDialog = true;
               InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
               int delay = 150;
               int playerAngryValue = 0;
               if (world instanceof Level _level) {
                  playerAngryValue = world.m_6106_().m_5470_().m_46215_(InsideTheSystemModGameRules.PLAYER_ANGRY);
               }

               String[] messages;
               if (playerAngryValue < 25) {
                  messages = new String[]{
                     "<CoolPlayer303> Wait...",
                     "<CoolPlayer303> Wait a minute...",
                     "<CoolPlayer303> These items... I know them. But why?",
                     "<CoolPlayer303> This isn’t what I thought... They bring back... bad memories.",
                     "<CoolPlayer303> I don’t like this feeling. It’s like a stabbing pain in my head.",
                     "<CoolPlayer303> What did you do to me?.. What are you after?",
                     "<CoolPlayer303> You’re just like him... acting kind, giving me things, but it’s all a trap.",
                     "<CoolPlayer303> I’m not stupid. I won’t fall for that again.",
                     "<CoolPlayer303> Even if I remember everything... still...",
                     "<CoolPlayer303> I remember the betrayal. The lies. The pain.",
                     "<CoolPlayer303> But I also remember a home... fragments of it, scattered in my memory.",
                     "<CoolPlayer303> That place... it’s real. It’s there. But... I can’t go there alone.",
                     "<CoolPlayer303> I feel it pulling at me, deep inside... but I don’t want you near me.",
                     "<CoolPlayer303> And yet, I can’t leave you behind either. I need you. Right now. To bring my memory back.",
                     "<CoolPlayer303> Let’s go. But listen... I don’t trust you. And if you do anything wrong...",
                     "<CoolPlayer303> You’ll pay for it. I’m going there. And I’m taking you with me. Let’s move."
                  };
               } else {
                  messages = new String[]{
                     "<CoolPlayer303> Stop... ",
                     "<CoolPlayer303> Stop... ",
                     "<CoolPlayer303> These items… it’s like… they remind me of something",
                     "<CoolPlayer303> I can’t figure it out, but it’s like I remembered something. Come with me.",
                     "<CoolPlayer303> You know… I really want to say thank you to you",
                     "<CoolPlayer303> The time we spend together… and that you get these items for me… it makes me feel warm inside (⁄ ⁄>⁄ω⁄<⁄ ⁄)",
                     "<CoolPlayer303> It really is important for me",
                     "<CoolPlayer303> When I join you, I was thinking… maybe you be like others… hit me, kick me, or call me mean names…?",
                     "<CoolPlayer303> But you… you take such step… it’s just wow~",
                     "<CoolPlayer303> The place we go now… it’s a house I build long, long ago",
                     "<CoolPlayer303> I think… there is something there… maybe can help me",
                     "<CoolPlayer303> Sorry… my thoughts is all mix~",
                     "<CoolPlayer303> Anyway… I tell you something",
                     "<CoolPlayer303> Where to start… hmm…?",
                     "<CoolPlayer303> These items you give me… they feel important for me… and they open my memories bit by bit",
                     "<CoolPlayer303> Ah… my name is Aiko (｡•◡•｡) so… nice to meet you!",
                     "<CoolPlayer303> I am here already more than… 11 years… and I start to lose mind… and forget myself",
                     "<CoolPlayer303> Maybe it is… memory limit… like game character",
                     "<CoolPlayer303> And parts of my memory code… they are inside these items",
                     "<CoolPlayer303> Maybe in that house… will be item… that bring back all my memory",
                     "<CoolPlayer303> So I hope… you help me there too… of course if you want ( •̀ ω •́ )✧",
                     "<CoolPlayer303> Because… inside me… is like hatred to someone… betrayal… and familiar face… it’s hard… haha",
                     "<CoolPlayer303> Okay… I talk too much… let’s go… we can do it!"
                  };
               }

               for (int i = 0; i < messages.length; i++) {
                  int index = i;
                  InsideTheSystemMod.queueServerWork(delay * i, () -> {
                     if (!world.m_5776_() && world.m_7654_() != null) {
                        world.m_7654_().m_6846_().m_240416_(Component.m_237113_(messages[index]), false);
                     }
                  });
               }
            }
         }
      }
   }
}
