package net.mcreator.insidethesystem.procedures;

import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

public class WarningPriZakrytiiIntierfieisaProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z) {
      if (world instanceof Level _level) {
         if (!_level.m_5776_()) {
            _level.m_5594_(
               null,
               BlockPos.m_274561_(x, y, z),
               (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:begining")),
               SoundSource.NEUTRAL,
               1.0F,
               1.0F
            );
         } else {
            _level.m_7785_(
               x,
               y,
               z,
               (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:begining")),
               SoundSource.NEUTRAL,
               1.0F,
               1.0F,
               false
            );
         }
      }

      if (world instanceof ServerLevel _levelx) {
         _levelx.m_7654_()
            .m_129892_()
            .m_230957_(
               new CommandSourceStack(
                     CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _levelx, 4, "", Component.m_237113_(""), _levelx.m_7654_(), null
                  )
                  .m_81324_(),
               "/title @a times 20 60 20"
            );
      }

      if (world instanceof ServerLevel _levelx) {
         _levelx.m_7654_()
            .m_129892_()
            .m_230957_(
               new CommandSourceStack(
                     CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _levelx, 4, "", Component.m_237113_(""), _levelx.m_7654_(), null
                  )
                  .m_81324_(),
               "/title @a subtitle {\"text\":\"A strange friend\",\"italic\":true,\"color\":\"#DADADA\"}"
            );
      }

      if (world instanceof ServerLevel _levelx) {
         _levelx.m_7654_()
            .m_129892_()
            .m_230957_(
               new CommandSourceStack(
                     CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _levelx, 4, "", Component.m_237113_(""), _levelx.m_7654_(), null
                  )
                  .m_81324_(),
               "/title @a title {\"text\":\"ACT I\"}"
            );
      }
   }
}
