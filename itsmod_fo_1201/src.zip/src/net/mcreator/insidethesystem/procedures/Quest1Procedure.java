package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.init.InsideTheSystemModItems;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.player.PlayerEvent.ItemCraftedEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class Quest1Procedure {
   @SubscribeEvent
   public static void onItemCrafted(ItemCraftedEvent event) {
      execute(event, event.getEntity().m_9236_(), event.getEntity().m_20185_(), event.getEntity().m_20186_(), event.getEntity().m_20189_(), event.getCrafting());
   }

   public static void execute(LevelAccessor world, double x, double y, double z, ItemStack itemstack) {
      execute(null, world, x, y, z, itemstack);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, ItemStack itemstack) {
      if (itemstack.m_41720_() == InsideTheSystemModItems.SHELLNECKLACE_CHESTPLATE.get()) {
         if (!world.m_5776_() && world.m_7654_() != null) {
            world.m_7654_()
               .m_6846_()
               .m_240416_(Component.m_237113_("<CoolPlayer303> What a beautiful necklace! Thank you, it's just like the one my mother made for me!"), false);
         }

         InsideTheSystemModVariables.MapVariables.get(world).quest2 = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemMod.queueServerWork(
            70,
            () -> {
               if (world instanceof ServerLevel _level) {
                  _level.m_7654_()
                     .m_129892_()
                     .m_230957_(
                        new CommandSourceStack(
                              CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                           )
                           .m_81324_(),
                        "/title @a actionbar [\"Give it to him\"]"
                     );
               }
            }
         );
      }
   }
}
