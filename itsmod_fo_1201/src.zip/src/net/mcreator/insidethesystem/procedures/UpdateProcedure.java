package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.arguments.EntityAnchorArgument.Anchor;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec3;

public class UpdateProcedure {
   public static void execute(LevelAccessor world, Entity entity) {
      if (entity != null) {
         entity.m_6021_(
            InsideTheSystemModVariables.MapVariables.get(world).PlayerX + 3.0,
            InsideTheSystemModVariables.MapVariables.get(world).PlayerY,
            InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
         );
         if (entity instanceof ServerPlayer _serverPlayer) {
            _serverPlayer.f_8906_
               .m_9774_(
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerX + 3.0,
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerY,
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerZ,
                  entity.m_146908_(),
                  entity.m_146909_()
               );
         }

         entity.m_7618_(
            Anchor.EYES,
            new Vec3(
               InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
               InsideTheSystemModVariables.MapVariables.get(world).PlayerY + 1.0,
               InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
            )
         );
         if (InsideTheSystemModVariables.MapVariables.get(world).followerdied <= 2000.0
            && InsideTheSystemModVariables.MapVariables.get(world).followerdied != 0.0) {
            InsideTheSystemModVariables.MapVariables.get(world).followerdied--;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemModVariables.MapVariables.get(world).eventfollover = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }

         if (InsideTheSystemModVariables.MapVariables.get(world).followerdied == 0.0) {
            if (!entity.m_9236_().m_5776_()) {
               entity.m_146870_();
            }

            InsideTheSystemModVariables.MapVariables.get(world).eventfollover = false;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }
      }
   }
}
