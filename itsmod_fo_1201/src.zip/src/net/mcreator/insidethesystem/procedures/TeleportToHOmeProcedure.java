package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerChangedDimensionEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.registries.ForgeRegistries;

@EventBusSubscriber
public class TeleportToHOmeProcedure {
   @SubscribeEvent
   public static void onPlayerChangedDimension(PlayerChangedDimensionEvent event) {
      execute(event, event.getEntity().m_9236_(), event.getEntity().m_20185_(), event.getEntity().m_20186_(), event.getEntity().m_20189_(), event.getEntity());
   }

   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      execute(null, world, x, y, z, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (entity.m_9236_().m_46472_() == ResourceKey.m_135785_(Registries.f_256858_, new ResourceLocation("inside_the_system:final_dimens"))) {
            InsideTheSystemMod.queueServerWork(
               3600,
               () -> {
                  if (world instanceof ServerLevel _level) {
                     _level.m_5594_(
                        null,
                        new BlockPos((int)x, (int)y, (int)z),
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:openmemory")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F
                     );
                     CommandSourceStack commandSource = new CommandSourceStack(
                           CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                        )
                        .m_81324_();
                     _level.m_7654_()
                        .m_129892_()
                        .m_230957_(commandSource, "/setblock 11 102 30 inside_the_system:memory_doors[facing=north,half=lower,hinge=left,open=false]");
                     _level.m_7654_()
                        .m_129892_()
                        .m_230957_(commandSource, "/setblock 11 103 30 inside_the_system:memory_doors[facing=north,half=upper,hinge=left,open=false]");
                  }
               }
            );
         }
      }
   }
}
