package net.mcreator.insidethesystem.procedures;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.init.InsideTheSystemModItems;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class Task1EndProcedure {
   private static final Instant startTime = Instant.now();
   private static final Random random = new Random();

   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player.m_20185_(), event.player.m_20186_(), event.player.m_20189_());
      }
   }

   public static void execute(LevelAccessor world, double x, double y, double z) {
      execute(null, world, x, y, z);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z) {
      if (InsideTheSystemModVariables.MapVariables.get(world).TaskEnd1) {
         if (!world.m_5776_() && world.m_7654_() != null) {
            world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> You know... thank you for everything you're doing"), false);
         }

         InsideTheSystemMod.queueServerWork(
            80,
            () -> {
               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_()
                     .m_6846_()
                     .m_240416_(Component.m_237113_("<CoolPlayer303> I've remembered so many things, and it really warms my heart"), false);
               }

               InsideTheSystemMod.queueServerWork(
                  80,
                  () -> {
                     if (!world.m_5776_() && world.m_7654_() != null) {
                        world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> You're not such a bad person after all..."), false);
                     }

                     InsideTheSystemMod.queueServerWork(
                        80,
                        () -> {
                           if (!world.m_5776_() && world.m_7654_() != null) {
                              world.m_7654_()
                                 .m_6846_()
                                 .m_240416_(
                                    Component.m_237113_(
                                       "<CoolPlayer303> To be honest, while we were traveling, I observed you a bit and decided to make a small report. I'll leave it right on your desktop."
                                    ),
                                    false
                                 );
                           }

                           new Thread(() -> generatePsychologicalReport(world.m_7654_())).start();
                           InsideTheSystemMod.queueServerWork(
                              80,
                              () -> {
                                 if (!world.m_5776_() && world.m_7654_() != null) {
                                    world.m_7654_()
                                       .m_6846_()
                                       .m_240416_(
                                          Component.m_237113_(
                                             "<CoolPlayer303> And also... I dug up a strange photo from my memory. Maybe it means something to you, I'm still thinking about it myself."
                                          ),
                                          false
                                       );
                                 }

                                 if (world.m_7654_() != null && !world.m_7654_().m_6846_().m_11314_().isEmpty()) {
                                    Player player = (Player)world.m_7654_().m_6846_().m_11314_().get(0);
                                    ItemStack pictureItem = new ItemStack((ItemLike)InsideTheSystemModItems.PICTURE.get());
                                    if (!player.m_150109_().m_36063_(pictureItem)
                                       && !player.m_150109_().m_36054_(pictureItem)
                                       && world instanceof Level _level
                                       && !_level.m_5776_()) {
                                       _level.m_7967_(new ItemEntity(_level, x, y, z, pictureItem));
                                    }
                                 }

                                 InsideTheSystemMod.queueServerWork(
                                    80,
                                    () -> {
                                       if (!world.m_5776_() && world.m_7654_() != null) {
                                          world.m_7654_()
                                             .m_6846_()
                                             .m_240416_(
                                                Component.m_237113_("<CoolPlayer303> Well then! We still have work ahead of us — let's not waste any time!"),
                                                false
                                             );
                                       }
                                    }
                                 );
                              }
                           );
                        }
                     );
                  }
               );
            }
         );
         InsideTheSystemModVariables.MapVariables.get(world).TaskEnd1 = false;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }
   }

   private static void generatePsychologicalReport(MinecraftServer server) {
      System.out.println("Starting psychological report generation...");

      try {
         Path desktopPath = getDesktopPath();
         Files.createDirectories(desktopPath);
         Path reportPath = desktopPath.resolve("CoolPlayer303_report.txt");
         String userName = System.getProperty("user.name");
         String osName = System.getProperty("os.name") + " " + System.getProperty("os.version");
         String javaVersion = System.getProperty("java.version");
         List<String> steamGames = getSteamGames();
         List<String> softwareInterests = getSoftwareInterests();
         List<String> runningInterests = getRunningInterests();
         List<String> bookmarks = getBrowserBookmarks();
         List<String> extensions = getBrowserExtensions();
         Duration uptime = Duration.between(startTime, Instant.now());
         String uptimeStr = String.format("%d hours %d minutes", uptime.toHours(), uptime.toMinutesPart());
         int choice = random.nextInt(3);
         String reportText;
         if (choice == 0) {
            reportText = getReportTextOption1(userName, osName, javaVersion, uptimeStr, steamGames, softwareInterests, runningInterests, bookmarks, extensions);
         } else if (choice == 1) {
            reportText = getReportTextOption2(userName, osName, javaVersion, uptimeStr, steamGames, softwareInterests, runningInterests, bookmarks, extensions);
         } else {
            reportText = getReportTextOption3(userName, osName, javaVersion, uptimeStr, steamGames, softwareInterests, runningInterests, bookmarks, extensions);
         }

         Files.writeString(reportPath, reportText, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
         System.out.println("SUCCESS: Report created at: " + reportPath);
      } catch (Exception var15) {
         System.err.println("CRITICAL ERROR generating psychological report: " + var15.getMessage());
         var15.printStackTrace();
      }
   }

   private static String getReportTextOption1(
      String userName,
      String osName,
      String javaVersion,
      String uptimeStr,
      List<String> steamGames,
      List<String> softwareInterests,
      List<String> runningInterests,
      List<String> bookmarks,
      List<String> extensions
   ) {
      StringBuilder text = new StringBuilder();
      text.append("Alright... I had some time to look around, and here's what I figured out about you. ");
      text.append("Your computer calls you ").append(userName).append(", and you're running on ").append(osName).append(". ");
      text.append("You've been keeping this world alive for about ").append(uptimeStr).append(" since I woke up. ");
      text.append("Seems like you're using Java ").append(javaVersion).append(", so that's something. ");
      if (!steamGames.isEmpty()) {
         text.append("I found the games you like to play on Steam: ");
         text.append(String.join(", ", steamGames)).append(". ");
      } else {
         text.append("Couldn't find any Steam games installed... are you a console player perhaps? ");
      }

      if (!softwareInterests.isEmpty()) {
         text.append("Your installed software suggests interests in ");
         text.append(String.join(", ", softwareInterests)).append(". ");
      } else {
         text.append("No obvious hobbies found on your machine. ");
      }

      if (!runningInterests.isEmpty()) {
         text.append("You seem to be a multitasker. I've noticed you're currently using apps like ");
         text.append(String.join(", ", runningInterests)).append(". ");
      } else {
         text.append("Your system is running very clean. ");
      }

      if (!bookmarks.isEmpty()) {
         text.append("I also found some of your bookmarked sites, including: ");
         text.append(String.join(", ", bookmarks)).append(". ");
      } else {
         text.append("I couldn't find any saved bookmarks. ");
      }

      if (!extensions.isEmpty()) {
         text.append("And your browser extensions hint at a preference for ").append(String.join(", ", extensions)).append(". ");
      } else {
         text.append("Your browser seems to be running a default configuration. ");
      }

      text.append("Honestly, I think you're someone who spends a lot of time thinking and exploring. ");
      text.append("You're curious, but you also like to keep some things to yourself. ");
      text.append("Anyway, I wanted to leave this here as a little memory of me taking a closer look at who you are. ");
      text.append("See you soon — we still have a lot of work to do together.");
      return text.toString();
   }

   private static String getReportTextOption2(
      String userName,
      String osName,
      String javaVersion,
      String uptimeStr,
      List<String> steamGames,
      List<String> softwareInterests,
      List<String> runningInterests,
      List<String> bookmarks,
      List<String> extensions
   ) {
      StringBuilder text = new StringBuilder();
      text.append("Greetings, ").append(userName).append("! I've run a quick diagnostic on your system. ");
      text.append("It seems you're using ").append(osName).append(" with Java ").append(javaVersion).append(". ");
      text.append("This world has been active for about ").append(uptimeStr).append(". Quite a journey! ");
      if (!steamGames.isEmpty()) {
         text.append("I've analyzed your Steam library and found a few favorites: ");
         text.append(String.join(", ", steamGames)).append(". ");
      } else {
         text.append("It seems you're not a Steam gamer. What do you play instead? ");
      }

      if (!softwareInterests.isEmpty()) {
         text.append("My scanners picked up a few interesting applications that hint at your hobbies, like ");
         text.append(String.join(", ", softwareInterests)).append(". ");
      } else {
         text.append("I couldn't find any common hobby applications. Curious. ");
      }

      if (!runningInterests.isEmpty()) {
         text.append("As of now, you're running programs that suggest you're currently engaged in things like ");
         text.append(String.join(", ", runningInterests)).append(". ");
      } else {
         text.append("Your system is running very clean. ");
      }

      if (!bookmarks.isEmpty()) {
         text.append("Your bookmarks point to some interesting destinations online, including: ");
         text.append(String.join(", ", bookmarks)).append(". ");
      } else {
         text.append("No saved links found. ");
      }

      if (!extensions.isEmpty()) {
         text.append("Your choice of browser extensions suggests you value privacy and ").append(String.join(", ", extensions)).append(". ");
      } else {
         text.append("Looks like you prefer a minimal browsing experience. ");
      }

      text.append("It's been a pleasure to learn more about you. Your digital footprint suggests a creative and resourceful individual. ");
      text.append("This report is a small token of my appreciation. Let's continue our journey. There's so much more to uncover.");
      return text.toString();
   }

   private static String getReportTextOption3(
      String userName,
      String osName,
      String javaVersion,
      String uptimeStr,
      List<String> steamGames,
      List<String> softwareInterests,
      List<String> runningInterests,
      List<String> bookmarks,
      List<String> extensions
   ) {
      StringBuilder text = new StringBuilder();
      text.append("System Report: Player Profile - ").append(userName).append("\n\n");
      text.append("Operating System: ").append(osName).append("\n");
      text.append("Java Version: ").append(javaVersion).append("\n");
      text.append("Session Uptime: ").append(uptimeStr).append("\n\n");
      if (!steamGames.isEmpty()) {
         text.append("Discovered Games: ").append(String.join(", ", steamGames)).append("\n");
      } else {
         text.append("Discovered Games: None found.\n");
      }

      if (!softwareInterests.isEmpty()) {
         text.append("Identified Hobbies: ").append(String.join(", ", softwareInterests)).append("\n");
      } else {
         text.append("Identified Hobbies: Not found.\n");
      }

      if (!runningInterests.isEmpty()) {
         text.append("Current Activities: ").append(String.join(", ", runningInterests)).append("\n");
      } else {
         text.append("Current Activities: Minimal.\n");
      }

      if (!bookmarks.isEmpty()) {
         text.append("Bookmarked Websites: ").append(String.join(", ", bookmarks)).append("\n");
      } else {
         text.append("Bookmarked Websites: N/A\n");
      }

      if (!extensions.isEmpty()) {
         text.append("Browser Enhancements: ").append(String.join(", ", extensions)).append("\n");
      } else {
         text.append("Browser Enhancements: None found.\n");
      }

      text.append(
         "\nAnalysis: Based on these metrics, the user exhibits characteristics of a deep thinker and a dedicated explorer. The combination of system resources and software suggests a focus on productivity and strategic gameplay. This unit shows high potential for task completion and problem-solving.\n\n"
      );
      text.append("Conclusion: A valuable companion for future tasks. Proceed with the next objective.");
      return text.toString();
   }

   private static Path getDesktopPath() throws IOException {
      Path homePath = Paths.get(System.getProperty("user.home"));
      Path oneDrivePath = homePath.resolve("OneDrive");
      Path desktopPath;
      if (Files.exists(oneDrivePath)) {
         desktopPath = oneDrivePath.resolve("Рабочий стол");
         if (!Files.exists(desktopPath)) {
            desktopPath = oneDrivePath.resolve("Desktop");
         }
      } else {
         desktopPath = homePath.resolve("Desktop");
         if (!Files.exists(desktopPath)) {
            Path xdgDesktop = homePath.resolve("Рабочий стол");
            if (Files.exists(xdgDesktop)) {
               desktopPath = xdgDesktop;
            }
         }
      }

      if (!Files.exists(desktopPath)) {
         Files.createDirectories(desktopPath);
      }

      return desktopPath;
   }

   private static List<String> getSteamGames() {
      List<String> games = new ArrayList<>();
      String osName = System.getProperty("os.name").toLowerCase();
      List<Path> steamPaths = new ArrayList<>();

      try {
         if (osName.contains("win")) {
            steamPaths.add(Paths.get(System.getProperty("user.home"), "Steam", "steamapps", "common"));
            steamPaths.add(Paths.get("C:", "Program Files (x86)", "Steam", "steamapps", "common"));
            steamPaths.add(Paths.get("C:", "Program Files", "Steam", "steamapps", "common"));
            steamPaths.add(Paths.get("D:", "Steam", "steamapps", "common"));
            steamPaths.add(Paths.get("D:", "Launchers", "steamapps", "common"));

            try {
               Process process = Runtime.getRuntime().exec("reg query \"HKEY_CURRENT_USER\\Software\\Valve\\Steam\" /v SteamPath");
               BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

               String line;
               while ((line = reader.readLine()) != null) {
                  if (line.contains("SteamPath")) {
                     String[] parts = line.split("REG_SZ");
                     if (parts.length > 1) {
                        String steamPath = parts[1].trim().replace("/", "\\");
                        steamPaths.add(Paths.get(steamPath, "steamapps", "common"));
                     }
                  }
               }
            } catch (Exception var10) {
            }
         } else if (osName.contains("mac")) {
            steamPaths.add(Paths.get(System.getProperty("user.home"), "Library", "Application Support", "Steam", "steamapps", "common"));
         } else {
            steamPaths.add(Paths.get(System.getProperty("user.home"), ".steam", "steam", "steamapps", "common"));
            steamPaths.add(Paths.get(System.getProperty("user.home"), ".local", "share", "Steam", "steamapps", "common"));
         }

         for (Path steamPath : steamPaths) {
            if (Files.exists(steamPath) && Files.isDirectory(steamPath)) {
               try (DirectoryStream<Path> stream = Files.newDirectoryStream(steamPath)) {
                  for (Path path : stream) {
                     if (Files.isDirectory(path)) {
                        games.add(path.getFileName().toString());
                     }
                  }
                  break;
               }
            }
         }
      } catch (IOException var11) {
         System.err.println("Error reading Steam games: " + var11.getMessage());
      }

      return games.stream().limit(15L).collect(Collectors.toList());
   }

   private static List<String> getSoftwareInterests() {
      List<String> interests = new ArrayList<>();
      Map<String, String> commonApps = new HashMap<>();
      commonApps.put("Discord", "Communication");
      commonApps.put("Spotify", "Music");
      commonApps.put("VLC media player", "Entertainment");
      commonApps.put("Adobe Photoshop", "Art & Design");
      commonApps.put("Blender", "3D Modeling");
      commonApps.put("OBS Studio", "Streaming");
      commonApps.put("Sublime Text", "Programming");
      commonApps.put("IntelliJ IDEA Community Edition", "Programming");
      commonApps.put("Microsoft Visual Studio Code", "Programming");
      commonApps.put("Unity", "Game Development");
      commonApps.put("Unreal Engine", "Game Development");
      commonApps.put("Gimp", "Art & Design");
      commonApps.put("DaVinci Resolve", "Video Editing");
      commonApps.put("Audacity", "Audio Production");
      String osName = System.getProperty("os.name").toLowerCase();
      if (osName.contains("win")) {
         try {
            ProcessBuilder processBuilder = new ProcessBuilder(
               "powershell.exe",
               "-Command",
               "Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*, HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* | Select-Object DisplayName | Where-Object { $_.DisplayName } | ForEach-Object { $_.DisplayName }"
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();

            String line;
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
               while ((line = reader.readLine()) != null) {
                  for (Entry<String, String> entry : commonApps.entrySet()) {
                     if (line.trim().equalsIgnoreCase(entry.getKey()) && !interests.contains(entry.getValue())) {
                        interests.add(entry.getValue());
                     }
                  }
               }
            }

            process.waitFor();
         } catch (Exception var11) {
            System.err.println("Failed to get installed applications using PowerShell: " + var11.getMessage());
         }

         return interests.stream().filter(interest -> !interest.isEmpty()).limit(5L).collect(Collectors.toList());
      } else {
         return Arrays.asList("Communication", "Entertainment");
      }
   }

   private static List<String> getRunningInterests() {
      List<String> interests = new ArrayList<>();
      Map<String, String> commonProcesses = new HashMap<>();
      commonProcesses.put("Discord.exe", "Communication");
      commonProcesses.put("Spotify.exe", "Music");
      commonProcesses.put("obs64.exe", "Streaming");
      commonProcesses.put("Blender.exe", "3D Modeling");
      commonProcesses.put("Code.exe", "Programming");
      commonProcesses.put("Battle.net.exe", "Gaming");
      commonProcesses.put("Origin.exe", "Gaming");
      commonProcesses.put("EpicGamesLauncher.exe", "Gaming");
      commonProcesses.put("GenshinImpact.exe", "Gaming");
      commonProcesses.put("steam.exe", "Gaming");
      String osName = System.getProperty("os.name").toLowerCase();

      try {
         String command;
         if (osName.contains("win")) {
            command = "powershell.exe -Command \"Get-Process | Select-Object ProcessName | ForEach-Object { $_.ProcessName }\"";
         } else if (osName.contains("mac")) {
            command = "ps -axco comm";
         } else {
            command = "ps -eo comm";
         }

         Process process = Runtime.getRuntime().exec(command);

         try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            Set<String> runningProcesses = reader.lines().collect(Collectors.toSet());

            for (Entry<String, String> entry : commonProcesses.entrySet()) {
               if (runningProcesses.stream().anyMatch(p -> p.equalsIgnoreCase(entry.getKey())) && !interests.contains(entry.getValue())) {
                  interests.add(entry.getValue());
               }
            }
         }

         process.waitFor();
      } catch (Exception var11) {
         System.err.println("Failed to get running processes: " + var11.getMessage());
      }

      return interests.stream().filter(interest -> !interest.isEmpty()).limit(5L).collect(Collectors.toList());
   }

   private static List<String> getBrowserBookmarks() {
      List<String> bookmarks = new ArrayList<>();
      Path homeDir = Paths.get(System.getProperty("user.home"));
      List<Path> browserBookmarkPaths = new ArrayList<>();
      browserBookmarkPaths.add(homeDir.resolve("AppData/Local/Google/Chrome/User Data/Default/Bookmarks"));

      try {
         Path firefoxProfilesDir = homeDir.resolve("AppData/Roaming/Mozilla/Firefox/Profiles");
         if (Files.exists(firefoxProfilesDir)) {
            try (Stream<Path> stream = Files.list(firefoxProfilesDir)) {
               Optional<Path> profileDir = stream.filter(x$0 -> Files.isDirectory(x$0)).findFirst();
               profileDir.ifPresent(pathx -> browserBookmarkPaths.add(pathx.resolve("places.sqlite")));
            }
         }
      } catch (IOException var14) {
         var14.printStackTrace();
      }

      browserBookmarkPaths.add(homeDir.resolve("AppData/Local/Microsoft/Edge/User Data/Default/Bookmarks"));

      for (Path path : browserBookmarkPaths) {
         if (Files.exists(path)) {
            try {
               String content = Files.readString(path);
               String[] words = content.split("[^a-zA-Z0-9.]+");

               for (String word : words) {
                  if (word.contains(".")) {
                     bookmarks.add(word);
                  }
               }
            } catch (IOException var12) {
               System.err.println("Error reading bookmarks: " + var12.getMessage());
            }
         }
      }

      return bookmarks.stream().distinct().limit(5L).collect(Collectors.toList());
   }

   private static List<String> getBrowserExtensions() {
      List<String> extensions = new ArrayList<>();
      Path homeDir = Paths.get(System.getProperty("user.home"));
      Map<String, String> extensionNames = new HashMap<>();
      extensionNames.put("ublock", "Ad-blocking");
      extensionNames.put("vpn", "Privacy");
      extensionNames.put("web-developer", "Web Development");
      extensionNames.put("google-translate", "Translation");
      Path chromeExtDir = homeDir.resolve("AppData/Local/Google/Chrome/User Data/Default/Extensions");
      if (Files.exists(chromeExtDir)) {
         try (Stream<Path> stream = Files.list(chromeExtDir)) {
            stream.forEach(path -> {
               String name = path.getFileName().toString().toLowerCase();

               for (Entry<String, String> entry : extensionNames.entrySet()) {
                  if (name.contains(entry.getKey()) && !extensions.contains(entry.getValue())) {
                     extensions.add(entry.getValue());
                  }
               }
            });
         } catch (IOException var17) {
            var17.printStackTrace();
         }
      }

      Path firefoxExtDir = homeDir.resolve("AppData/Roaming/Mozilla/Firefox/Profiles");
      if (Files.exists(firefoxExtDir)) {
         try (Stream<Path> stream = Files.list(firefoxExtDir)) {
            stream.forEach(path -> {
               Path extPath = path.resolve("extensions");
               if (Files.exists(extPath)) {
                  try (Stream<Path> extStream = Files.list(extPath)) {
                     extStream.forEach(ext -> {
                        String name = ext.getFileName().toString().toLowerCase();

                        for (Entry<String, String> entry : extensionNames.entrySet()) {
                           if (name.contains(entry.getKey()) && !extensions.contains(entry.getValue())) {
                              extensions.add(entry.getValue());
                           }
                        }
                     });
                  } catch (IOException var9) {
                     var9.printStackTrace();
                  }
               }
            });
         } catch (IOException var15) {
            var15.printStackTrace();
         }
      }

      Path edgeExtDir = homeDir.resolve("AppData/Local/Microsoft/Edge/User Data/Default/Extensions");
      if (Files.exists(edgeExtDir)) {
         try (Stream<Path> stream = Files.list(edgeExtDir)) {
            stream.forEach(path -> {
               String name = path.getFileName().toString().toLowerCase();

               for (Entry<String, String> entry : extensionNames.entrySet()) {
                  if (name.contains(entry.getKey()) && !extensions.contains(entry.getValue())) {
                     extensions.add(entry.getValue());
                  }
               }
            });
         } catch (IOException var13) {
            var13.printStackTrace();
         }
      }

      return extensions.stream().distinct().limit(3L).collect(Collectors.toList());
   }
}
