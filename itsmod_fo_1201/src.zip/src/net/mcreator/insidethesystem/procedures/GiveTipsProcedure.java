package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.init.InsideTheSystemModItems;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.registries.ForgeRegistries;

@EventBusSubscriber
public class GiveTipsProcedure {
   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player.m_20185_(), event.player.m_20186_(), event.player.m_20189_(), event.player);
      }
   }

   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      execute(null, world, x, y, z, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (InsideTheSystemModVariables.MapVariables.get(world).Tips) {
            InsideTheSystemModVariables.MapVariables.get(world).Tips = false;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemMod.queueServerWork(700, () -> {
               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> Hey! I found a strange piece of paper in my inventory"), false);
               }

               InsideTheSystemMod.queueServerWork(70, () -> {
                  if (!world.m_5776_() && world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> Here, can you draw me in it? :3"), false);
                  }

                  if (entity instanceof Player _player) {
                     ItemStack _setstack = new ItemStack((ItemLike)InsideTheSystemModItems.TIPS.get());
                     _setstack.m_41764_(1);
                     ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
                  }
               });
            });
         } else if (InsideTheSystemModVariables.MapVariables.get(world).Task1T) {
            InsideTheSystemMod.queueServerWork(
               700,
               () -> {
                  if (world instanceof ServerLevel _level) {
                     _level.m_7654_()
                        .m_129892_()
                        .m_230957_(
                           new CommandSourceStack(
                                 CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                              )
                              .m_81324_(),
                           "/title @p actionbar {\"text\":\"I’ve written down the hints\"}"
                        );
                  }

                  if (world instanceof Level _level && !_level.m_5776_()) {
                     _level.m_5594_(
                        null,
                        new BlockPos((int)x, (int)y, (int)z),
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:write")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F
                     );
                  }

                  InsideTheSystemModVariables.MapVariables.get(world).Tips1 = true;
                  InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
               }
            );
            InsideTheSystemModVariables.MapVariables.get(world).Task1T = false;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         } else if (InsideTheSystemModVariables.MapVariables.get(world).Task2T) {
            InsideTheSystemMod.queueServerWork(
               1900,
               () -> {
                  if (world instanceof ServerLevel _level) {
                     _level.m_7654_()
                        .m_129892_()
                        .m_230957_(
                           new CommandSourceStack(
                                 CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                              )
                              .m_81324_(),
                           "/title @p actionbar {\"text\":\"I’ve written down the hints\"}"
                        );
                  }

                  if (world instanceof Level _level && !_level.m_5776_()) {
                     _level.m_5594_(
                        null,
                        new BlockPos((int)x, (int)y, (int)z),
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:write")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F
                     );
                  }

                  InsideTheSystemModVariables.MapVariables.get(world).Tips1 = false;
                  InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
                  InsideTheSystemModVariables.MapVariables.get(world).Tips2 = true;
                  InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
               }
            );
            InsideTheSystemModVariables.MapVariables.get(world).Task2T = false;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         } else if (InsideTheSystemModVariables.MapVariables.get(world).Task3T) {
            InsideTheSystemMod.queueServerWork(
               1900,
               () -> {
                  if (world instanceof ServerLevel _level) {
                     _level.m_7654_()
                        .m_129892_()
                        .m_230957_(
                           new CommandSourceStack(
                                 CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                              )
                              .m_81324_(),
                           "/title @p actionbar {\"text\":\"I’ve written down the hints\"}"
                        );
                  }

                  if (world instanceof Level _level && !_level.m_5776_()) {
                     _level.m_5594_(
                        null,
                        new BlockPos((int)x, (int)y, (int)z),
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:write")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F
                     );
                  }

                  InsideTheSystemModVariables.MapVariables.get(world).Tips2 = false;
                  InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
                  InsideTheSystemModVariables.MapVariables.get(world).Tips3 = true;
                  InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
               }
            );
            InsideTheSystemModVariables.MapVariables.get(world).Task3T = false;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }
      }
   }
}
