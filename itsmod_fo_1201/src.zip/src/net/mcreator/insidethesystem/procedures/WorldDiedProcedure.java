package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.TickEvent.LevelTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class WorldDiedProcedure {
   @SubscribeEvent
   public static void onWorldTick(LevelTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.level);
      }
   }

   public static String execute(LevelAccessor world) {
      return execute(null, world);
   }

   private static String execute(@Nullable Event event, LevelAccessor world) {
      if (InsideTheSystemModVariables.MapVariables.get(world).WorldDied <= 192000.0
         && InsideTheSystemModVariables.MapVariables.get(world).Angry
         && InsideTheSystemModVariables.MapVariables.get(world).WorldDied != 0.0) {
         InsideTheSystemModVariables.MapVariables.get(world).WorldDied--;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldDied == 153000.0) {
         InsideTheSystemModVariables.MapVariables.get(world).First = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldDied == 133000.0) {
         InsideTheSystemModVariables.MapVariables.get(world).Second = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldDied == 106000.0) {
         InsideTheSystemModVariables.MapVariables.get(world).Third = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldDied == 80000.0) {
         InsideTheSystemModVariables.MapVariables.get(world).Fourth = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldDied == 50000.0) {
         InsideTheSystemModVariables.MapVariables.get(world).Fiveth = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldDied == 25000.0) {
         InsideTheSystemModVariables.MapVariables.get(world).Sixth = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).WorldDied == 0.0) {
         InsideTheSystemModVariables.MapVariables.get(world).Died = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      return InsideTheSystemModVariables.MapVariables.get(world).WorldDied + "";
   }
}
