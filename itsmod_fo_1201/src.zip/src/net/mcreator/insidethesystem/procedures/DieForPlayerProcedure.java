package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.entity.CoolPlayer303Entity;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class DieForPlayerProcedure {
   @SubscribeEvent
   public static void onEntityDeath(LivingDeathEvent event) {
      if (event != null && event.getEntity() != null) {
         execute(event, event.getEntity().m_9236_(), event.getEntity(), event.getSource().m_7639_());
      }
   }

   public static void execute(LevelAccessor world, Entity entity, Entity sourceentity) {
      execute(null, world, entity, sourceentity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, Entity entity, Entity sourceentity) {
      if (entity != null && sourceentity != null) {
         if (entity instanceof CoolPlayer303Entity && sourceentity instanceof Player) {
            if (Mth.m_216271_(RandomSource.m_216327_(), 1, 5) == 1) {
               InsideTheSystemMod.queueServerWork(40, () -> {
                  if (!world.m_5776_() && world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> Hey, bro, why are you doing this?"), false);
                  }
               });
            } else if (Mth.m_216271_(RandomSource.m_216327_(), 1, 4) == 1) {
               InsideTheSystemMod.queueServerWork(40, () -> {
                  if (!world.m_5776_() && world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> I don't like you killing me"), false);
                  }
               });
            } else if (Mth.m_216271_(RandomSource.m_216327_(), 1, 3) == 1) {
               InsideTheSystemMod.queueServerWork(40, () -> {
                  if (!world.m_5776_() && world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> Stop it! I'm your friend"), false);
                  }
               });
            } else if (Mth.m_216271_(RandomSource.m_216327_(), 1, 2) == 1) {
               InsideTheSystemMod.queueServerWork(40, () -> {
                  if (!world.m_5776_() && world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> I'm annoyed that you're killing me"), false);
                  }
               });
            } else if (Mth.m_216271_(RandomSource.m_216327_(), 1, 1) == 1) {
               InsideTheSystemMod.queueServerWork(40, () -> {
                  if (!world.m_5776_() && world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> You want me to get mad?"), false);
                  }
               });
            }
         }
      }
   }
}
