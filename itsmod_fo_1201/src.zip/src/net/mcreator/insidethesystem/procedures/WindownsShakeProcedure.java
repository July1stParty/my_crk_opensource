package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWVidMode;

@EventBusSubscriber(Dist.CLIENT)
public class WindownsShakeProcedure {
   private static boolean shaking = false;
   private static int shakeTicks = 0;
   private static int originalX = -1;
   private static int originalY = -1;

   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (FMLEnvironment.dist.isClient()) {
         if (event.phase == Phase.END && event.player.m_9236_().f_46443_) {
            execute(event.player.m_9236_());
         }
      }
   }

   private static void execute(Level world) {
      Minecraft mc = Minecraft.m_91087_();
      if (mc != null && mc.m_91268_() != null) {
         long window = mc.m_91268_().m_85439_();
         if (window != 0L) {
            InsideTheSystemModVariables.MapVariables mapVars = InsideTheSystemModVariables.MapVariables.get(world);
            if (mapVars != null) {
               if (mapVars.eventfollover) {
                  if (isFullscreen(mc)) {
                     toggleFullscreen(window);
                  }

                  if (!shaking) {
                     int[] pos = getWindowPosition(window);
                     originalX = pos[0];
                     originalY = pos[1];
                  }

                  shaking = true;
                  shakeTicks = 40;
               }

               if (shaking && shakeTicks > 0) {
                  shakeWindow(window);
                  shakeTicks--;
                  if (shakeTicks <= 0) {
                     shaking = false;
                     restoreWindowPosition(window);
                  }
               }
            }
         }
      }
   }

   private static void shakeWindow(long window) {
      int baseX = originalX != -1 ? originalX : 100;
      int baseY = originalY != -1 ? originalY : 100;
      int xOffset = (int)(Math.random() * 30.0 - 15.0);
      int yOffset = (int)(Math.random() * 30.0 - 15.0);
      GLFW.glfwSetWindowPos(window, baseX + xOffset, baseY + yOffset);
   }

   private static void restoreWindowPosition(long window) {
      if (originalX != -1 && originalY != -1) {
         GLFW.glfwSetWindowPos(window, originalX, originalY);
         originalX = -1;
         originalY = -1;
      }
   }

   private static int[] getWindowPosition(long window) {
      int[] xPos = new int[1];
      int[] yPos = new int[1];
      GLFW.glfwGetWindowPos(window, xPos, yPos);
      return new int[]{xPos[0], yPos[0]};
   }

   private static boolean isFullscreen(Minecraft mc) {
      long window = mc.m_91268_().m_85439_();
      return window == 0L ? false : GLFW.glfwGetWindowMonitor(window) != 0L;
   }

   private static void toggleFullscreen(long window) {
      if (window != 0L) {
         GLFWVidMode vidMode = GLFW.glfwGetVideoMode(GLFW.glfwGetPrimaryMonitor());
         if (vidMode != null) {
            if (GLFW.glfwGetWindowMonitor(window) == 0L) {
               GLFW.glfwSetWindowMonitor(window, GLFW.glfwGetPrimaryMonitor(), 0, 0, vidMode.width(), vidMode.height(), -1);
            } else {
               int screenWidth = vidMode.width();
               int screenHeight = vidMode.height();
               int newWidth = (int)(screenWidth * 0.8);
               int newHeight = (int)(screenHeight * 0.8);
               int centerX = (screenWidth - newWidth) / 2;
               int centerY = (screenHeight - newHeight) / 2;
               GLFW.glfwSetWindowMonitor(window, 0L, centerX, centerY, newWidth, newHeight, -1);
            }
         }
      }
   }
}
