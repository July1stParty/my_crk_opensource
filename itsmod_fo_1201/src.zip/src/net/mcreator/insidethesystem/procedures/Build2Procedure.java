package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.registries.ForgeRegistries;

@EventBusSubscriber
public class Build2Procedure {
   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player.m_20185_(), event.player.m_20186_(), event.player.m_20189_());
      }
   }

   public static void execute(LevelAccessor world, double x, double y, double z) {
      execute(null, world, x, y, z);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z) {
      if (InsideTheSystemModVariables.MapVariables.get(world).story1) {
         InsideTheSystemModVariables.MapVariables.get(world).story1 = false;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemMod.queueServerWork(
            20,
            () -> {
               if (world instanceof Level _level) {
                  if (!_level.m_5776_()) {
                     _level.m_5594_(
                        null,
                        BlockPos.m_274561_(x, y, z),
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F
                     );
                  } else {
                     _level.m_7785_(
                        x,
                        y,
                        z,
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F,
                        false
                     );
                  }
               }

               if (world instanceof ServerLevel _levelx) {
                  _levelx.m_7654_()
                     .m_129892_()
                     .m_230957_(
                        new CommandSourceStack(
                              CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _levelx, 4, "", Component.m_237113_(""), _levelx.m_7654_(), null
                           )
                           .m_81324_(),
                        "/setblock 7 10 22 inside_the_system:base"
                     );
               }

               if (world instanceof ServerLevel _levelx) {
                  _levelx.m_8767_(ParticleTypes.f_123746_, x, y, z, 5, 7.0, 10.0, 22.0, 1.0);
               }

               InsideTheSystemMod.queueServerWork(
                  20,
                  () -> {
                     if (world instanceof Level _levelxxx) {
                        if (!_levelxxx.m_5776_()) {
                           _levelxxx.m_5594_(
                              null,
                              BlockPos.m_274561_(x, y, z),
                              (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                              SoundSource.NEUTRAL,
                              1.0F,
                              1.0F
                           );
                        } else {
                           _levelxxx.m_7785_(
                              x,
                              y,
                              z,
                              (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                              SoundSource.NEUTRAL,
                              1.0F,
                              1.0F,
                              false
                           );
                        }
                     }

                     if (world instanceof ServerLevel _levelx) {
                        _levelx.m_7654_()
                           .m_129892_()
                           .m_230957_(
                              new CommandSourceStack(
                                    CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _levelx, 4, "", Component.m_237113_(""), _levelx.m_7654_(), null
                                 )
                                 .m_81324_(),
                              "/setblock 7 10 23 inside_the_system:base"
                           );
                     }

                     if (world instanceof ServerLevel _levelx) {
                        _levelx.m_8767_(ParticleTypes.f_123746_, x, y, z, 5, 7.0, 10.0, 23.0, 1.0);
                     }

                     InsideTheSystemMod.queueServerWork(
                        20,
                        () -> {
                           if (world instanceof Level _levelxxxxxx) {
                              if (!_levelxxxxxx.m_5776_()) {
                                 _levelxxxxxx.m_5594_(
                                    null,
                                    BlockPos.m_274561_(x, y, z),
                                    (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                    SoundSource.NEUTRAL,
                                    1.0F,
                                    1.0F
                                 );
                              } else {
                                 _levelxxxxxx.m_7785_(
                                    x,
                                    y,
                                    z,
                                    (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                    SoundSource.NEUTRAL,
                                    1.0F,
                                    1.0F,
                                    false
                                 );
                              }
                           }

                           if (world instanceof ServerLevel _levelx) {
                              _levelx.m_7654_()
                                 .m_129892_()
                                 .m_230957_(
                                    new CommandSourceStack(
                                          CommandSource.f_80164_,
                                          new Vec3(x, y, z),
                                          Vec2.f_82462_,
                                          _levelx,
                                          4,
                                          "",
                                          Component.m_237113_(""),
                                          _levelx.m_7654_(),
                                          null
                                       )
                                       .m_81324_(),
                                    "/setblock 7 10 24 inside_the_system:base"
                                 );
                           }

                           if (world instanceof ServerLevel _levelx) {
                              _levelx.m_8767_(ParticleTypes.f_123746_, x, y, z, 5, 7.0, 10.0, 24.0, 1.0);
                           }

                           InsideTheSystemMod.queueServerWork(
                              20,
                              () -> {
                                 if (world instanceof Level _levelxxxxxxxxx) {
                                    if (!_levelxxxxxxxxx.m_5776_()) {
                                       _levelxxxxxxxxx.m_5594_(
                                          null,
                                          BlockPos.m_274561_(x, y, z),
                                          (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                          SoundSource.NEUTRAL,
                                          1.0F,
                                          1.0F
                                       );
                                    } else {
                                       _levelxxxxxxxxx.m_7785_(
                                          x,
                                          y,
                                          z,
                                          (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                          SoundSource.NEUTRAL,
                                          1.0F,
                                          1.0F,
                                          false
                                       );
                                    }
                                 }

                                 if (world instanceof ServerLevel _levelx) {
                                    _levelx.m_7654_()
                                       .m_129892_()
                                       .m_230957_(
                                          new CommandSourceStack(
                                                CommandSource.f_80164_,
                                                new Vec3(x, y, z),
                                                Vec2.f_82462_,
                                                _levelx,
                                                4,
                                                "",
                                                Component.m_237113_(""),
                                                _levelx.m_7654_(),
                                                null
                                             )
                                             .m_81324_(),
                                          "/setblock 7 10 25 inside_the_system:base"
                                       );
                                 }

                                 if (world instanceof ServerLevel _levelx) {
                                    _levelx.m_8767_(ParticleTypes.f_123746_, x, y, z, 5, 7.0, 10.0, 25.0, 1.0);
                                 }

                                 InsideTheSystemMod.queueServerWork(
                                    20,
                                    () -> {
                                       if (world instanceof Level _levelxxxxxxxxxxxx) {
                                          if (!_levelxxxxxxxxxxxx.m_5776_()) {
                                             _levelxxxxxxxxxxxx.m_5594_(
                                                null,
                                                BlockPos.m_274561_(x, y, z),
                                                (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                                SoundSource.NEUTRAL,
                                                1.0F,
                                                1.0F
                                             );
                                          } else {
                                             _levelxxxxxxxxxxxx.m_7785_(
                                                x,
                                                y,
                                                z,
                                                (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                                SoundSource.NEUTRAL,
                                                1.0F,
                                                1.0F,
                                                false
                                             );
                                          }
                                       }

                                       if (world instanceof ServerLevel _levelx) {
                                          _levelx.m_7654_()
                                             .m_129892_()
                                             .m_230957_(
                                                new CommandSourceStack(
                                                      CommandSource.f_80164_,
                                                      new Vec3(x, y, z),
                                                      Vec2.f_82462_,
                                                      _levelx,
                                                      4,
                                                      "",
                                                      Component.m_237113_(""),
                                                      _levelx.m_7654_(),
                                                      null
                                                   )
                                                   .m_81324_(),
                                                "/setblock 7 10 26 inside_the_system:base"
                                             );
                                       }

                                       if (world instanceof ServerLevel _levelx) {
                                          _levelx.m_8767_(ParticleTypes.f_123746_, x, y, z, 5, 7.0, 10.0, 26.0, 1.0);
                                       }

                                       InsideTheSystemMod.queueServerWork(
                                          20,
                                          () -> {
                                             if (world instanceof Level _levelxxxxxxxxxxxxxxx) {
                                                if (!_levelxxxxxxxxxxxxxxx.m_5776_()) {
                                                   _levelxxxxxxxxxxxxxxx.m_5594_(
                                                      null,
                                                      BlockPos.m_274561_(x, y, z),
                                                      (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                                      SoundSource.NEUTRAL,
                                                      1.0F,
                                                      1.0F
                                                   );
                                                } else {
                                                   _levelxxxxxxxxxxxxxxx.m_7785_(
                                                      x,
                                                      y,
                                                      z,
                                                      (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.step")),
                                                      SoundSource.NEUTRAL,
                                                      1.0F,
                                                      1.0F,
                                                      false
                                                   );
                                                }
                                             }

                                             if (world instanceof ServerLevel _levelx) {
                                                _levelx.m_8767_(ParticleTypes.f_123746_, x, y, z, 5, 7.0, 10.0, 27.0, 1.0);
                                             }

                                             if (world instanceof ServerLevel _levelx) {
                                                _levelx.m_7654_()
                                                   .m_129892_()
                                                   .m_230957_(
                                                      new CommandSourceStack(
                                                            CommandSource.f_80164_,
                                                            new Vec3(x, y, z),
                                                            Vec2.f_82462_,
                                                            _levelx,
                                                            4,
                                                            "",
                                                            Component.m_237113_(""),
                                                            _levelx.m_7654_(),
                                                            null
                                                         )
                                                         .m_81324_(),
                                                      "/setblock 7 10 27 inside_the_system:base"
                                                   );
                                             }

                                             InsideTheSystemMod.queueServerWork(
                                                20,
                                                () -> {
                                                   if (world instanceof Level _levelxxxxxxxxxxxxxxxxxx) {
                                                      if (!_levelxxxxxxxxxxxxxxxxxx.m_5776_()) {
                                                         _levelxxxxxxxxxxxxxxxxxx.m_5594_(
                                                            null,
                                                            BlockPos.m_274561_(x, y, z),
                                                            (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                               .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                            SoundSource.NEUTRAL,
                                                            1.0F,
                                                            1.0F
                                                         );
                                                      } else {
                                                         _levelxxxxxxxxxxxxxxxxxx.m_7785_(
                                                            x,
                                                            y,
                                                            z,
                                                            (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                               .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                            SoundSource.NEUTRAL,
                                                            1.0F,
                                                            1.0F,
                                                            false
                                                         );
                                                      }
                                                   }

                                                   if (world instanceof ServerLevel _levelx) {
                                                      _levelx.m_8767_(ParticleTypes.f_123765_, x, y, z, 5, 7.0, 10.0, 28.0, 1.0);
                                                   }

                                                   if (world instanceof ServerLevel _levelx) {
                                                      _levelx.m_7654_()
                                                         .m_129892_()
                                                         .m_230957_(
                                                            new CommandSourceStack(
                                                                  CommandSource.f_80164_,
                                                                  new Vec3(x, y, z),
                                                                  Vec2.f_82462_,
                                                                  _levelx,
                                                                  4,
                                                                  "",
                                                                  Component.m_237113_(""),
                                                                  _levelx.m_7654_(),
                                                                  null
                                                               )
                                                               .m_81324_(),
                                                            "/setblock 7 10 28 inside_the_system:base"
                                                         );
                                                   }

                                                   InsideTheSystemMod.queueServerWork(
                                                      20,
                                                      () -> {
                                                         if (world instanceof Level _levelxxxxxxxxxxxxxxxxxxxxx) {
                                                            if (!_levelxxxxxxxxxxxxxxxxxxxxx.m_5776_()) {
                                                               _levelxxxxxxxxxxxxxxxxxxxxx.m_5594_(
                                                                  null,
                                                                  BlockPos.m_274561_(x, y, z),
                                                                  (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                     .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                  SoundSource.NEUTRAL,
                                                                  1.0F,
                                                                  1.0F
                                                               );
                                                            } else {
                                                               _levelxxxxxxxxxxxxxxxxxxxxx.m_7785_(
                                                                  x,
                                                                  y,
                                                                  z,
                                                                  (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                     .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                  SoundSource.NEUTRAL,
                                                                  1.0F,
                                                                  1.0F,
                                                                  false
                                                               );
                                                            }
                                                         }

                                                         if (world instanceof ServerLevel _levelx) {
                                                            _levelx.m_8767_(ParticleTypes.f_123765_, x, y, z, 5, 7.0, 10.0, 28.0, 1.0);
                                                         }

                                                         if (world instanceof ServerLevel _levelx) {
                                                            _levelx.m_7654_()
                                                               .m_129892_()
                                                               .m_230957_(
                                                                  new CommandSourceStack(
                                                                        CommandSource.f_80164_,
                                                                        new Vec3(x, y, z),
                                                                        Vec2.f_82462_,
                                                                        _levelx,
                                                                        4,
                                                                        "",
                                                                        Component.m_237113_(""),
                                                                        _levelx.m_7654_(),
                                                                        null
                                                                     )
                                                                     .m_81324_(),
                                                                  "/setblock 7 10 29 inside_the_system:base"
                                                               );
                                                         }

                                                         InsideTheSystemMod.queueServerWork(
                                                            20,
                                                            () -> {
                                                               if (world instanceof Level _levelxxxxxxxxxxxxxxxxxxxxxxxx) {
                                                                  if (!_levelxxxxxxxxxxxxxxxxxxxxxxxx.m_5776_()) {
                                                                     _levelxxxxxxxxxxxxxxxxxxxxxxxx.m_5594_(
                                                                        null,
                                                                        BlockPos.m_274561_(x, y, z),
                                                                        (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                           .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                        SoundSource.NEUTRAL,
                                                                        1.0F,
                                                                        1.0F
                                                                     );
                                                                  } else {
                                                                     _levelxxxxxxxxxxxxxxxxxxxxxxxx.m_7785_(
                                                                        x,
                                                                        y,
                                                                        z,
                                                                        (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                           .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                        SoundSource.NEUTRAL,
                                                                        1.0F,
                                                                        1.0F,
                                                                        false
                                                                     );
                                                                  }
                                                               }

                                                               if (world instanceof ServerLevel _levelx) {
                                                                  _levelx.m_8767_(ParticleTypes.f_123765_, x, y, z, 5, 7.0, 10.0, 28.0, 1.0);
                                                               }

                                                               if (world instanceof ServerLevel _levelx) {
                                                                  _levelx.m_7654_()
                                                                     .m_129892_()
                                                                     .m_230957_(
                                                                        new CommandSourceStack(
                                                                              CommandSource.f_80164_,
                                                                              new Vec3(x, y, z),
                                                                              Vec2.f_82462_,
                                                                              _levelx,
                                                                              4,
                                                                              "",
                                                                              Component.m_237113_(""),
                                                                              _levelx.m_7654_(),
                                                                              null
                                                                           )
                                                                           .m_81324_(),
                                                                        "/setblock 7 10 30 inside_the_system:base"
                                                                     );
                                                               }

                                                               InsideTheSystemMod.queueServerWork(
                                                                  20,
                                                                  () -> {
                                                                     if (world instanceof Level _levelxxxxxxxxxxxxxxxxxxxxxxxxxxx) {
                                                                        if (!_levelxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_5776_()) {
                                                                           _levelxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_5594_(
                                                                              null,
                                                                              BlockPos.m_274561_(x, y, z),
                                                                              (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                 .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                              SoundSource.NEUTRAL,
                                                                              1.0F,
                                                                              1.0F
                                                                           );
                                                                        } else {
                                                                           _levelxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_7785_(
                                                                              x,
                                                                              y,
                                                                              z,
                                                                              (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                 .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                              SoundSource.NEUTRAL,
                                                                              1.0F,
                                                                              1.0F,
                                                                              false
                                                                           );
                                                                        }
                                                                     }

                                                                     if (world instanceof ServerLevel _levelx) {
                                                                        _levelx.m_8767_(ParticleTypes.f_123765_, x, y, z, 5, 7.0, 10.0, 28.0, 1.0);
                                                                     }

                                                                     if (world instanceof ServerLevel _levelx) {
                                                                        _levelx.m_7654_()
                                                                           .m_129892_()
                                                                           .m_230957_(
                                                                              new CommandSourceStack(
                                                                                    CommandSource.f_80164_,
                                                                                    new Vec3(x, y, z),
                                                                                    Vec2.f_82462_,
                                                                                    _levelx,
                                                                                    4,
                                                                                    "",
                                                                                    Component.m_237113_(""),
                                                                                    _levelx.m_7654_(),
                                                                                    null
                                                                                 )
                                                                                 .m_81324_(),
                                                                              "/setblock 7 10 31 inside_the_system:base"
                                                                           );
                                                                     }

                                                                     InsideTheSystemMod.queueServerWork(
                                                                        20,
                                                                        () -> {
                                                                           if (world instanceof Level _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxx) {
                                                                              if (!_levelxxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_5776_()) {
                                                                                 _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_5594_(
                                                                                    null,
                                                                                    BlockPos.m_274561_(x, y, z),
                                                                                    (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                       .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                                    SoundSource.NEUTRAL,
                                                                                    1.0F,
                                                                                    1.0F
                                                                                 );
                                                                              } else {
                                                                                 _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_7785_(
                                                                                    x,
                                                                                    y,
                                                                                    z,
                                                                                    (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                       .getValue(new ResourceLocation("block.amethyst_block.step")),
                                                                                    SoundSource.NEUTRAL,
                                                                                    1.0F,
                                                                                    1.0F,
                                                                                    false
                                                                                 );
                                                                              }
                                                                           }

                                                                           if (world instanceof ServerLevel _serverworld) {
                                                                              StructureTemplate template = _serverworld.m_215082_()
                                                                                 .m_230359_(new ResourceLocation("inside_the_system", "story2"));
                                                                              if (template != null) {
                                                                                 template.m_230328_(
                                                                                    _serverworld,
                                                                                    new BlockPos(1, 10, 32),
                                                                                    new BlockPos(1, 10, 32),
                                                                                    new StructurePlaceSettings()
                                                                                       .m_74379_(Rotation.NONE)
                                                                                       .m_74377_(Mirror.NONE)
                                                                                       .m_74392_(false),
                                                                                    _serverworld.f_46441_,
                                                                                    3
                                                                                 );
                                                                              }
                                                                           }

                                                                           InsideTheSystemMod.queueServerWork(
                                                                              60,
                                                                              () -> {
                                                                                 if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                    world.m_7654_()
                                                                                       .m_6846_()
                                                                                       .m_240416_(
                                                                                          Component.m_237113_(
                                                                                             "<CoolPlayer303> It was not yet too late, but the street lamps had already lit up, casting their soft glow upon the familiar road. The girl walked happily along the same path she often took to school"
                                                                                          ),
                                                                                          false
                                                                                       );
                                                                                 }

                                                                                 if (world instanceof ServerLevel _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx) {
                                                                                    _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_7654_()
                                                                                       .m_129892_()
                                                                                       .m_230957_(
                                                                                          new CommandSourceStack(
                                                                                                CommandSource.f_80164_,
                                                                                                new Vec3(x, y, z),
                                                                                                Vec2.f_82462_,
                                                                                                _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx,
                                                                                                4,
                                                                                                "",
                                                                                                Component.m_237113_(""),
                                                                                                _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_7654_(),
                                                                                                null
                                                                                             )
                                                                                             .m_81324_(),
                                                                                          "/setblock 7 12 44 minecraft:light"
                                                                                       );
                                                                                 }

                                                                                 if (world instanceof Level _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxxx) {
                                                                                    if (!_levelxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_5776_()) {
                                                                                       _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_5594_(
                                                                                          null,
                                                                                          BlockPos.m_274561_(x, y, z),
                                                                                          (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                             .getValue(new ResourceLocation("inside_the_system:light")),
                                                                                          SoundSource.NEUTRAL,
                                                                                          1.0F,
                                                                                          1.0F
                                                                                       );
                                                                                    } else {
                                                                                       _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_7785_(
                                                                                          x,
                                                                                          y,
                                                                                          z,
                                                                                          (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                             .getValue(new ResourceLocation("inside_the_system:light")),
                                                                                          SoundSource.NEUTRAL,
                                                                                          1.0F,
                                                                                          1.0F,
                                                                                          false
                                                                                       );
                                                                                    }
                                                                                 }

                                                                                 InsideTheSystemMod.queueServerWork(
                                                                                    200,
                                                                                    () -> {
                                                                                       if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                          world.m_7654_()
                                                                                             .m_6846_()
                                                                                             .m_240416_(
                                                                                                Component.m_237113_(
                                                                                                   "<CoolPlayer303> She felt no fear traveling alone at such an hour, for her neighborhood was known to be safe, a place where crimes almost never occurred"
                                                                                                ),
                                                                                                false
                                                                                             );
                                                                                       }

                                                                                       InsideTheSystemMod.queueServerWork(
                                                                                          200,
                                                                                          () -> {
                                                                                             if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                world.m_7654_()
                                                                                                   .m_6846_()
                                                                                                   .m_240416_(
                                                                                                      Component.m_237113_(
                                                                                                         "<CoolPlayer303> Only the sudden cry of a crow startled her for a moment—sharp and unpleasant—but just as quickly, she brushed it aside and continued onward"
                                                                                                      ),
                                                                                                      false
                                                                                                   );
                                                                                             }

                                                                                             if (world instanceof Level _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx) {
                                                                                                if (!_levelxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_5776_()) {
                                                                                                   _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_5594_(
                                                                                                      null,
                                                                                                      BlockPos.m_274561_(
                                                                                                         InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                                                                                                         InsideTheSystemModVariables.MapVariables.get(world).PlayerY,
                                                                                                         InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
                                                                                                      ),
                                                                                                      (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                                         .getValue(
                                                                                                            new ResourceLocation("inside_the_system:raven")
                                                                                                         ),
                                                                                                      SoundSource.NEUTRAL,
                                                                                                      1.0F,
                                                                                                      1.0F
                                                                                                   );
                                                                                                } else {
                                                                                                   _levelxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.m_7785_(
                                                                                                      InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                                                                                                      InsideTheSystemModVariables.MapVariables.get(world).PlayerY,
                                                                                                      InsideTheSystemModVariables.MapVariables.get(world).PlayerZ,
                                                                                                      (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                                         .getValue(
                                                                                                            new ResourceLocation("inside_the_system:raven")
                                                                                                         ),
                                                                                                      SoundSource.NEUTRAL,
                                                                                                      1.0F,
                                                                                                      1.0F,
                                                                                                      false
                                                                                                   );
                                                                                                }
                                                                                             }

                                                                                             InsideTheSystemMod.queueServerWork(
                                                                                                200,
                                                                                                () -> {
                                                                                                   if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                      world.m_7654_()
                                                                                                         .m_6846_()
                                                                                                         .m_240416_(
                                                                                                            Component.m_237113_(
                                                                                                               "<CoolPlayer303> The road was not a short one, for the tunnel she sought lay near the edge of the forest"
                                                                                                            ),
                                                                                                            false
                                                                                                         );
                                                                                                   }

                                                                                                   InsideTheSystemMod.queueServerWork(
                                                                                                      200,
                                                                                                      () -> {
                                                                                                         if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                            world.m_7654_()
                                                                                                               .m_6846_()
                                                                                                               .m_240416_(
                                                                                                                  Component.m_237113_(
                                                                                                                     "<CoolPlayer303> Carried by her own curiosity, she had packed a few crackers and a small lantern, planning to explore the abandoned, eerie place with her friend—like something out of a horror film"
                                                                                                                  ),
                                                                                                                  false
                                                                                                               );
                                                                                                         }

                                                                                                         InsideTheSystemMod.queueServerWork(
                                                                                                            200,
                                                                                                            () -> {
                                                                                                               if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                                  world.m_7654_()
                                                                                                                     .m_6846_()
                                                                                                                     .m_240416_(
                                                                                                                        Component.m_237113_(
                                                                                                                           "<CoolPlayer303> In that moment, she was simply happy"
                                                                                                                        ),
                                                                                                                        false
                                                                                                                     );
                                                                                                               }

                                                                                                               InsideTheSystemModVariables.MapVariables.get(
                                                                                                                     world
                                                                                                                  )
                                                                                                                  .story2 = true;
                                                                                                               InsideTheSystemModVariables.MapVariables.get(
                                                                                                                     world
                                                                                                                  )
                                                                                                                  .syncData(world);
                                                                                                            }
                                                                                                         );
                                                                                                      }
                                                                                                   );
                                                                                                }
                                                                                             );
                                                                                          }
                                                                                       );
                                                                                    }
                                                                                 );
                                                                              }
                                                                           );
                                                                        }
                                                                     );
                                                                  }
                                                               );
                                                            }
                                                         );
                                                      }
                                                   );
                                                }
                                             );
                                          }
                                       );
                                    }
                                 );
                              }
                           );
                        }
                     );
                  }
               );
            }
         );
      }
   }
}
