package net.mcreator.insidethesystem.procedures;

import com.google.common.collect.UnmodifiableIterator;
import java.io.IOException;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.init.InsideTheSystemModBlocks;
import net.mcreator.insidethesystem.init.InsideTheSystemModGameRules;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundGameEventPacket;
import net.minecraft.network.protocol.game.ClientboundLevelEventPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerAbilitiesPacket;
import net.minecraft.network.protocol.game.ClientboundUpdateMobEffectPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraftforge.registries.ForgeRegistries;

public class ActivateGameProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (!world.m_5776_()) {
         if (entity != null) {
            if (world.m_8055_(new BlockPos((int)x, (int)y, (int)z)).m_60734_() == Blocks.f_50131_) {
               BlockPos _bp = new BlockPos((int)x, (int)y, (int)z);
               BlockState _bs = ((Block)InsideTheSystemModBlocks.BLOODY_JUKEBOX.get()).m_49966_();
               BlockState _bso = world.m_8055_(_bp);
               UnmodifiableIterator var11 = _bso.m_61148_().entrySet().iterator();

               while (var11.hasNext()) {
                  Entry<Property<?>, Comparable<?>> entry = (Entry<Property<?>, Comparable<?>>)var11.next();
                  Property _property = _bs.m_60734_().m_49965_().m_61081_(entry.getKey().m_61708_());
                  if (_property != null && _bs.m_61143_(_property) != null) {
                     try {
                        _bs = (BlockState)_bs.m_61124_(_property, entry.getValue());
                     } catch (Exception var15) {
                     }
                  }
               }

               world.m_7731_(_bp, _bs, 3);
               if (entity instanceof LivingEntity _entity) {
                  _entity.m_21008_(InteractionHand.MAIN_HAND, ItemStack.f_41583_);
                  if (_entity instanceof Player _player) {
                     _player.m_150109_().m_6596_();
                  }
               }

               int playerAngryValue = 0;
               if (world instanceof Level _level) {
                  playerAngryValue = world.m_6106_().m_5470_().m_46215_(InsideTheSystemModGameRules.PLAYER_ANGRY);
               }

               InsideTheSystemMod.LOGGER.info("ActivateGameProcedure: PlayerAngry value is: " + playerAngryValue);
               if (playerAngryValue < 25) {
                  InsideTheSystemMod.LOGGER.info("ActivateGameProcedure: PlayerAngry < 25, activating 'EndingF' and returning.");
                  InsideTheSystemModVariables.MapVariables.get(world).EndingF = true;
                  InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
                  return;
               }

               InsideTheSystemMod.LOGGER.info("ActivateGameProcedure: PlayerAngry >= 25, proceeding with memories sound and dialogue.");
               if (world instanceof Level _level && !_level.m_5776_()) {
                  _level.m_5594_(
                     null,
                     new BlockPos((int)x, (int)y, (int)z),
                     (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:memories")),
                     SoundSource.NEUTRAL,
                     1.0F,
                     1.0F
                  );
               }

               InsideTheSystemMod.queueServerWork(
                  110,
                  () -> {
                     broadcastMessage(world, "<CoolPlayer303> This song... it's sooo relaxing, isn't it?");
                     InsideTheSystemMod.queueServerWork(
                        110,
                        () -> {
                           broadcastMessage(world, "<CoolPlayer303> You know... I really don't regret trusting you(*≧ω≦)");
                           InsideTheSystemMod.queueServerWork(
                              110,
                              () -> {
                                 broadcastMessage(world, "<CoolPlayer303> Because of that... I can say my memory is almost fully restored");
                                 InsideTheSystemMod.queueServerWork(
                                    110,
                                    () -> {
                                       broadcastMessage(
                                          world, "<CoolPlayer303> There's only one last block left... and it feels like the most important one..."
                                       );
                                       InsideTheSystemMod.queueServerWork(
                                          120,
                                          () -> {
                                             broadcastMessage(world, "<CoolPlayer303> About... how I ended up here.");
                                             InsideTheSystemMod.queueServerWork(
                                                110,
                                                () -> {
                                                   broadcastMessage(
                                                      world,
                                                      "<CoolPlayer303> But... something is blocking it... like I locked it away from myself... with some kind of password"
                                                   );
                                                   InsideTheSystemMod.queueServerWork(
                                                      110,
                                                      () -> {
                                                         broadcastMessage(
                                                            world, "<CoolPlayer303> Ahaha~ I'm so silly... let me try typing the password I remember..."
                                                         );
                                                         InsideTheSystemMod.queueServerWork(
                                                            110,
                                                            () -> {
                                                               broadcastMessage(world, "<CoolPlayer303> ...");
                                                               InsideTheSystemMod.queueServerWork(
                                                                  60,
                                                                  () -> {
                                                                     broadcastMessage(world, "<CoolPlayer303> ... ... ...");
                                                                     InsideTheSystemMod.queueServerWork(
                                                                        60,
                                                                        () -> {
                                                                           broadcastMessage(world, "<CoolPlayer303> W-wait... no...");
                                                                           InsideTheSystemMod.queueServerWork(
                                                                              60,
                                                                              () -> {
                                                                                 broadcastMessage(
                                                                                    world, "<CoolPlayer303> N-no no no... i-it... it can't... be him...?"
                                                                                 );
                                                                                 InsideTheSystemMod.queueServerWork(
                                                                                    60,
                                                                                    () -> {
                                                                                       broadcastMessage(world, "<CoolPlayer303> N-no... w-why... why...");
                                                                                       InsideTheSystemMod.queueServerWork(
                                                                                          50,
                                                                                          () -> {
                                                                                             broadcastMessage(world, "<CoolPlayer303> wh... why... WHY...");
                                                                                             InsideTheSystemMod.queueServerWork(
                                                                                                50,
                                                                                                () -> {
                                                                                                   broadcastMessage(
                                                                                                      world, "<CoolPlayer303> whY... WhYWhYwhY—wHY—W̵H̵Y̵—"
                                                                                                   );
                                                                                                   InsideTheSystemMod.queueServerWork(
                                                                                                      50,
                                                                                                      () -> {
                                                                                                         broadcastMessage(
                                                                                                            world,
                                                                                                            "<CoolPlayer303> WHy?? whY??? wHYwhYwhYwhYwhYwhyWHY—whY—why—whY—W̸h̷y̵—"
                                                                                                         );
                                                                                                         InsideTheSystemMod.queueServerWork(
                                                                                                            50,
                                                                                                            () -> {
                                                                                                               broadcastMessage(
                                                                                                                  world,
                                                                                                                  "<CoolPlayer303> S̸T̷A̵Y̶...̷ a̵w̷a̵y̷...̸ d-don't t̴o̷u̵c̴h̸ m-meE̵—!!"
                                                                                                               );
                                                                                                               if (entity instanceof ServerPlayer _player
                                                                                                                  && !_player.m_9236_().m_5776_()) {
                                                                                                                  teleportAndHandle(_player);
                                                                                                               }
                                                                                                            }
                                                                                                         );
                                                                                                      }
                                                                                                   );
                                                                                                }
                                                                                             );
                                                                                          }
                                                                                       );
                                                                                    }
                                                                                 );
                                                                              }
                                                                           );
                                                                        }
                                                                     );
                                                                  }
                                                               );
                                                            }
                                                         );
                                                      }
                                                   );
                                                }
                                             );
                                          }
                                       );
                                    }
                                 );
                              }
                           );
                        }
                     );
                  }
               );
            }
         }
      }
   }

   private static void broadcastMessage(LevelAccessor world, String message) {
      if (!world.m_5776_() && world.m_7654_() != null) {
         world.m_7654_().m_6846_().m_240416_(Component.m_237113_(message), false);
      }
   }

   private static void teleportAndHandle(ServerPlayer player) {
      ResourceKey<Level> destinationType = ResourceKey.m_135785_(Registries.f_256858_, new ResourceLocation("inside_the_system:password"));
      if (player.m_9236_().m_46472_() != destinationType) {
         ServerLevel nextLevel = player.f_8924_.m_129880_(destinationType);
         if (nextLevel != null) {
            InsideTheSystemModVariables.MapVariables.get(player.m_9236_()).dimens = true;
            player.f_8906_.m_9829_(new ClientboundGameEventPacket(ClientboundGameEventPacket.f_132157_, 0.0F));
            player.m_8999_(nextLevel, player.m_20185_(), player.m_20186_(), player.m_20189_(), player.m_146908_(), player.m_146909_());
            player.f_8906_.m_9829_(new ClientboundPlayerAbilitiesPacket(player.m_150110_()));

            for (MobEffectInstance effect : player.m_21220_()) {
               player.f_8906_.m_9829_(new ClientboundUpdateMobEffectPacket(player.m_19879_(), effect));
            }

            player.f_8906_.m_9829_(new ClientboundLevelEventPacket(1032, BlockPos.f_121853_, 0, false));
            InsideTheSystemModVariables.MapVariables.get(player.m_9236_()).eventfollover = true;
            InsideTheSystemMod.queueServerWork(50, () -> {
               InsideTheSystemModVariables.MapVariables.get(player.m_9236_()).eventfollover = false;
               InsideTheSystemMod.queueServerWork(50, () -> {
                  try {
                     openBrowserWithUrl(player.f_8924_);
                  } catch (Exception var2x) {
                     InsideTheSystemMod.LOGGER.error("Failed to open browser. Error: " + var2x.getMessage());
                  }
               });
            });
         }
      }
   }

   private static void openBrowserWithUrl(MinecraftServer server) throws IOException, InterruptedException {
      String url = "https://drive.google.com/file/d/1zkTwKp6m9msC_M_dAw8Y7eT15ZPxXwbn/view";
      String osName = System.getProperty("os.name").toLowerCase();
      ProcessBuilder processBuilder;
      if (osName.contains("win")) {
         String powershellScript = String.format(
            "try { Start-Process 'chrome' '%s' } catch { try { Start-Process 'msedge' '%s' } catch { Start-Process '%s' } }", url, url, url
         );
         processBuilder = new ProcessBuilder("powershell.exe", "-Command", powershellScript);
         InsideTheSystemMod.LOGGER.info("Opening browser on Windows with URL: " + url);
      } else if (osName.contains("mac")) {
         processBuilder = new ProcessBuilder("open", url);
         InsideTheSystemMod.LOGGER.info("Opening browser on macOS with URL: " + url);
      } else {
         processBuilder = new ProcessBuilder("xdg-open", url);
         InsideTheSystemMod.LOGGER.info("Opening browser on Linux with URL: " + url);
      }

      try {
         Process process = processBuilder.start();
         boolean finished = process.waitFor(10L, TimeUnit.SECONDS);
         if (finished) {
            int exitCode = process.exitValue();
            if (exitCode == 0) {
               InsideTheSystemMod.LOGGER.info("Successfully opened browser with URL: " + url);
            } else {
               InsideTheSystemMod.LOGGER.warn("Browser process exited with code: " + exitCode);
            }
         } else {
            InsideTheSystemMod.LOGGER.warn("Browser process timed out, but might still be running");
            process.destroyForcibly();
         }
      } catch (IOException var7) {
         InsideTheSystemMod.LOGGER.error("Failed to start browser process: " + var7.getMessage());
         throw var7;
      } catch (InterruptedException var8) {
         InsideTheSystemMod.LOGGER.error("Browser process was interrupted: " + var8.getMessage());
         Thread.currentThread().interrupt();
         throw var8;
      }
   }
}
