package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.registries.ForgeRegistries;

public class FollowerSpawnProcedure {
   public static void execute(LevelAccessor world) {
      InsideTheSystemModVariables.MapVariables.get(world).Second = false;
      InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      if (world instanceof Level _level) {
         if (!_level.m_5776_()) {
            _level.m_5594_(
               null,
               BlockPos.m_274561_(
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerY,
                  InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
               ),
               (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:spawnfollower")),
               SoundSource.NEUTRAL,
               1.0F,
               1.0F
            );
         } else {
            _level.m_7785_(
               InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
               InsideTheSystemModVariables.MapVariables.get(world).PlayerY,
               InsideTheSystemModVariables.MapVariables.get(world).PlayerZ,
               (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:spawnfollower")),
               SoundSource.NEUTRAL,
               1.0F,
               1.0F,
               false
            );
         }
      }

      InsideTheSystemModVariables.MapVariables.get(world).followerdied = 2000.0;
      InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
   }
}
