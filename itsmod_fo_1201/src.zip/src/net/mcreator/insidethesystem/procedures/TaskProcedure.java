package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class TaskProcedure {
   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player.m_20185_(), event.player.m_20186_(), event.player.m_20189_());
      }
   }

   public static void execute(LevelAccessor world, double x, double y, double z) {
      execute(null, world, x, y, z);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z) {
      if (InsideTheSystemModVariables.MapVariables.get(world).Task) {
         if (world instanceof ServerLevel _level) {
            _level.m_7654_()
               .m_129892_()
               .m_230957_(
                  new CommandSourceStack(
                        CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                     )
                     .m_81324_(),
                  "/title @a times 20 60 20"
               );
         }

         if (world instanceof ServerLevel _level) {
            _level.m_7654_()
               .m_129892_()
               .m_230957_(
                  new CommandSourceStack(
                        CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                     )
                     .m_81324_(),
                  "/title @a subtitle {\"text\":\"The path to understanding\",\"italic\":true,\"color\":\"#DADADA\"}"
               );
         }

         if (world instanceof ServerLevel _level) {
            _level.m_7654_()
               .m_129892_()
               .m_230957_(
                  new CommandSourceStack(
                        CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                     )
                     .m_81324_(),
                  "/title @a title {\"text\":\"ACT II\"}"
               );
         }

         if (!world.m_5776_() && world.m_7654_() != null) {
            world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> Hey... thanks for walking with me, you’re so sweet~!"), false);
         }

         InsideTheSystemMod.queueServerWork(
            70,
            () -> {
               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_()
                     .m_6846_()
                     .m_240416_(Component.m_237113_("<CoolPlayer303> It brings back memories, I think we can survive together, don’t you think?"), false);
               }

               InsideTheSystemMod.queueServerWork(
                  70,
                  () -> {
                     if (!world.m_5776_() && world.m_7654_() != null) {
                        world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> You know, could you make me a toy?.. Please!!!!"), false);
                     }

                     InsideTheSystemMod.queueServerWork(
                        70,
                        () -> {
                           if (!world.m_5776_() && world.m_7654_() != null) {
                              world.m_7654_()
                                 .m_6846_()
                                 .m_240416_(Component.m_237113_("<CoolPlayer303> I remember my plush bear Gerd — he was so special"), false);
                           }

                           InsideTheSystemMod.queueServerWork(
                              70,
                              () -> {
                                 if (!world.m_5776_() && world.m_7654_() != null) {
                                    world.m_7654_()
                                       .m_6846_()
                                       .m_240416_(
                                          Component.m_237113_(
                                             "<CoolPlayer303> In the first and third rows, there is brown wool in the center, in the second row on the sides there is black wool, and in the center... something organic, like meat, hehe, how strange"
                                          ),
                                          false
                                       );
                                 }

                                 InsideTheSystemMod.queueServerWork(
                                    70,
                                    () -> {
                                       if (!world.m_5776_() && world.m_7654_() != null) {
                                          world.m_7654_()
                                             .m_6846_()
                                             .m_240416_(
                                                Component.m_237113_(
                                                   "<CoolPlayer303> I think it’s craftable like this — I’ll leave the recipe, I’ll be so happy if you make it for me!!"
                                                ),
                                                false
                                             );
                                       }

                                       InsideTheSystemMod.queueServerWork(
                                          300,
                                          () -> {
                                             if (world instanceof ServerLevel _levelx) {
                                                _levelx.m_7654_()
                                                   .m_129892_()
                                                   .m_230957_(
                                                      new CommandSourceStack(
                                                            CommandSource.f_80164_,
                                                            new Vec3(x, y, z),
                                                            Vec2.f_82462_,
                                                            _levelx,
                                                            4,
                                                            "",
                                                            Component.m_237113_(""),
                                                            _levelx.m_7654_(),
                                                            null
                                                         )
                                                         .m_81324_(),
                                                      "/title @a actionbar [\"Failure ≠ The End\"]"
                                                   );
                                             }

                                             InsideTheSystemMod.queueServerWork(
                                                100,
                                                () -> {
                                                   if (world instanceof ServerLevel _levelxx) {
                                                      _levelxx.m_7654_()
                                                         .m_129892_()
                                                         .m_230957_(
                                                            new CommandSourceStack(
                                                                  CommandSource.f_80164_,
                                                                  new Vec3(x, y, z),
                                                                  Vec2.f_82462_,
                                                                  _levelxx,
                                                                  4,
                                                                  "",
                                                                  Component.m_237113_(""),
                                                                  _levelxx.m_7654_(),
                                                                  null
                                                               )
                                                               .m_81324_(),
                                                            "/title @a actionbar [\"Quests can always be completed\"]"
                                                         );
                                                   }
                                                }
                                             );
                                          }
                                       );
                                    }
                                 );
                              }
                           );
                        }
                     );
                  }
               );
            }
         );
         InsideTheSystemModVariables.MapVariables.get(world).Task = false;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }
   }
}
