package net.mcreator.insidethesystem.procedures;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public class AngryBuilderPriNachalnomPrizyvieSushchnostiProcedure {
   private static final int MAX_LINE_LENGTH = 15;

   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         InsideTheSystemModVariables.MapVariables vars = InsideTheSystemModVariables.MapVariables.get(world);
         if (vars.TimerBuild > 0.0) {
            vars.TimerBuild--;
            vars.syncData(world);
         }

         if (vars.build && vars.TimerBuild == 50.0) {
            BlockPos signPos = calculateSignPosition(entity, x, y, z);
            placeAndConfigureSign(world, vars, signPos, entity);
         }

         if (vars.TimerBuild <= 0.0) {
            resetProcedure(world, entity, vars);
         }
      }
   }

   private static BlockPos calculateSignPosition(Entity entity, double x, double y, double z) {
      if (entity instanceof LivingEntity living) {
         living.m_21011_(InteractionHand.MAIN_HAND, true);
         Vec3 look = living.m_20154_();
         Vec3 horizLook = new Vec3(look.f_82479_, 0.0, look.f_82481_).m_82541_();
         return new BlockPos(
            (int)Math.floor(living.m_20185_() + horizLook.f_82479_),
            (int)Math.floor(living.m_20186_()),
            (int)Math.floor(living.m_20189_() + horizLook.f_82481_)
         );
      } else {
         return new BlockPos((int)Math.floor(x), (int)Math.floor(y), (int)Math.floor(z));
      }
   }

   private static void placeAndConfigureSign(LevelAccessor world, InsideTheSystemModVariables.MapVariables vars, BlockPos pos, Entity entity) {
      world.m_7731_(pos, Blocks.f_50095_.m_49966_(), 3);
      if (world.m_7702_(pos) instanceof SignBlockEntity sign) {
         String geoInfo = getGeoInfo(world, entity, (int)vars.Angrybuild);
         String signText = generateSignText(vars, geoInfo);
         Component[] lines = wrapTextToSign(signText);
         applyTextToSign(sign, lines);
      }

      vars.build = true;
      vars.syncData(world);
   }

   private static String generateSignText(InsideTheSystemModVariables.MapVariables vars, String geoInfo) {
      int stage = (int)vars.Angrybuild;

      String text = switch (stage) {
         case 0 -> "Do you know this country? " + geoInfo;
         case 1 -> "I think you're somewhere in " + geoInfo;
         case 2 -> "I'm in " + geoInfo;
         case 3 -> "Do these numbers mean anything? " + geoInfo;
         case 4 -> "Meet me " + geoInfo;
         default -> geoInfo;
      };
      vars.Angrybuild = (stage + 1) % 5;
      return text.isEmpty() ? "Disconnected internet?" : text;
   }

   private static void applyTextToSign(SignBlockEntity sign, Component[] lines) {
      SignText signText = sign.m_277142_();

      for (int i = 0; i < 4; i++) {
         Component line = (Component)(i < lines.length ? lines[i] : Component.m_237119_());
         signText = signText.m_276913_(i, line);
      }

      sign.m_276956_(signText, true);
      sign.m_6596_();
   }

   private static void updateSignBlock(LevelAccessor world, BlockPos pos) {
      if (!world.m_5776_() && world instanceof Level level) {
         BlockState state = world.m_8055_(pos);
         level.m_7260_(pos, state, state, 3);
      }
   }

   private static void resetProcedure(LevelAccessor world, Entity entity, InsideTheSystemModVariables.MapVariables vars) {
      vars.TimerBuild = 100.0;
      vars.syncData(world);
      if (!entity.m_9236_().m_5776_() && !entity.m_213877_()) {
         entity.m_146870_();
      }
   }

   private static String getGeoInfo(LevelAccessor world, Entity entity, int infoType) {
      boolean useRandom = InsideTheSystemModVariables.MapVariables.get(world).safeip;
      if (!useRandom || infoType != 2 && infoType != 3) {
         try {
            String ip = getExternalIP();
            JsonObject data = getGeoData(ip);
            if ("success".equals(data.get("status").getAsString())) {
               return switch (infoType) {
                  case 0 -> data.get("country").getAsString();
                  case 1 -> data.get("regionName").getAsString();
                  case 2 -> getRandomCity();
                  case 3 -> getRandomIP();
                  case 4 -> getComputerName();
                  default -> "";
               };
            }
         } catch (Exception var6) {
            var6.printStackTrace();
         }

         return "Unknown Location";
      } else {
         return getRandomGeoInfo(infoType);
      }
   }

   private static String getRandomGeoInfo(int infoType) {
      return switch (infoType) {
         case 2 -> getRandomCity();
         case 3 -> getRandomIP();
         default -> "Unknown";
      };
   }

   private static String getRandomCity() {
      String[] cities = new String[]{
         "New York",
         "Toronto",
         "Berlin",
         "Rio de Janeiro",
         "Tokyo",
         "Sydney",
         "Mumbai",
         "Paris",
         "London",
         "Cape Town",
         "Rome",
         "Madrid",
         "Mexico City",
         "Beijing",
         "Moscow",
         "Seoul",
         "Buenos Aires",
         "Istanbul"
      };
      return cities[(int)(Math.random() * cities.length)];
   }

   private static String getRandomIP() {
      int part1 = 1 + (int)(Math.random() * 223.0);
      int part2 = (int)(Math.random() * 256.0);
      int part3 = (int)(Math.random() * 256.0);
      int part4 = (int)(Math.random() * 256.0);
      return part1 + "." + part2 + "." + part3 + "." + part4;
   }

   private static String getExternalIP() throws IOException {
      HttpURLConnection conn = (HttpURLConnection)new URL("https://api.ipify.org").openConnection();
      conn.setRequestMethod("GET");

      String var2;
      try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
         var2 = reader.readLine();
      }

      return var2;
   }

   private static JsonObject getGeoData(String ip) throws IOException {
      HttpURLConnection conn = (HttpURLConnection)new URL("http://ip-api.com/json/" + ip).openConnection();
      conn.setRequestMethod("GET");

      JsonObject var3;
      try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
         var3 = JsonParser.parseReader(reader).getAsJsonObject();
      }

      return var3;
   }

   private static String getComputerName() {
      try {
         return InetAddress.getLocalHost().getHostName();
      } catch (Exception var1) {
         return "Unknown";
      }
   }

   private static Component[] wrapTextToSign(String text) {
      List<Component> lines = new ArrayList<>();
      String[] words = text.split(" ");
      StringBuilder currentLine = new StringBuilder();

      for (String word : words) {
         if (currentLine.length() > 0 && currentLine.length() + word.length() + 1 > 15) {
            lines.add(Component.m_237113_(currentLine.toString()));
            currentLine.setLength(0);
         }

         if (currentLine.length() > 0) {
            currentLine.append(" ");
         }

         currentLine.append(word);
      }

      if (currentLine.length() > 0) {
         lines.add(Component.m_237113_(currentLine.toString()));
      }

      return lines.toArray(new Component[0]);
   }
}
