package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.init.InsideTheSystemModItems;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.registries.ForgeRegistries;

@EventBusSubscriber
public class ShardsProcedure {
   @SubscribeEvent
   public static void onChat(ServerChatEvent event) {
      execute(
         event.getPlayer().m_9236_(),
         event.getPlayer().m_20185_(),
         event.getPlayer().m_20186_(),
         event.getPlayer().m_20189_(),
         event.getRawText(),
         event.getPlayer()
      );
   }

   public static void execute(LevelAccessor world, double x, double y, double z, String text, Entity entity) {
      if (text != null) {
         InsideTheSystemModVariables.MapVariables vars = InsideTheSystemModVariables.MapVariables.get(world);
         if (text.equals("7H#j9K!p2@Qm5*W") && !vars.shard1) {
            vars.shard1 = true;
            vars.syncData(world);
            spawnItemAndSound(world, x, y, z, new ItemStack((ItemLike)InsideTheSystemModItems.BETRAYAL.get()), entity);
         } else if (text.equals("L3f3R8%tN6vX&zY4") && !vars.shard2) {
            vars.shard2 = true;
            vars.syncData(world);
            spawnItemAndSound(world, x, y, z, new ItemStack((ItemLike)InsideTheSystemModItems.VIOLENCE.get()), entity);
         } else if (text.equals("9Bq2!kP8*#mD3$wF") && !vars.shard3) {
            vars.shard3 = true;
            vars.syncData(world);
            spawnItemAndSound(world, x, y, z, new ItemStack((ItemLike)InsideTheSystemModItems.CONFUSION.get()), entity);
         } else if (text.equals("T5@yH7*gK4!nJ8$d") && !vars.shard4) {
            vars.shard4 = true;
            vars.syncData(world);
            spawnItemAndSound(world, x, y, z, new ItemStack((ItemLike)InsideTheSystemModItems.ACCEPTANCE.get()), entity);
         }
      }
   }

   private static void spawnItemAndSound(LevelAccessor world, double x, double y, double z, ItemStack item, Entity entity) {
      if (world instanceof Level _level && !_level.m_5776_()) {
         ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, item);
         entityToSpawn.m_32010_(10);
         _level.m_7967_(entityToSpawn);
      }

      if (world instanceof Level _level) {
         if (!_level.m_5776_()) {
            _level.m_5594_(
               null,
               new BlockPos((int)x, (int)y, (int)z),
               (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:shards")),
               SoundSource.NEUTRAL,
               1.0F,
               1.0F
            );
         } else {
            _level.m_7785_(
               x,
               y,
               z,
               (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:shards")),
               SoundSource.NEUTRAL,
               1.0F,
               1.0F,
               false
            );
         }
      }

      if (entity instanceof LivingEntity living) {
         living.m_7292_(new MobEffectInstance(MobEffects.f_216964_, 60, 0));
      }
   }
}
