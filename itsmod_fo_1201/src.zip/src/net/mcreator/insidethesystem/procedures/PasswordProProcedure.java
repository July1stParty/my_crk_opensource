package net.mcreator.insidethesystem.procedures;

import java.util.HashMap;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.init.InsideTheSystemModEntities;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.registries.ForgeRegistries;

public class PasswordProProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, HashMap guistate) {
      if (guistate != null) {
         if ("Mad father".equals(guistate.containsKey("text:Password") ? ((EditBox)guistate.get("text:Password")).m_94155_() : "")) {
            if (world instanceof Level _level) {
               if (!_level.m_5776_()) {
                  _level.m_5594_(
                     null,
                     BlockPos.m_274561_(x, y, z),
                     (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:accept")),
                     SoundSource.NEUTRAL,
                     1.0F,
                     1.0F
                  );
               } else {
                  _level.m_7785_(
                     x,
                     y,
                     z,
                     (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:accept")),
                     SoundSource.NEUTRAL,
                     1.0F,
                     1.0F,
                     false
                  );
               }
            }

            if (world instanceof ServerLevel _levelx) {
               Entity entityToSpawn = ((EntityType)InsideTheSystemModEntities.AYANAMI_AIKO.get())
                  .m_262496_(_levelx, new BlockPos(3, 1, 10), MobSpawnType.MOB_SUMMONED);
               if (entityToSpawn != null) {
                  entityToSpawn.m_146922_(world.m_213780_().m_188501_() * 360.0F);
               }
            }

            InsideTheSystemModVariables.MapVariables.get(world).breakb = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemMod.queueServerWork(
               40,
               () -> {
                  world.m_46961_(BlockPos.m_274561_(x, y, z), false);
                  InsideTheSystemMod.queueServerWork(
                     20,
                     () -> {
                        world.m_46961_(BlockPos.m_274561_(x, y - 1.0, z), false);
                        InsideTheSystemMod.queueServerWork(
                           20,
                           () -> {
                              world.m_46961_(BlockPos.m_274561_(x, y + 1.0, z), false);
                              if (world instanceof Level _levelxx) {
                                 if (!_levelxx.m_5776_()) {
                                    _levelxx.m_5594_(
                                       null,
                                       BlockPos.m_274561_(x, y, z),
                                       (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:aiko")),
                                       SoundSource.NEUTRAL,
                                       1.0F,
                                       1.0F
                                    );
                                 } else {
                                    _levelxx.m_7785_(
                                       x,
                                       y,
                                       z,
                                       (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:aiko")),
                                       SoundSource.NEUTRAL,
                                       1.0F,
                                       1.0F,
                                       false
                                    );
                                 }
                              }
                           }
                        );
                     }
                  );
               }
            );
         } else if (!"Mad father".equals(guistate.containsKey("text:Password") ? ((EditBox)guistate.get("text:Password")).m_94155_() : "")) {
            if (guistate.get("text:Password") instanceof EditBox _tf) {
               _tf.m_94144_("");
            }

            if (world instanceof Level _levelxx) {
               if (!_levelxx.m_5776_()) {
                  _levelxx.m_5594_(
                     null,
                     BlockPos.m_274561_(x, y, z),
                     (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:error")),
                     SoundSource.NEUTRAL,
                     1.0F,
                     1.0F
                  );
               } else {
                  _levelxx.m_7785_(
                     x,
                     y,
                     z,
                     (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:error")),
                     SoundSource.NEUTRAL,
                     1.0F,
                     1.0F,
                     false
                  );
               }
            }

            InsideTheSystemModVariables.MapVariables.get(world).errors--;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }
      }
   }
}
