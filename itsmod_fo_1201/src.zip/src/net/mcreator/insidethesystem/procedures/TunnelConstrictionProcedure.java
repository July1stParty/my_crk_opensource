package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.init.InsideTheSystemModBlocks;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.registries.ForgeRegistries;

@EventBusSubscriber
public class TunnelConstrictionProcedure {
   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player.m_20185_(), event.player.m_20186_(), event.player.m_20189_(), event.player);
      }
   }

   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      execute(null, world, x, y, z, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (entity.m_9236_().m_46472_() == ResourceKey.m_135785_(Registries.f_256858_, new ResourceLocation("inside_the_system:ending_tunnel"))) {
            if (Math.round(entity.m_20185_()) == 12L && InsideTheSystemModVariables.MapVariables.get(world).Tunnel == 0.0) {
               if (world instanceof ServerLevel _level) {
                  _level.m_7654_()
                     .m_129892_()
                     .m_230957_(
                        new CommandSourceStack(
                              CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                           )
                           .m_81324_(),
                        "setblock 3 1 1 inside_the_system:base"
                     );
               }

               if (world instanceof ServerLevel _level) {
                  _level.m_7654_()
                     .m_129892_()
                     .m_230957_(
                        new CommandSourceStack(
                              CommandSource.f_80164_, new Vec3(x, y, z), Vec2.f_82462_, _level, 4, "", Component.m_237113_(""), _level.m_7654_(), null
                           )
                           .m_81324_(),
                        "setblock 3 2 1 inside_the_system:base"
                     );
               }

               if (world instanceof Level _level) {
                  if (!_level.m_5776_()) {
                     _level.m_5594_(
                        null,
                        BlockPos.m_274561_(x, y, z),
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:tunnelsound")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F
                     );
                  } else {
                     _level.m_7785_(
                        x,
                        y,
                        z,
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:tunnelsound")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F,
                        false
                     );
                  }
               }

               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> Once upon a time, there lived a little girl..."), false);
               }

               InsideTheSystemModVariables.MapVariables.get(world).Tunnel++;
               InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            }

            if (Math.round(entity.m_20185_()) == 4L && InsideTheSystemModVariables.MapVariables.get(world).Tunnel == 1.0) {
               world.m_7731_(BlockPos.m_274561_(10.0, y, z), ((Block)InsideTheSystemModBlocks.BASE.get()).m_49966_(), 3);
               world.m_7731_(BlockPos.m_274561_(10.0, y + 1.0, z), ((Block)InsideTheSystemModBlocks.BASE.get()).m_49966_(), 3);
               if (world instanceof Level _levelx) {
                  if (!_levelx.m_5776_()) {
                     _levelx.m_5594_(
                        null,
                        BlockPos.m_274561_(x, y, z),
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:tunnelsound")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F
                     );
                  } else {
                     _levelx.m_7785_(
                        x,
                        y,
                        z,
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:tunnelsound")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F,
                        false
                     );
                  }
               }

               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> She loved reading books and eating dango..."), false);
               }

               InsideTheSystemModVariables.MapVariables.get(world).Tunnel++;
               InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            }

            if (Math.round(entity.m_20185_()) == 9L && InsideTheSystemModVariables.MapVariables.get(world).Tunnel == 2.0) {
               world.m_7731_(BlockPos.m_274561_(5.0, y, z), ((Block)InsideTheSystemModBlocks.BASE.get()).m_49966_(), 3);
               world.m_7731_(BlockPos.m_274561_(5.0, y + 1.0, z), ((Block)InsideTheSystemModBlocks.BASE.get()).m_49966_(), 3);
               if (world instanceof Level _levelxx) {
                  if (!_levelxx.m_5776_()) {
                     _levelxx.m_5594_(
                        null,
                        BlockPos.m_274561_(x, y, z),
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:tunnelsound")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F
                     );
                  } else {
                     _levelxx.m_7785_(
                        x,
                        y,
                        z,
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:tunnelsound")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F,
                        false
                     );
                  }
               }

               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_()
                     .m_6846_()
                     .m_240416_(Component.m_237113_("<CoolPlayer303> Every single day, she would open her favorite story about the Little Prince..."), false);
               }

               InsideTheSystemModVariables.MapVariables.get(world).Tunnel++;
               InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            }

            if (Math.round(entity.m_20185_()) == 6L && InsideTheSystemModVariables.MapVariables.get(world).Tunnel == 3.0) {
               world.m_7731_(BlockPos.m_274561_(9.0, y, z), ((Block)InsideTheSystemModBlocks.BASE.get()).m_49966_(), 3);
               world.m_7731_(BlockPos.m_274561_(9.0, y + 1.0, z), ((Block)InsideTheSystemModBlocks.BASE.get()).m_49966_(), 3);
               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> But she had no friends at all..."), false);
               }

               if (world instanceof Level _levelxxx) {
                  if (!_levelxxx.m_5776_()) {
                     _levelxxx.m_5594_(
                        null,
                        BlockPos.m_274561_(x, y, z),
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:tunnelsound")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F
                     );
                  } else {
                     _levelxxx.m_7785_(
                        x,
                        y,
                        z,
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:tunnelsound")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F,
                        false
                     );
                  }
               }

               InsideTheSystemModVariables.MapVariables.get(world).Tunnel++;
               InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            }

            if (Math.round(entity.m_20185_()) == 8L && InsideTheSystemModVariables.MapVariables.get(world).Tunnel == 4.0) {
               world.m_7731_(BlockPos.m_274561_(6.0, y, z), ((Block)InsideTheSystemModBlocks.BASE.get()).m_49966_(), 3);
               world.m_7731_(BlockPos.m_274561_(6.0, y + 1.0, z), ((Block)InsideTheSystemModBlocks.BASE.get()).m_49966_(), 3);
               if (world instanceof Level _levelxxxx) {
                  if (!_levelxxxx.m_5776_()) {
                     _levelxxxx.m_5594_(
                        null,
                        BlockPos.m_274561_(x, y, z),
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:tunnelsound")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F
                     );
                  } else {
                     _levelxxxx.m_7785_(
                        x,
                        y,
                        z,
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:tunnelsound")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F,
                        false
                     );
                  }
               }

               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> And then, one day, he returned to her life..."), false);
               }

               InsideTheSystemModVariables.MapVariables.get(world).Tunnel++;
               InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            }

            if (Math.round(entity.m_20185_()) == 8L && InsideTheSystemModVariables.MapVariables.get(world).Tunnel == 5.0) {
               world.m_7731_(BlockPos.m_274561_(8.0, y, z), ((Block)InsideTheSystemModBlocks.BASE.get()).m_49966_(), 3);
               world.m_7731_(BlockPos.m_274561_(8.0, y + 1.0, z), ((Block)InsideTheSystemModBlocks.BASE.get()).m_49966_(), 3);
               if (world instanceof Level _levelxxxxx) {
                  if (!_levelxxxxx.m_5776_()) {
                     _levelxxxxx.m_5594_(
                        null,
                        BlockPos.m_274561_(x, y, z),
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:tunnelsound")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F
                     );
                  } else {
                     _levelxxxxx.m_7785_(
                        x,
                        y,
                        z,
                        (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:tunnelsound")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F,
                        false
                     );
                  }
               }

               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> That return became the reason for her death..."), false);
               }

               InsideTheSystemModVariables.MapVariables.get(world).Tunnel++;
               InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            }

            if (InsideTheSystemModVariables.MapVariables.get(world).Tunnel == 6.0) {
               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> And now, leave... you have no place here."), false);
               }

               InsideTheSystemModVariables.MapVariables.get(world).Tunnel++;
               InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
               InsideTheSystemModVariables.MapVariables.get(world).Endingf = true;
               InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            }
         }
      }
   }
}
