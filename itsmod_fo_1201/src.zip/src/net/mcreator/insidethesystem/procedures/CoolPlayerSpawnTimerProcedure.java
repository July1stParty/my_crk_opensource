package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent.LevelTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class CoolPlayerSpawnTimerProcedure {
   @SubscribeEvent
   public static void onWorldTick(LevelTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.level);
      }
   }

   private static void execute(@Nullable Event event, LevelAccessor world) {
      InsideTheSystemModVariables.MapVariables vars = InsideTheSystemModVariables.MapVariables.get(world);
      if (vars.TimerJoin <= 0.0 && vars.Colljoin && !vars.TimerEnd) {
         playSpawnSoundWithSilentCommand(world, vars.PlayerX, vars.PlayerY, vars.PlayerZ);
         vars.showInTab = true;
         vars.Colljoin = false;
         vars.spawn = true;
         vars.TimerEnd = true;
         vars.firstSpawnDone = true;
         vars.messageDelay = 20.0;
         vars.syncData(world);
      }

      if (vars.messageDelay > 0.0) {
         vars.messageDelay--;
         if (vars.messageDelay <= 0.0) {
            sendDelayedMessage(world);
         }

         vars.syncData(world);
      }
   }

   private static void playSpawnSoundWithSilentCommand(LevelAccessor world, double x, double y, double z) {
      if (world instanceof ServerLevel serverLevel) {
         MinecraftServer server = serverLevel.m_7654_();
         if (server != null) {
            CommandSourceStack silentSource = new CommandSourceStack(
                  server, new Vec3(x, y, z), Vec2.f_82462_, serverLevel, 2, "", Component.m_237119_(), server, null
               )
               .m_81324_();
            String command = String.format("playsound inside_the_system:spawnplayer ambient @a %s %s %s 1 1", (int)x, (int)y, (int)z);
            server.m_129892_().m_230957_(silentSource, command);
         }
      }
   }

   private static void sendDelayedMessage(LevelAccessor world) {
      if (!world.m_5776_() && world.m_7654_() != null) {
         world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> Uh halloo!!!!"), false);
      }
   }
}
