package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.init.InsideTheSystemModItems;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;

public class FatherKnifeProcedure {
   public static void execute(Entity entity) {
      if (entity != null) {
         if (entity instanceof LivingEntity _entity) {
            ItemStack _setstack = new ItemStack((ItemLike)InsideTheSystemModItems.BLOODYKNIFE.get());
            _setstack.m_41764_(1);
            _entity.m_21008_(InteractionHand.MAIN_HAND, _setstack);
            if (_entity instanceof Player _player) {
               _player.m_150109_().m_6596_();
            }
         }
      }
   }
}
