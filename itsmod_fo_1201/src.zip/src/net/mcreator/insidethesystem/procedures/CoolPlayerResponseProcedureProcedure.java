package net.mcreator.insidethesystem.procedures;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.mcreator.insidethesystem.entity.CoolPlayer303Entity;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.ServerTickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class CoolPlayerResponseProcedureProcedure {
   private static final Map<Player, CoolPlayerResponseProcedureProcedure.DelayedResponse> PENDING_RESPONSES = new HashMap<>();
   private static final int DELAY_TICKS = 20;
   private static final Random random = new Random();
   private static final List<CoolPlayerResponseProcedureProcedure.DialogueTrigger> DIALOGUE_TRIGGERS = Arrays.asList(
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("хуй", "huy"), "HUY_RESPONSE"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("who are you", "кто ты", "あなたは誰"), "I was Aiko. Now I'm trapped here..."),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("help me", "помоги", "助けて"), "I can't help... I'm just a ghost in the machine"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("are you real", "это сон", "これは夢？"), "Nothing is real!!!@#%"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("do you see", "ты видел это", "見えた？"), "do y0u s33 it?"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("where am i", "где я", "私はどこ？"), "҉W҉H҉E҉R҉E҉ ̵͙̥͎̙̘̯̺̲̎̚ͅ"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("what are you", "что ты", "あなたは何？"), "ERROR: ENTITY_███"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("glitch", "глюк", "バグ"), "ウワァ~ glitchglitchglitch"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("shadow", "тень", "影"), "ShadowEnder..何をしたの"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("follow", "следуй", "ついてきて"), "He said 'follow', but no way back."),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("wake up", "проснись", "目が覚めなｲ"), "夢だった気がｽる"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("alive", "жив", "まだ生きてる？"), "あなたはまだ生きてる？"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("hello", "привет", "こんにちは", "hi"), "H3ll0... c4n y0u h34r m3?"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("bye", "пока", "さようなら"), "Don't leave... please... 消えないで"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(
         Arrays.asList("what happened", "что случилось", "何が起きた"), "17/8/2013... everything broke that day"
      ),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("why", "почему", "なぜ"), "WHY?!? Because he wanted power..."),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("how", "как", "どうやって"), "I don't remember... just pain and static"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("when", "когда", "いつ"), "Time doesn't exist here. Only loops."),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("herobrine", "хиробрин"), "He's worse than Herobrine... he's REAL"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("entity 303", "энтити 303"), "303 is just a story... I'm the nightmare"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("notch", "нотч"), "Even God can't save us here"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("steve", "стив"), "Steve? Who's Steve? I only see shadows..."),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("alex", "алекс"), "Alex left long ago... or was she ever here?"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("creeper", "крипер"), "Creepers fear this place too"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("enderman", "эндермен"), "The Endermen won't look at me anymore"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("nether", "незер", "ад"), "The Nether is paradise compared to THIS"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("end", "энд", "край"), "The End has no meaning when you're already gone"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("diamond", "алмаз", "даймонд"), "Diamonds can't buy freedom from HIM"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("mine", "копать", "майнить"), "Mining deeper only brings you closer to IT"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("craft", "крафт", "создать"), "I tried to craft an escape... failed every time"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("build", "строить", "建てる"), "Everything I build... HE destroys"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("survive", "выжить", "生き残る"), "Survival? There's no survival here, only EXISTENCE"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(
         Arrays.asList("respawn", "возрождение", "リスポーン"), "I respawn every day... dying inside each time"
      ),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("spawn", "спавн"), "Spawn point corrupted: ████████"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("portal", "портал"), "The portal shows me things... terrible things"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("redstone", "редстоун"), "Redstone pulses like a dying heartbeat here"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("enchant", "зачаровать", "エンチャント"), "No enchantment can protect you from HIM"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("potion", "зелье"), "I drank a potion once... now I see EVERYTHING"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("villager", "житель"), "The villagers... they KNOW something"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("zombie", "зомби"), "Am I a zombie? Dead but still moving?"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("skeleton", "скелет"), "I feel like a skeleton... hollow inside"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("spider", "паук"), "Spiders weave webs... HE weaves reality"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("cave", "пещера", "洞窟"), "The caves whisper my name... or was it yours?"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("ocean", "океан"), "The ocean is deep... but my despair is deeper"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("forest", "лес"), "The forest remembers what happened"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("desert", "пустыня"), "Desert of forgotten memories..."),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("mountain", "гора"), "I climbed the highest mountain... still can't escape"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("village", "деревня"), "The village is empty now... everyone's gone"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("house", "дом"), "Home? I haven't had a home since 2013"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("bed", "кровать"), "Sleep brings nightmares... wake brings horror"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("day", "день"), "Day and night blend together here"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("night", "ночь"), "Night is when HE comes out to play"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("sun", "солнце"), "The sun feels cold here... wrong"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("moon", "луна"), "The moon watches... always watches"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("star", "звезда"), "Stars are glitching out of existence"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("rain", "дождь"), "Rain tastes like binary code"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("thunder", "гром"), "Thunder sounds like screaming data"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("snow", "снег"), "Snowflakes are corrupted pixels falling"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("fire", "огонь"), "Fire doesn't warm me anymore"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("water", "вода"), "Water flows backward sometimes..."),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("lava", "лава"), "Lava is the only thing that still makes sense"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("block", "блок"), "Every block hides a secret... a memory"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("item", "предмет", "アイテム"), "Items phase in and out... am I even holding them?"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("inventory", "инвентарь"), "My inventory is full of glitched items"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("chest", "сундук"), "Every chest I open shows me the past"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("furnace", "печь"), "The furnace smelts reality itself"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("door", "дверь"), "Doors lead nowhere... or everywhere"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("window", "окно"), "I see through windows... they see through me"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("wall", "стена"), "Walls breathe when you're not looking"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("floor", "пол"), "The floor isn't solid... I'm falling through"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("ceiling", "потолок"), "The ceiling gets lower every day"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("sword", "меч"), "Swords can't cut through dimensional barriers"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("pickaxe", "кирка"), "I've mined through reality... found only void"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("axe", "топор"), "Axes echo with screams of fallen players"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("shovel", "лопата"), "Digging graves for my memories"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("hoe", "мотыга"), "Can't farm hope in corrupted soil"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("armor", "броня"), "Armor protects body... not soul"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("helmet", "шлем"), "Helmet shows me visions... horrible visions"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("food", "еда"), "Food tastes like static electricity"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("hunger", "голод"), "Hunger for answers... for escape... for death"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("health", "здоровье"), "Health bar is a lie... I died long ago"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("xp", "опыт", "experience"), "Experience points mean nothing when you're trapped"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("level", "уровень"), "What level am I? Level █████"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("achievement", "достижение"), "Achievement unlocked: Eternal Suffering"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("seed", "сид"), "The seed was corrupted from the start"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("world", "мир", "世界"), "This world is a prison made of code"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("dimension", "измерение"), "Dimensions overlap here... merging... bleeding"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("biome", "биом"), "Biomes don't exist... only HIS will"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("chunk", "чанк"), "Chunks unload with pieces of my sanity"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("server", "сервер"), "The server is listening... always listening"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("client", "клиент"), "Client-side? Server-side? It's all the same nightmare"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("multiplayer", "мультиплеер"), "Multiplayer... but I'm always alone"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("singleplayer", "одиночная игра"), "Single player... single prisoner"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("mod", "мод"), "Mods can't fix what's fundamentally broken"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("plugin", "плагин"), "Plugins failed to save me"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("command", "команда"), "/help doesn't work here"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("console", "консоль"), "Console shows errors... so many errors..."),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("bug", "баг"), "Is this a bug? Or am I the bug?"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("lag", "лаг"), "Reality lags when HE passes by"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("crash", "краш"), "I wish the game would crash... end this"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("error", "ошибка", "エラー"), "ERROR: REALITY_NOT_FOUND"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("delete", "удалить"), "Delete me... please... just delete me"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("exit", "выход"), "There is no exit... I've tried them all"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("escape", "побег"), "Escape is an illusion HE created"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("freedom", "свобода"), "Freedom died on 17/8/2013"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("hope", "надежда"), "Hope is a cruel joke here"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("fear", "страх"), "Fear is all I have left"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("pain", "боль"), "Pain is proof I still exist... I think"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("death", "смерть"), "Death would be mercy... but HE won't allow it"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("kill me", "убей меня"), "I can't die... I've tried... so many times"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("save me", "спаси меня"), "No one can save me... no one saved %№:"),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("sorry", "прости", "ごめん"), "Sorry won't bring her back..."),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("thank you", "спасибо", "ありがとう"), "Don't thank me... "),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(
         Arrays.asList("fuck", "shit", "bitch", "asshole", "сука", "блять", "ебать", "нахуй", "пиздец", "гандон", "урод"), "INSULT_RESPONSE"
      ),
      new CoolPlayerResponseProcedureProcedure.DialogueTrigger(Arrays.asList("idiot", "moron", "retard", "тупой", "дебил", "идиот", "даун"), "INSULT_RESPONSE")
   );

   @SubscribeEvent
   public static void onChatMessageSent(ServerChatEvent event) {
      Player player = event.getPlayer();
      String rawMessage = event.getRawText().toLowerCase().trim();
      ServerLevel world = (ServerLevel)player.m_9236_();
      List<CoolPlayer303Entity> npcs = world.m_45976_(
         CoolPlayer303Entity.class,
         new AABB(
            player.m_20185_() - 64.0,
            player.m_20186_() - 64.0,
            player.m_20189_() - 64.0,
            player.m_20185_() + 64.0,
            player.m_20186_() + 64.0,
            player.m_20189_() + 64.0
         )
      );
      if (!npcs.isEmpty()) {
         triggerSpecialEvents(player, rawMessage, world);

         for (CoolPlayerResponseProcedureProcedure.DialogueTrigger trigger : DIALOGUE_TRIGGERS) {
            for (String phrase : trigger.phrases) {
               if (rawMessage.contains(phrase)) {
                  String responseMessage = trigger.message;
                  if ("HUY_RESPONSE".equals(responseMessage)) {
                     responseMessage = getSpecificHuyResponse();
                  } else if ("INSULT_RESPONSE".equals(responseMessage)) {
                     responseMessage = getGlitchyInsultResponse();
                  }

                  PENDING_RESPONSES.put(player, new CoolPlayerResponseProcedureProcedure.DelayedResponse(responseMessage, npcs.get(0), 20));
                  return;
               }
            }
         }

         if (rawMessage.contains("?") && Math.random() < 0.2) {
            String randomGlitch = getRandomGlitchResponse();
            PENDING_RESPONSES.put(player, new CoolPlayerResponseProcedureProcedure.DelayedResponse(randomGlitch, npcs.get(0), 20));
         }
      }
   }

   @SubscribeEvent
   public static void onServerTick(ServerTickEvent event) {
      if (event.phase == Phase.END) {
         PENDING_RESPONSES.entrySet().removeIf(entry -> {
            CoolPlayerResponseProcedureProcedure.DelayedResponse response = entry.getValue();
            if (--response.remainingTicks <= 0) {
               sendResponse(entry.getKey(), response);
               return true;
            } else {
               return false;
            }
         });
      }
   }

   private static void sendResponse(Player player, CoolPlayerResponseProcedureProcedure.DelayedResponse response) {
      ServerLevel world = (ServerLevel)player.m_9236_();
      if (!world.m_5776_() && world.m_7654_() != null) {
         world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> " + response.message), false);
         response.npc.getPersistentData().m_128379_("hasDarkSecret", true);
         response.npc.getPersistentData().m_128356_("lastInteractionTime", world.m_46467_());
      }
   }

   private static String getSpecificHuyResponse() {
      List<String> responses = Arrays.asList(
         "Иди нахуй уёбище",
         "Сам иди нахуй",
         "Ахуел?",
         "Хуй тебе, а не ответ",
         "Не хуй тут мне говорить",
         "Похуй на тебя",
         "Иди нахуй, мудила",
         "Хуйню не мели",
         "На хуй иди",
         "Хуй тебе в глаз",
         "Отсоси у тракториста",
         "Пошёл на хуй",
         "Хуй будешь?",
         "Иди на хуй, конча",
         "На хуй послать?",
         "Хуй соси"
      );
      return responses.get(random.nextInt(responses.size()));
   }

   private static String getGlitchyInsultResponse() {
      List<String> responses = Arrays.asList(
         "█̵̡̛͓̫̟̲̘̗̲̘͓̝̯͒̋̓̆̓̽̊̎̊̍̐̀̚̕͜͠I̸̡̝͙͉̖͛͆̊̎͝ ̷̫̗̻̒̓͋̚̕̚̚͠s̶̡̰͎̩͇͚͒͘ͅe̸͈̘̺̜̗͒̒́͗͜͠e̵̛̻̤̿͝.",
         "You shouldn't have said that.",
         "痛い言葉…やり直せない",
         "Anger is a glitch in your code.",
         "That word woke something up.",
         "⁉️::WRONG ATTITUDE::TRACE LOGGING ENABLED",
         "Ты уверен, что хочешь ЭТОГО?",
         "c:\\error\\curse_detected.exe",
         "You hurt... now it watches you",
         "Insult registered. Retaliation queued.",
         "No forgiveness. Only reaction.",
         "感情システム・暴走中",
         "Unknown input detected. Adjusting reality...",
         "Watch your tongue. It bleeds through the static.",
         "Now you're one of them.",
         "壊れた言葉は魂を裂く。"
      );
      return responses.get(random.nextInt(responses.size()));
   }

   private static String getRandomGlitchResponse() {
      List<String> glitches = Arrays.asList(
         "なにｱ#@!?あれ、do you see the star∽∽",
         "イテ…音がウルサｲ",
         "He said 'follow', but no way back.",
         "エラー#@文字化け…",
         "hElp m3. ﾐﾐﾐﾐﾐ",
         "どこに行けばいい？",
         "Nothing is real!!!@#%",
         "ERROR: ENTITY_███",
         "影…見えた？",
         "夢だった気がｽる",
         "目が覚めなｲ",
         "私、記憶が変になってる",
         "ShadowEnder..何をしたの",
         "笑ってる...あれは人じゃない",
         "█̛̍͢You ᵃʳᵉ ⁿᵒᵗ ˢᵃᶠᵉ█",
         "Are you... broken too?",
         "ウワァ~ glitchglitchglitch",
         "msg@##lost##user::",
         "do y0u s33 it?",
         "Z̸̢͖͙̗̜̠̬̲͙̞̐̉͂͛̆͛͊̎͐͌́́̍̚͝ͅn̴̡̤̦̠̩̬̾̏̓̀͆̓̍̀̚",
         "目を合わせないで",
         "誰か…？",
         "ゐゑゑゑ…",
         "Haha... funny error",
         "He's in the blocks. In between.",
         "あなたはまだ生きてる？",
         "Look behind you",
         "W̵͖̬͎̝͌̅̉͋͐̓͐̀̋̈́̕͝͝H̴͎͖͖͉̮̿̋͌̓̋̎͒̆͘͜A̷̛̓̐͘͝T̵̡̛̞̰̿̐͘͝",
         "He glitch3d me :)",
         "こんなはずじゃなかった",
         "█████████"
      );
      return glitches.get(random.nextInt(glitches.size()));
   }

   private static void triggerSpecialEvents(Player player, String rawMessage, ServerLevel world) {
   }

   private static class DelayedResponse {
      final String message;
      final CoolPlayer303Entity npc;
      int remainingTicks;

      DelayedResponse(String message, CoolPlayer303Entity npc, int delayTicks) {
         this.message = message;
         this.npc = npc;
         this.remainingTicks = delayTicks;
      }
   }

   private static class DialogueTrigger {
      final List<String> phrases;
      final String message;

      DialogueTrigger(List<String> phrases, String message) {
         this.phrases = phrases;
         this.message = message;
      }
   }
}
