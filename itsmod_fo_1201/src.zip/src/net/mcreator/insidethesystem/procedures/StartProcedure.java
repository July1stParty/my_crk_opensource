package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundGameEventPacket;
import net.minecraft.network.protocol.game.ClientboundLevelEventPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerAbilitiesPacket;
import net.minecraft.network.protocol.game.ClientboundUpdateMobEffectPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.registries.ForgeRegistries;

@EventBusSubscriber
public class StartProcedure {
   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player.m_20185_(), event.player.m_20186_(), event.player.m_20189_(), event.player);
      }
   }

   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      execute(null, world, x, y, z, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (InsideTheSystemModVariables.MapVariables.get(world).EndingF) {
            if (world instanceof Level _level) {
               if (!_level.m_5776_()) {
                  _level.m_5594_(
                     null,
                     BlockPos.m_274561_(x, y, z),
                     (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:brokenbox")),
                     SoundSource.NEUTRAL,
                     1.0F,
                     1.0F
                  );
               } else {
                  _level.m_7785_(
                     x,
                     y,
                     z,
                     (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:brokenbox")),
                     SoundSource.NEUTRAL,
                     1.0F,
                     1.0F,
                     false
                  );
               }
            }

            InsideTheSystemModVariables.MapVariables.get(world).EndingF = false;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            InsideTheSystemMod.queueServerWork(
               100,
               () -> {
                  if (!world.m_5776_() && world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> You.."), false);
                  }

                  InsideTheSystemMod.queueServerWork(
                     100,
                     () -> {
                        if (!world.m_5776_() && world.m_7654_() != null) {
                           world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> Are you serious???"), false);
                        }

                        InsideTheSystemMod.queueServerWork(
                           100,
                           () -> {
                              if (!world.m_5776_() && world.m_7654_() != null) {
                                 world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> And I waited for this???"), false);
                              }

                              InsideTheSystemMod.queueServerWork(
                                 100,
                                 () -> {
                                    if (!world.m_5776_() && world.m_7654_() != null) {
                                       world.m_7654_()
                                          .m_6846_()
                                          .m_240416_(
                                             Component.m_237113_(
                                                "<CoolPlayer303> How stupid I was.. hoping for you.. thought you would change.. become better after all that treatment"
                                             ),
                                             false
                                          );
                                    }

                                    InsideTheSystemMod.queueServerWork(
                                       100,
                                       () -> {
                                          if (!world.m_5776_() && world.m_7654_() != null) {
                                             world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> But no.. you’re just like him"), false);
                                          }

                                          InsideTheSystemMod.queueServerWork(
                                             100,
                                             () -> {
                                                if (!world.m_5776_() && world.m_7654_() != null) {
                                                   world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> D̷͘͟i͢͝͝r̛͜t͞͠y.."), false);
                                                }

                                                InsideTheSystemMod.queueServerWork(
                                                   80,
                                                   () -> {
                                                      if (!world.m_5776_() && world.m_7654_() != null) {
                                                         world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> U͟͡g͞͝l̵͘͠y.."), false);
                                                      }

                                                      InsideTheSystemMod.queueServerWork(
                                                         80,
                                                         () -> {
                                                            if (!world.m_5776_() && world.m_7654_() != null) {
                                                               world.m_7654_()
                                                                  .m_6846_()
                                                                  .m_240416_(Component.m_237113_("<CoolPlayer303> T͞͞r̴͢͠a͟͡i̵t͘͜͡o͡͞r.. ばかやろう!"), false);
                                                            }

                                                            InsideTheSystemMod.queueServerWork(
                                                               80,
                                                               () -> {
                                                                  if (!world.m_5776_() && world.m_7654_() != null) {
                                                                     world.m_7654_()
                                                                        .m_6846_()
                                                                        .m_240416_(
                                                                           Component.m_237113_("<CoolPlayer303> I d͢͝o͞͝n’͢t w̷̸a͢͜͡n͞t t͡͠o s͘͞e͟͡e y͘͝o͞u.."),
                                                                           false
                                                                        );
                                                                  }

                                                                  InsideTheSystemMod.queueServerWork(
                                                                     80,
                                                                     () -> {
                                                                        if (!world.m_5776_() && world.m_7654_() != null) {
                                                                           world.m_7654_()
                                                                              .m_6846_()
                                                                              .m_240416_(
                                                                                 Component.m_237113_(
                                                                                    "<CoolPlayer303> Yo͢u’͝r͞e th̛͜e͘͟ ẅ̵͜͝o͏͡r͘͝s͢͞t͜ a̶m̸o͢n͞g̷ p̵͞͞l͝͡ąy͢͡e͝r̴s.. クソッ!"
                                                                                 ),
                                                                                 false
                                                                              );
                                                                        }

                                                                        InsideTheSystemMod.queueServerWork(
                                                                           50,
                                                                           () -> {
                                                                              if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                 world.m_7654_()
                                                                                    .m_6846_()
                                                                                    .m_240416_(
                                                                                       Component.m_237113_("<CoolPlayer303> Ǥ͘͟͝͠Ę͜͟͠T̴͢ ͘͜O͘͡U̶͞T͏͡͞!͟!̷"),
                                                                                       false
                                                                                    );
                                                                              }

                                                                              InsideTheSystemModVariables.MapVariables.get(world).Scr1 = true;
                                                                              InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
                                                                              if (world instanceof Level _levelx) {
                                                                                 if (!_levelx.m_5776_()) {
                                                                                    _levelx.m_5594_(
                                                                                       null,
                                                                                       BlockPos.m_274561_(x, y, z),
                                                                                       (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                          .getValue(new ResourceLocation("inside_the_system:endingfscreamers")),
                                                                                       SoundSource.NEUTRAL,
                                                                                       1.0F,
                                                                                       1.0F
                                                                                    );
                                                                                 } else {
                                                                                    _levelx.m_7785_(
                                                                                       x,
                                                                                       y,
                                                                                       z,
                                                                                       (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                          .getValue(new ResourceLocation("inside_the_system:endingfscreamers")),
                                                                                       SoundSource.NEUTRAL,
                                                                                       1.0F,
                                                                                       1.0F,
                                                                                       false
                                                                                    );
                                                                                 }
                                                                              }

                                                                              InsideTheSystemMod.queueServerWork(
                                                                                 50,
                                                                                 () -> {
                                                                                    if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                       world.m_7654_()
                                                                                          .m_6846_()
                                                                                          .m_240416_(
                                                                                             Component.m_237113_(
                                                                                                "<CoolPlayer303> \ud835\udd72҉̶͝͠E̵͢͞͡͏Ť͘͟͞ ͢͡O͘͟͟͝U͠T̴͞!̶̢!͞ バケモノ!"
                                                                                             ),
                                                                                             false
                                                                                          );
                                                                                    }

                                                                                    InsideTheSystemModVariables.MapVariables.get(world).Scr2 = true;
                                                                                    InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
                                                                                    if (world instanceof Level _levelxx) {
                                                                                       if (!_levelxx.m_5776_()) {
                                                                                          _levelxx.m_5594_(
                                                                                             null,
                                                                                             BlockPos.m_274561_(x, y, z),
                                                                                             (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                                .getValue(
                                                                                                   new ResourceLocation("inside_the_system:endingfscreamers")
                                                                                                ),
                                                                                             SoundSource.NEUTRAL,
                                                                                             1.0F,
                                                                                             1.0F
                                                                                          );
                                                                                       } else {
                                                                                          _levelxx.m_7785_(
                                                                                             x,
                                                                                             y,
                                                                                             z,
                                                                                             (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                                .getValue(
                                                                                                   new ResourceLocation("inside_the_system:endingfscreamers")
                                                                                                ),
                                                                                             SoundSource.NEUTRAL,
                                                                                             1.0F,
                                                                                             1.0F,
                                                                                             false
                                                                                          );
                                                                                       }
                                                                                    }

                                                                                    InsideTheSystemMod.queueServerWork(
                                                                                       50,
                                                                                       () -> {
                                                                                          if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                             world.m_7654_()
                                                                                                .m_6846_()
                                                                                                .m_240416_(
                                                                                                   Component.m_237113_(
                                                                                                      "<CoolPlayer303> ᚵ͢͜͠E͘͟͞͠T̸͢͝ Ō͢͞͝U̶͘T͘͜!!"
                                                                                                   ),
                                                                                                   false
                                                                                                );
                                                                                          }

                                                                                          InsideTheSystemModVariables.MapVariables.get(world).Scr3 = true;
                                                                                          InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
                                                                                          if (world instanceof Level _levelxxx) {
                                                                                             if (!_levelxxx.m_5776_()) {
                                                                                                _levelxxx.m_5594_(
                                                                                                   null,
                                                                                                   BlockPos.m_274561_(x, y, z),
                                                                                                   (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                                      .getValue(
                                                                                                         new ResourceLocation(
                                                                                                            "inside_the_system:endingfscreamers"
                                                                                                         )
                                                                                                      ),
                                                                                                   SoundSource.NEUTRAL,
                                                                                                   1.0F,
                                                                                                   1.0F
                                                                                                );
                                                                                             } else {
                                                                                                _levelxxx.m_7785_(
                                                                                                   x,
                                                                                                   y,
                                                                                                   z,
                                                                                                   (SoundEvent)ForgeRegistries.SOUND_EVENTS
                                                                                                      .getValue(
                                                                                                         new ResourceLocation(
                                                                                                            "inside_the_system:endingfscreamers"
                                                                                                         )
                                                                                                      ),
                                                                                                   SoundSource.NEUTRAL,
                                                                                                   1.0F,
                                                                                                   1.0F,
                                                                                                   false
                                                                                                );
                                                                                             }
                                                                                          }

                                                                                          InsideTheSystemMod.queueServerWork(
                                                                                             50,
                                                                                             () -> {
                                                                                                if (!world.m_5776_() && world.m_7654_() != null) {
                                                                                                   world.m_7654_()
                                                                                                      .m_6846_()
                                                                                                      .m_240416_(
                                                                                                         Component.m_237113_(
                                                                                                            "<CoolPlayer303> \ud83d\udf5e҉̴͘G͟͠͝͡E͘͘T̛͢͝͞ ͜O͟͠U͠͞T̸!! 死ね!!!"
                                                                                                         ),
                                                                                                         false
                                                                                                      );
                                                                                                }

                                                                                                if (entity instanceof ServerPlayer _player
                                                                                                   && !_player.m_9236_().m_5776_()) {
                                                                                                   ResourceKey<Level> destinationType = ResourceKey.m_135785_(
                                                                                                      Registries.f_256858_,
                                                                                                      new ResourceLocation("inside_the_system:ending_tunnel")
                                                                                                   );
                                                                                                   if (_player.m_9236_().m_46472_() == destinationType) {
                                                                                                      return;
                                                                                                   }

                                                                                                   ServerLevel nextLevel = _player.f_8924_
                                                                                                      .m_129880_(destinationType);
                                                                                                   if (nextLevel != null) {
                                                                                                      _player.f_8906_
                                                                                                         .m_9829_(
                                                                                                            new ClientboundGameEventPacket(
                                                                                                               ClientboundGameEventPacket.f_132157_, 0.0F
                                                                                                            )
                                                                                                         );
                                                                                                      _player.m_8999_(
                                                                                                         nextLevel,
                                                                                                         _player.m_20185_(),
                                                                                                         _player.m_20186_(),
                                                                                                         _player.m_20189_(),
                                                                                                         _player.m_146908_(),
                                                                                                         _player.m_146909_()
                                                                                                      );
                                                                                                      _player.f_8906_
                                                                                                         .m_9829_(
                                                                                                            new ClientboundPlayerAbilitiesPacket(
                                                                                                               _player.m_150110_()
                                                                                                            )
                                                                                                         );

                                                                                                      for (MobEffectInstance _effectinstance : _player.m_21220_()) {
                                                                                                         _player.f_8906_
                                                                                                            .m_9829_(
                                                                                                               new ClientboundUpdateMobEffectPacket(
                                                                                                                  _player.m_19879_(), _effectinstance
                                                                                                               )
                                                                                                            );
                                                                                                      }

                                                                                                      _player.f_8906_
                                                                                                         .m_9829_(
                                                                                                            new ClientboundLevelEventPacket(
                                                                                                               1032, BlockPos.f_121853_, 0, false
                                                                                                            )
                                                                                                         );
                                                                                                   }
                                                                                                }

                                                                                                InsideTheSystemModVariables.MapVariables.get(world).site = true;
                                                                                                InsideTheSystemModVariables.MapVariables.get(world)
                                                                                                   .syncData(world);
                                                                                             }
                                                                                          );
                                                                                       }
                                                                                    );
                                                                                 }
                                                                              );
                                                                           }
                                                                        );
                                                                     }
                                                                  );
                                                               }
                                                            );
                                                         }
                                                      );
                                                   }
                                                );
                                             }
                                          );
                                       }
                                    );
                                 }
                              );
                           }
                        );
                     }
                  );
               }
            );
         }
      }
   }
}
