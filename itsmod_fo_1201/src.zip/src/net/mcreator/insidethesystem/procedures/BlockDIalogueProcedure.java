package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.registries.ForgeRegistries;

@EventBusSubscriber
public class BlockDIalogueProcedure {
   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player.m_20185_(), event.player.m_20186_(), event.player.m_20189_());
      }
   }

   public static void execute(LevelAccessor world, double x, double y, double z) {
      execute(null, world, x, y, z);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z) {
      if (InsideTheSystemModVariables.MapVariables.get(world).BlockDialogue) {
         InsideTheSystemModVariables.MapVariables.get(world).BlockDialogue = false;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         if (!world.m_5776_() && world.m_7654_() != null) {
            world.m_7654_().m_6846_().m_240416_(Component.m_237113_("You know..."), false);
         }

         InsideTheSystemMod.queueServerWork(
            80,
            () -> {
               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_().m_6846_().m_240416_(Component.m_237113_("I don't think it's fair..."), false);
               }

               InsideTheSystemMod.queueServerWork(
                  80,
                  () -> {
                     if (!world.m_5776_() && world.m_7654_() != null) {
                        world.m_7654_().m_6846_().m_240416_(Component.m_237113_("Why are you can using commands?"), false);
                     }

                     InsideTheSystemMod.queueServerWork(
                        80,
                        () -> {
                           if (!world.m_5776_() && world.m_7654_() != null) {
                              world.m_7654_().m_6846_().m_240416_(Component.m_237113_("Let's turn them off..."), false);
                           }

                           InsideTheSystemModVariables.MapVariables.get(world).BlockCommands = true;
                           InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
                           InsideTheSystemMod.queueServerWork(
                              80,
                              () -> {
                                 if (world instanceof Level _level) {
                                    if (!_level.m_5776_()) {
                                       _level.m_5594_(
                                          null,
                                          BlockPos.m_274561_(x, y, z),
                                          (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:smile")),
                                          SoundSource.NEUTRAL,
                                          1.0F,
                                          1.0F
                                       );
                                    } else {
                                       _level.m_7785_(
                                          x,
                                          y,
                                          z,
                                          (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:smile")),
                                          SoundSource.NEUTRAL,
                                          1.0F,
                                          1.0F,
                                          false
                                       );
                                    }
                                 }

                                 if (!world.m_5776_() && world.m_7654_() != null) {
                                    world.m_7654_().m_6846_().m_240416_(Component.m_237113_("§c:)"), false);
                                 }
                              }
                           );
                        }
                     );
                  }
               );
            }
         );
      }
   }
}
