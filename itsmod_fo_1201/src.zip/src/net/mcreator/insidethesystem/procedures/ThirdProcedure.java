package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.entity.AngryBuilderEntity;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.entity.living.LivingEvent.LivingTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class ThirdProcedure {
   private static boolean messageSent = false;

   @SubscribeEvent
   public static void onEntityTick(LivingTickEvent event) {
      execute(event, event.getEntity().m_9236_(), event.getEntity());
   }

   public static void execute(LevelAccessor world, Entity entity) {
      execute(null, world, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
      if (entity != null) {
         if (InsideTheSystemModVariables.MapVariables.get(world).Third) {
            if (!messageSent) {
               if (!world.m_5776_() && world instanceof Level level && level.m_7654_() != null) {
                  level.m_7654_().m_6846_().m_240416_(Component.m_237113_("You're alone in this world, isn't it lonely?"), false);
               }

               messageSent = true;
            }

            if (!(entity instanceof ServerPlayer) && !(entity instanceof AngryBuilderEntity) && !world.m_5776_()) {
               entity.m_146870_();
            }
         }
      }
   }
}
