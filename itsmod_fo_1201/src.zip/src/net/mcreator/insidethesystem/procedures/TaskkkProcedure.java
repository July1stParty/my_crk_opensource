package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class TaskkkProcedure {
   private static boolean isDialogueScheduled = false;
   private static final int INITIAL_DELAY = 1900;
   private static final int MESSAGE_INTERVAL = 70;

   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_());
      }
   }

   public static void execute(LevelAccessor world) {
      execute(null, world);
   }

   private static void execute(@Nullable Event event, LevelAccessor world) {
      InsideTheSystemModVariables.MapVariables mapVars = InsideTheSystemModVariables.MapVariables.get(world);
      if (mapVars.Taskkk && !isDialogueScheduled) {
         isDialogueScheduled = true;
         InsideTheSystemMod.queueServerWork(1900, () -> {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> You know... we spend so much time together..."), false);
            }
         });
         InsideTheSystemMod.queueServerWork(1970, () -> {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> And honestly, everything around me feels... almost unreal"), false);
            }
         });
         InsideTheSystemMod.queueServerWork(2040, () -> {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> I don’t know why..."), false);
            }
         });
         InsideTheSystemMod.queueServerWork(
            2110,
            () -> {
               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_()
                     .m_6846_()
                     .m_240416_(
                        Component.m_237113_("<CoolPlayer303> The weapon you have... it feels like it’s not meant for me. Like... it can’t really hurt me"),
                        false
                     );
               }
            }
         );
         InsideTheSystemMod.queueServerWork(
            2180,
            () -> {
               if (!world.m_5776_() && world.m_7654_() != null) {
                  world.m_7654_()
                     .m_6846_()
                     .m_240416_(Component.m_237113_("<CoolPlayer303> In my memories... there was a knife. Yes... a knife. It could draw blood..."), false);
               }
            }
         );
         InsideTheSystemMod.queueServerWork(2250, () -> {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> I want to know if I’m really real"), false);
            }
         });
         InsideTheSystemMod.queueServerWork(2320, () -> {
            if (!world.m_5776_() && world.m_7654_() != null) {
               world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<CoolPlayer303> Please... make a knife and test it..."), false);
            }

            isDialogueScheduled = false;
            InsideTheSystemModVariables.MapVariables finalMapVars = InsideTheSystemModVariables.MapVariables.get(world);
            finalMapVars.Taskkk = false;
            finalMapVars.syncData(world);
         });
      }
   }
}
