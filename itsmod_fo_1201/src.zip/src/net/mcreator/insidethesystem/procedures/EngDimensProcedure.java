package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;

public class EngDimensProcedure {
   public static void execute(LevelAccessor world) {
      if (world instanceof ServerLevel _level) {
         _level.m_7654_()
            .m_129892_()
            .m_230957_(
               new CommandSourceStack(
                     CommandSource.f_80164_,
                     new Vec3(
                        InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                        InsideTheSystemModVariables.MapVariables.get(world).PlayerY,
                        InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
                     ),
                     Vec2.f_82462_,
                     _level,
                     4,
                     "",
                     Component.m_237113_(""),
                     _level.m_7654_(),
                     null
                  )
                  .m_81324_(),
               "tp @a 0 2 0"
            );
      }

      world.m_7731_(new BlockPos(0, 0, 0), Blocks.f_152498_.m_49966_(), 3);
      if (world instanceof ServerLevel _level) {
         _level.m_7654_()
            .m_129892_()
            .m_230957_(
               new CommandSourceStack(
                     CommandSource.f_80164_,
                     new Vec3(
                        InsideTheSystemModVariables.MapVariables.get(world).PlayerX,
                        InsideTheSystemModVariables.MapVariables.get(world).PlayerY,
                        InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
                     ),
                     Vec2.f_82462_,
                     _level,
                     4,
                     "",
                     Component.m_237113_(""),
                     _level.m_7654_(),
                     null
                  )
                  .m_81324_(),
               "spawnpoint @a"
            );
      }

      InsideTheSystemModVariables.MapVariables.get(world).DialogueBool = true;
      InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
   }
}
