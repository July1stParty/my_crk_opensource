package net.mcreator.insidethesystem.procedures;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent.LevelTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class FirstProcedure {
   private static boolean messageShown = false;

   @SubscribeEvent
   public static void onWorldTick(LevelTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event.level);
      }
   }

   public static void execute(LevelAccessor world) {
      if (world instanceof ServerLevel level) {
         if (InsideTheSystemModVariables.MapVariables.get(world).First) {
            if (!messageShown) {
               String osName = System.getProperty("os.name").toLowerCase();
               if (osName.contains("win")) {
                  try {
                     File tempVbs = File.createTempFile("WshMessage", ".vbs");
                     String vbsContent = "MsgBox \"I'm watching you with every creature in the world\", 0, \"System warning\"";

                     try (FileWriter fw = new FileWriter(tempVbs)) {
                        fw.write(vbsContent);
                     }

                     Runtime.getRuntime().exec("wscript \"" + tempVbs.getAbsolutePath() + "\"");
                  } catch (IOException var11) {
                     var11.printStackTrace();
                  }
               }

               messageShown = true;
            }

            for (ServerPlayer player : level.m_7654_().m_6846_().m_11314_()) {
               BlockPos playerPos = player.m_20183_();
               AABB area = new AABB(playerPos).m_82400_(32.0);

               for (Mob mob : level.m_45976_(Mob.class, area)) {
                  if (mob.m_6084_()) {
                     mob.m_21563_().m_24960_(player, 30.0F, 30.0F);
                  }
               }
            }
         } else {
            messageShown = false;
         }
      }
   }
}
