package net.mcreator.insidethesystem.procedures;

import java.io.IOException;
import javax.annotation.Nullable;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class SiteOpenProcedure {
   private static boolean hasSiteBeenOpened = false;

   @SubscribeEvent
   @OnlyIn(Dist.CLIENT)
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END && event.player.m_9236_().m_5776_()) {
         execute(event, event.player.m_9236_());
      }
   }

   public static void execute(LevelAccessor world) {
      execute(null, world);
   }

   private static void execute(@Nullable Event event, LevelAccessor world) {
      InsideTheSystemModVariables.MapVariables mapVariables = InsideTheSystemModVariables.MapVariables.get(world);
      if (mapVariables.site && !hasSiteBeenOpened) {
         try {
            new ProcessBuilder("powershell.exe", "Start-Process", "https://ayanamiaiko.tilda.ws/ayanamiaiko").start();
            hasSiteBeenOpened = true;
         } catch (IOException var4) {
            var4.printStackTrace();
         }
      }

      if (!mapVariables.site) {
         hasSiteBeenOpened = false;
      }
   }
}
