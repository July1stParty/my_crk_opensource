package net.mcreator.insidethesystem.procedures;

import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.world.level.LevelAccessor;

public class LeftProcedure {
   public static void execute(LevelAccessor world) {
      InsideTheSystemModVariables.MapVariables.get(world).buildblock = true;
      InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      InsideTheSystemModVariables.MapVariables.get(world).EndingDtext = true;
      InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
   }
}
