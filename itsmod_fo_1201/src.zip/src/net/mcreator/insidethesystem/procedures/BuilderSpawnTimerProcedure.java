package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.TickEvent.LevelTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class BuilderSpawnTimerProcedure {
   @SubscribeEvent
   public static void onWorldTick(LevelTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.level);
      }
   }

   public static String execute(LevelAccessor world) {
      return execute(null, world);
   }

   private static String execute(@Nullable Event event, LevelAccessor world) {
      if (InsideTheSystemModVariables.MapVariables.get(world).builderSpawnTimer <= 32000.0 && InsideTheSystemModVariables.MapVariables.get(world).Angry) {
         InsideTheSystemModVariables.MapVariables.get(world).builderSpawnTimer--;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      if (InsideTheSystemModVariables.MapVariables.get(world).builderSpawnTimer == 0.0) {
         InsideTheSystemModVariables.MapVariables.get(world).summon = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         InsideTheSystemModVariables.MapVariables.get(world).builderSpawnTimer = 32000.0;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }

      return InsideTheSystemModVariables.MapVariables.get(world).builderSpawnTimer + "";
   }
}
