package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.InsideTheSystemMod;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.commands.arguments.EntityAnchorArgument.Anchor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class PlayerLookBuilderProcedure {
   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player);
      }
   }

   public static void execute(LevelAccessor world, Entity entity) {
      execute(null, world, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
      if (entity != null) {
         if (InsideTheSystemModVariables.MapVariables.get(world).builderLook) {
            entity.m_7618_(
               Anchor.EYES,
               new Vec3(
                  InsideTheSystemModVariables.MapVariables.get(world).builderX,
                  InsideTheSystemModVariables.MapVariables.get(world).builderY + 1.0,
                  InsideTheSystemModVariables.MapVariables.get(world).builderZ
               )
            );
            InsideTheSystemMod.queueServerWork(60, () -> {
               InsideTheSystemModVariables.MapVariables.get(world).builderLook = false;
               InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            });
         }
      }
   }
}
