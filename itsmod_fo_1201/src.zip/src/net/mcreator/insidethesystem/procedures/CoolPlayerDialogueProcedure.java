package net.mcreator.insidethesystem.procedures;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.mcreator.insidethesystem.entity.CoolPlayer303Entity;
import net.mcreator.insidethesystem.init.InsideTheSystemModGameRules;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.entity.living.LivingEvent.LivingTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class CoolPlayerDialogueProcedure {
   private static final List<String> happyMessages = List.of(
      "Hi!! Do you wanna build a neko cafe with me??",
      "Let's go find some flowers",
      "Oops, English hard... sowwy!!",
      "今日もたのしいですね！",
      "Yay! I found bunny!!!",
      "I love playing here. Do you?",
      "Hungry... do you have foodu?",
      "Do you like onigiri??",
      "Wanna help me make cake??",
      "This world is fun... I think so!",
      "あなたもここに来たの？",
      "We should build something cute!",
      "Uwaa~ creeper!こわい～",
      "I like you. You're nice ^_^",
      "お空きれい！ Sky is pretty!!",
      "Look! I made a cat!!",
      "ふわふわのベッド欲しいな～",
      "Haha you're funny!",
      "My English not bestu but I try!",
      "Yay together forever right?",
      "Don't leave me, okay?",
      "I draw you in my book!",
      "Friends play together every day!",
      "I want to see sakura again...",
      "I love when it's sunny!",
      "Ne ne do you have doggo?",
      "I want to name a sheep rainbow!",
      "Come come I show you something!",
      "Let's go explore!!",
      "Nee, do you have houseu?",
      "Maa maa I like this song!",
      "I'm not scared if you're with me!",
      "Let's play tag, ok?",
      "Waaa~ the stars so nice tonight!",
      "Do you think I sound weirdu?",
      "Maybe I build ice cream tower!",
      "Let's sleep near fire!",
      "I saw dream... it was beautiful",
      "I want to sing!! But I shy...",
      "I'll protect you! Like hero",
      "Snow reminds me of home",
      "Nee, what is your favorite color?",
      "I never had friend like you!",
      "Hehe, you're blushing!!",
      "You teach me English someday?",
      "わたし、がんばるね！",
      "I'll always remember today!",
      "Nyaa~ so sleepy...",
      "You my bestest!",
      "Someday, we build castle together!",
      "Don't go offline yet!"
   );
   private static final List<String> darkMessages = List.of(
      "This place... is strange now.",
      "Have you ever lost time?",
      "Why does it feel like a dream?",
      "I forget how long I've been here.",
      "I keep hearing voices. Not yours.",
      "Did we build this... or did someone else?",
      "Sometimes... I see shadows.",
      "The sky doesn't move anymore.",
      "What happens when we die here?",
      "I miss home... I think?",
      "Shibuya... feels like a memory now.",
      "Something is wrong with this game.",
      "Are we still friends?",
      "Why can't I leave?",
      "It's like I blink and a day passes.",
      "My hands... they glitch sometimes.",
      "You're still real, right?",
      "Where is ShadowEnderman_666 now?",
      "Do you remember the tunnel?",
      "I keep waking up here.",
      "This isn't play anymore.",
      "I'm scared.",
      "Can we build a way out?",
      "There's something behind you. Wait—",
      "Are you listening...?",
      "He said I was 'Date 17'.",
      "The knife was cold.",
      "The light in the tunnel... didn't return.",
      "My voice... it echoes wrong now.",
      "Sometimes I forget my name.",
      "I'm still here. I never left.",
      "Shadows don't cast in this world.",
      "Do you feel the lag too?",
      "Every mob I kill feels... familiar.",
      "My heart doesn't beat here.",
      "He laughed. Not through mic. Through code.",
      "I miss my mom.",
      "You're all I have left.",
      "This game is my cage.",
      "Do you remember how we met?",
      "I tried to scream.",
      "I saw my reflection. It wasn't me.",
      "He took my voice.",
      "The server never sleeps.",
      "You're blinking too fast.",
      "My inventory fills with echoes.",
      "Every block is heavy now.",
      "The End... it's not just a place.",
      "I want to wake up.",
      "Please... don't forget me."
   );

   @SubscribeEvent
   public static void onEntityTick(LivingTickEvent event) {
      if (!event.getEntity().m_9236_().m_5776_()) {
         execute(null, event.getEntity().m_9236_(), event.getEntity());
      }
   }

   public static void execute(LevelAccessor world, Entity entity) {
      execute(null, world, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
      if (entity != null && world instanceof Level) {
         if (entity instanceof CoolPlayer303Entity) {
            long currentTick = ((Level)world).m_46467_();
            long lastSpokenTick = entity.getPersistentData().m_128454_("coolPlayerLastSpoken");
            if (lastSpokenTick == 0L) {
               entity.getPersistentData().m_128356_("coolPlayerLastSpoken", currentTick);
               return;
            }

            boolean hasDarkSecret = entity.getPersistentData().m_128471_("hasDarkSecret");
            if (currentTick - lastSpokenTick >= 2500L) {
               Random random = new Random();
               String message;
               if (!hasDarkSecret) {
                  message = "<CoolPlayer303> " + happyMessages.get(random.nextInt(happyMessages.size()));
               } else {
                  int angryValue = world.m_6106_().m_5470_().m_46215_(InsideTheSystemModGameRules.PLAYER_ANGRY);
                  if (angryValue > 30 && random.nextFloat() > 0.3F) {
                     message = "<CoolPlayer303> " + happyMessages.get(random.nextInt(happyMessages.size()));
                  } else {
                     message = "<CoolPlayer303> " + darkMessages.get(random.nextInt(darkMessages.size()));
                  }
               }

               if (world.m_7654_() != null) {
                  world.m_7654_().m_6846_().m_240416_(Component.m_237113_(message), false);
                  entity.getPersistentData().m_128356_("coolPlayerLastSpoken", currentTick);
               }
            }
         }
      }
   }
}
