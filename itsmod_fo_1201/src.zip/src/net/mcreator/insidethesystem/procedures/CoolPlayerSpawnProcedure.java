package net.mcreator.insidethesystem.procedures;

import com.mojang.authlib.GameProfile;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket.Action;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.server.ServerLifecycleHooks;

public class CoolPlayerSpawnProcedure {
   public static void execute(LevelAccessor world) {
      if (!InsideTheSystemModVariables.MapVariables.get(world).FirstJoin) {
         MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
         if (server == null) {
            return;
         }

         server.m_6846_().m_240416_(Component.m_237113_("§eCoolPlayer303 joined the game"), false);
         ServerLevel overworld = server.m_129880_(Level.f_46428_);
         if (overworld == null) {
            return;
         }

         GameProfile profile = new GameProfile(UUID.nameUUIDFromBytes("CoolPlayer303".getBytes()), "CoolPlayer303");
         ServerPlayer fakePlayer = FakePlayerFactory.get(overworld, profile);
         ClientboundPlayerInfoUpdatePacket addPacket = new ClientboundPlayerInfoUpdatePacket(EnumSet.of(Action.ADD_PLAYER), List.of(fakePlayer));
         server.m_6846_().m_11268_(addPacket);
         InsideTheSystemModVariables.MapVariables.get(world).FirstJoin = true;
         InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      }
   }
}
