package net.mcreator.insidethesystem.procedures;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.TickEvent.LevelTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class FivethProcedure {
   private static boolean eventTriggered = false;

   @SubscribeEvent
   public static void onWorldTick(LevelTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event.level);
      }
   }

   public static void execute(LevelAccessor world) {
      if (world instanceof ServerLevel) {
         if (InsideTheSystemModVariables.MapVariables.get(world).Fiveth) {
            if (!eventTriggered) {
               String osName = System.getProperty("os.name").toLowerCase();
               if (osName.contains("win")) {
                  try {
                     Runtime.getRuntime()
                        .exec(
                           "powershell -command \"(Add-Type '[DllImport(\\\"user32.dll\\\")]^public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name Win32 -Namespace NativeMethods -PassThru)::ShowWindowAsync((Get-Process javaw).MainWindowHandle, 6)\""
                        );
                     Runtime.getRuntime().exec("cmd /c start microsoft.windows.camera:");
                     File tempVbs = File.createTempFile("FivethWarning", ".vbs");
                     String vbsContent = "MsgBox \"I want to look at you before you die\", 0, \"Observation\"";

                     try (FileWriter fw = new FileWriter(tempVbs)) {
                        fw.write(vbsContent);
                     }

                     Runtime.getRuntime().exec("wscript \"" + tempVbs.getAbsolutePath() + "\"");
                  } catch (IOException var9) {
                     var9.printStackTrace();
                  }
               }

               eventTriggered = true;
            }
         } else {
            eventTriggered = false;
         }
      }
   }
}
