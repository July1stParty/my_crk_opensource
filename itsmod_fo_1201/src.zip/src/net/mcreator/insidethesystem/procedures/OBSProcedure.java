package net.mcreator.insidethesystem.procedures;

import java.io.IOException;
import javax.annotation.Nullable;
import net.mcreator.insidethesystem.entity.Father2Entity;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class OBSProcedure {
   private static int tickCounter = 0;
   private static boolean isOBSRunning = false;
   private static boolean notificationShown = false;
   private static long notificationTime = 0L;
   private static boolean obsFound = false;
   private static boolean obsSequenceCompleted = false;
   private static boolean initialCheckDone = false;
   private static int coolPlayerTickCounter = 0;
   private static boolean coolPlayerMessagePhase = false;
   private static int messageIndex = 0;
   private static boolean nonOBSSequenceExecuted = false;
   private static int nonOBSTickCounter = 0;
   private static int nonOBSStage = 0;

   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player);
      }
   }

   public static void execute(LevelAccessor world, Player player) {
      execute(null, world, player);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, Player player) {
      if (!world.m_5776_()) {
         if (InsideTheSystemModVariables.MapVariables.get(world).OBS) {
            if (!initialCheckDone && !obsSequenceCompleted) {
               initialCheckDone = true;
               if (isOBSOpen()) {
                  obsFound = true;
                  isOBSRunning = true;
                  tickCounter = 0;
                  notificationShown = false;
               } else {
                  obsFound = false;
                  if (!nonOBSSequenceExecuted) {
                     executeNonOBSSequence(world, player);
                     nonOBSSequenceExecuted = true;
                     obsSequenceCompleted = true;
                  }
               }
            } else if (isOBSRunning && obsFound) {
               tickCounter++;
               if (tickCounter == 60) {
                  if (world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<§k:#№;%;?§r§c> Stop... I think someone is following us."), false);
                  }
               } else if (tickCounter == 120) {
                  if (world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<§k:#№;%;?§r§c> Are you recording me? That won't do :)"), false);
                  }
               } else if (tickCounter == 160) {
                  minimizeGame();
               } else if (tickCounter == 161) {
                  restoreOBS();
               } else if (tickCounter == 162 && !notificationShown) {
                  showErrorPopup();
                  notificationShown = true;
                  notificationTime = System.currentTimeMillis();
               } else if (notificationShown && System.currentTimeMillis() - notificationTime >= 10000L) {
                  closeOBS();
                  if (world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<§k:#№;%;?§r§c> That's better..."), false);
                  }

                  if (!nonOBSSequenceExecuted) {
                     executeNonOBSSequence(world, player);
                     nonOBSSequenceExecuted = true;
                  }

                  isOBSRunning = false;
                  tickCounter = 0;
                  notificationShown = false;
                  obsSequenceCompleted = true;
               }
            }
         }

         if (nonOBSStage > 0) {
            nonOBSTickCounter++;
            if (nonOBSStage == 1) {
               if (nonOBSTickCounter >= 40) {
                  if (world.m_7654_() != null) {
                     world.m_7654_().m_6846_().m_240416_(Component.m_237113_("<§k:#№;%;?§r§c> Good luck..."), false);
                  }

                  removeAllFather2Entities(world, player);
                  player.m_21219_();
                  nonOBSStage = 2;
                  nonOBSTickCounter = 0;
               }
            } else if (nonOBSStage == 2 && nonOBSTickCounter >= 10) {
               coolPlayerMessagePhase = true;
               coolPlayerTickCounter = 0;
               messageIndex = 0;
               nonOBSStage = 0;
               nonOBSTickCounter = 0;
            }
         }

         if (coolPlayerMessagePhase) {
            coolPlayerTickCounter++;
            if (coolPlayerTickCounter >= 70) {
               coolPlayerTickCounter = 0;
               sendCoolPlayerMessage(world, messageIndex);
               messageIndex++;
               if (messageIndex >= 4) {
                  coolPlayerMessagePhase = false;
                  messageIndex = 0;
                  InsideTheSystemModVariables.MapVariables.get(world).OBS = false;
                  InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
                  resetAllStates();
               }
            }
         }
      }
   }

   private static void executeNonOBSSequence(LevelAccessor world, Player player) {
      if (world.m_7654_() != null) {
         world.m_7654_()
            .m_6846_()
            .m_240416_(Component.m_237113_("<§k:#№;%;?§r§c> Although, you know... I think you'll find out for yourself in the end :)"), false);
         nonOBSStage = 1;
         nonOBSTickCounter = 0;
         nonOBSSequenceExecuted = true;
         obsSequenceCompleted = true;
      }
   }

   private static void removeAllFather2Entities(LevelAccessor world, Player player) {
      if (world instanceof Level _level) {
         AABB searchArea = new AABB(
            player.m_20185_() - 100.0,
            player.m_20186_() - 100.0,
            player.m_20189_() - 100.0,
            player.m_20185_() + 100.0,
            player.m_20186_() + 100.0,
            player.m_20189_() + 100.0
         );

         for (Father2Entity father : _level.m_45976_(Father2Entity.class, searchArea)) {
            father.m_146870_();
         }
      }
   }

   private static void sendCoolPlayerMessage(LevelAccessor world, int index) {
      if (world.m_7654_() != null) {
         String[] messages = new String[]{
            "<CoolPlayer303>§f What was that.. I feel like I fell asleep.. my head is splitting",
            "<CoolPlayer303>§f You don't remember anything?...",
            "<CoolPlayer303>§f Something strange happened here...",
            "<CoolPlayer303>§f I have a bad feeling about this..."
         };
         if (index < messages.length) {
            world.m_7654_().m_6846_().m_240416_(Component.m_237113_(messages[index]), false);
         }
      }
   }

   private static void resetAllStates() {
      tickCounter = 0;
      isOBSRunning = false;
      notificationShown = false;
      notificationTime = 0L;
      obsFound = false;
      obsSequenceCompleted = false;
      initialCheckDone = false;
      coolPlayerTickCounter = 0;
      coolPlayerMessagePhase = false;
      messageIndex = 0;
      nonOBSSequenceExecuted = false;
      nonOBSTickCounter = 0;
      nonOBSStage = 0;
   }

   private static boolean isOBSOpen() {
      try {
         Process process = Runtime.getRuntime().exec("powershell Get-Process obs64 -ErrorAction SilentlyContinue");
         return process.waitFor() == 0;
      } catch (InterruptedException | IOException var1) {
         var1.printStackTrace();
         return false;
      }
   }

   private static void minimizeGame() {
      try {
         Runtime.getRuntime().exec("powershell (New-Object -ComObject Shell.Application).MinimizeAll()");
      } catch (IOException var1) {
         var1.printStackTrace();
      }
   }

   private static void showErrorPopup() {
      try {
         Runtime.getRuntime()
            .exec(
               "powershell -command \"Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('SYSTEM CORRUPTED - OBS WILL CLOSE IN 10 SECONDS - FINISH RECORDING NOW!', 'FATAL ERROR', 0, 16)\""
            );
      } catch (IOException var1) {
         var1.printStackTrace();
      }
   }

   private static void restoreOBS() {
      try {
         Runtime.getRuntime()
            .exec(
               "powershell -command \"& {$process = Get-Process obs64 -ErrorAction SilentlyContinue;if ($process) {    $signature = '[DllImport(\\\"user32.dll\\\")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);';    $type = Add-Type -MemberDefinition $signature -Name WinAPI -Namespace User32 -PassThru;    $hwnd = $process.MainWindowHandle;    $type::ShowWindowAsync($hwnd, 9);    $type::ShowWindowAsync($hwnd, 5);}}\""
            );
      } catch (IOException var1) {
         var1.printStackTrace();
      }
   }

   private static void closeOBS() {
      try {
         Runtime.getRuntime().exec("powershell Stop-Process -Name obs64 -Force");
      } catch (IOException var1) {
         var1.printStackTrace();
      }
   }
}
