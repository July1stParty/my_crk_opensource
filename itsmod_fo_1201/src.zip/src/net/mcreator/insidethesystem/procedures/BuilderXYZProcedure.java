package net.mcreator.insidethesystem.procedures;

import javax.annotation.Nullable;
import net.mcreator.insidethesystem.entity.AngryBuilderEntity;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.entity.living.LivingEvent.LivingTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.registries.ForgeRegistries;

@EventBusSubscriber
public class BuilderXYZProcedure {
   @SubscribeEvent
   public static void onEntityTick(LivingTickEvent event) {
      if (!event.getEntity().m_9236_().m_5776_()) {
         execute(event, event.getEntity().m_9236_(), event.getEntity());
      }
   }

   public static void execute(LevelAccessor world, Entity entity) {
      execute(null, world, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
      if (entity != null) {
         if (entity instanceof AngryBuilderEntity) {
            InsideTheSystemModVariables.MapVariables mapVariables = InsideTheSystemModVariables.MapVariables.get(world);
            mapVariables.builderX = entity.m_20185_();
            mapVariables.builderY = entity.m_20186_();
            mapVariables.builderZ = entity.m_20189_();
            mapVariables.builderLook = false;
            mapVariables.syncData(world);
            if (world instanceof Level _level) {
               _level.m_5594_(
                  null,
                  new BlockPos((int)mapVariables.PlayerX, (int)mapVariables.PlayerY, (int)mapVariables.PlayerZ),
                  (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:builderspawn")),
                  SoundSource.NEUTRAL,
                  1.0F,
                  1.0F
               );
            }
         }

         BlockPos checkPos = new BlockPos(
            (int)InsideTheSystemModVariables.MapVariables.get(world).PlayerX + 3,
            (int)InsideTheSystemModVariables.MapVariables.get(world).PlayerY + 1,
            (int)InsideTheSystemModVariables.MapVariables.get(world).PlayerZ
         );
         boolean isBlockCurrentlyEmpty = world.m_8055_(checkPos).m_60800_(world, checkPos) > 0.1;
         InsideTheSystemModVariables.MapVariables mapVariables = InsideTheSystemModVariables.MapVariables.get(world);
         if (mapVariables.isBlockEmpty != isBlockCurrentlyEmpty) {
            mapVariables.isBlockEmpty = isBlockCurrentlyEmpty;
            mapVariables.syncData(world);
         }
      }
   }
}
