package net.mcreator.insidethesystem.procedures;

import io.netty.buffer.Unpooled;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.mcreator.insidethesystem.world.inventory.PasswordWriteMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.ServerTickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.registries.ForgeRegistries;

public class PasswordBlockPriShchielchkiePKMPoBlokuProcedure {
   public static void execute(final LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (InsideTheSystemModVariables.MapVariables.get(world).errors == 4.0) {
            InsideTheSystemModVariables.MapVariables.get(world).errors = 3.0;
            InsideTheSystemModVariables.MapVariables.get(world).screamer3 = true;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
            if (world instanceof Level _level) {
               if (!_level.m_5776_()) {
                  _level.m_5594_(
                     null,
                     new BlockPos((int)x, (int)y, (int)z),
                     (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:pswscreamer")),
                     SoundSource.NEUTRAL,
                     1.0F,
                     1.0F
                  );
               } else {
                  _level.m_7785_(
                     x,
                     y,
                     z,
                     (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("inside_the_system:pswscreamer")),
                     SoundSource.NEUTRAL,
                     1.0F,
                     1.0F,
                     false
                  );
               }
            }

            MinecraftForge.EVENT_BUS.register(new Object() {
               int ticks = 0;

               @SubscribeEvent
               public void onTick(ServerTickEvent event) {
                  if (event.phase == Phase.END) {
                     this.ticks++;
                     if (this.ticks >= 50) {
                        try {
                           Runtime.getRuntime().exec(new String[]{"cmd.exe", "/c", "start cmd /k dir /s"});
                        } catch (Exception var3) {
                           var3.printStackTrace();
                        }

                        if (FMLEnvironment.dist.isClient()) {
                           this.stopClient();
                        } else if (world instanceof Level lvl && !lvl.m_5776_()) {
                           lvl.m_7654_().m_7570_(false);
                        }

                        MinecraftForge.EVENT_BUS.unregister(this);
                     }
                  }
               }

               @OnlyIn(Dist.CLIENT)
               private void stopClient() {
                  Minecraft.m_91087_().m_91395_();
               }
            });
         } else if (entity instanceof ServerPlayer _ent) {
            final BlockPos _bpos = new BlockPos((int)x, (int)y, (int)z);
            NetworkHooks.openScreen(_ent, new MenuProvider() {
               public Component m_5446_() {
                  return Component.m_237113_("PasswordWrite");
               }

               public AbstractContainerMenu m_7208_(int id, Inventory inventory, Player player) {
                  return new PasswordWriteMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).m_130064_(_bpos));
               }
            }, _bpos);
         }
      }
   }
}
