package net.mcreator.insidethesystem.procedures;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.mcreator.insidethesystem.network.InsideTheSystemModVariables;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SignBlock;
import net.minecraft.world.level.block.StandingSignBlock;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class SteamProcedure {
   private static final String[] INITIAL_MESSAGES = new String[]{
      "Hello friend",
      "I am §k:#№;%;?§r",
      "Don't you want to play a game?",
      "Don't complete the tasks :)",
      "I know you love playing games",
      "Especially on Steam"
   };
   private static Map<Player, SteamProcedure.SteamEventData> activeEvents = new HashMap<>();

   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent event) {
      if (event.phase == Phase.END) {
         execute(event, event.player.m_9236_(), event.player);
      }
   }

   public static void execute(LevelAccessor world, Entity entity) {
      execute(null, world, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
      if (entity != null && entity instanceof Player player) {
         if (InsideTheSystemModVariables.MapVariables.get(world).Steam) {
            startSteamEvent(world, player);
            InsideTheSystemModVariables.MapVariables.get(world).Steam = false;
            InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
         }

         if (activeEvents.containsKey(player)) {
            processSteamEvent(world, player);
         }
      }
   }

   private static void startSteamEvent(LevelAccessor world, Player player) {
      if (player instanceof LivingEntity && !player.m_9236_().m_5776_()) {
         player.m_7292_(new MobEffectInstance(MobEffects.f_216964_, 1200, 3));
      }

      SteamProcedure.SteamEventData eventData = new SteamProcedure.SteamEventData();
      eventData.steamGames = getSteamGames();
      activeEvents.put(player, eventData);
   }

   private static void processSteamEvent(LevelAccessor world, Player player) {
      SteamProcedure.SteamEventData eventData = activeEvents.get(player);
      eventData.tickCounter++;
      switch (eventData.stage) {
         case 0:
            processInitialMessages(world, player, eventData);
            break;
         case 1:
            processChaosPhase(world, player, eventData);
            break;
         case 2:
            processWaitingPhase(world, player, eventData);
            break;
         case 3:
            processGoodLuckPhase(world, player, eventData);
            break;
         case 4:
            processFinalPhase(world, player, eventData);
            break;
         case 5:
            finishEvent(world, player);
      }
   }

   private static void processInitialMessages(LevelAccessor world, Player player, SteamProcedure.SteamEventData eventData) {
      if (eventData.tickCounter % 100 == 0) {
         if (eventData.messageIndex < INITIAL_MESSAGES.length) {
            spawnMessageSign(world, player, INITIAL_MESSAGES[eventData.messageIndex]);
            if (eventData.messageIndex == INITIAL_MESSAGES.length - 1 && world instanceof Level level) {
               level.m_5594_(null, player.m_20183_(), (SoundEvent)SoundEvents.f_11689_.get(), SoundSource.AMBIENT, 2.5F, 0.6F);
            }

            eventData.messageIndex++;
         } else {
            eventData.stage = 1;
            eventData.tickCounter = 0;
         }
      }
   }

   private static void processChaosPhase(LevelAccessor world, Player player, SteamProcedure.SteamEventData eventData) {
      if (!eventData.chaosStarted) {
         eventData.chaosStarted = true;
         if (!eventData.soundPlayed && world instanceof Level level) {
            level.m_5594_(null, player.m_20183_(), (SoundEvent)SoundEvents.f_11689_.get(), SoundSource.MASTER, 2.0F, 0.5F);
            eventData.soundPlayed = true;
         }
      }

      if (eventData.tickCounter % 10 == 0 && eventData.currentGameIndex < eventData.steamGames.size()) {
         int signsToSpawn = Math.min(1 + (int)(Math.random() * 2.0), eventData.steamGames.size() - eventData.currentGameIndex);

         for (int i = 0; i < signsToSpawn; i++) {
            if (eventData.currentGameIndex < eventData.steamGames.size()) {
               spawnSingleGameSign(world, player, eventData, eventData.steamGames.get(eventData.currentGameIndex));
               eventData.currentGameIndex++;
            }
         }

         if (world instanceof Level level && Math.random() < 0.3) {
            level.m_5594_(null, player.m_20183_(), SoundEvents.f_12598_, SoundSource.MASTER, 1.0F, 0.8F + (float)Math.random() * 0.4F);
         }
      }

      if (eventData.currentGameIndex >= eventData.steamGames.size()) {
         eventData.stage = 2;
         eventData.tickCounter = 0;
      }
   }

   private static void processWaitingPhase(LevelAccessor world, Player player, SteamProcedure.SteamEventData eventData) {
      if (eventData.tickCounter >= 200) {
         eventData.stage = 3;
         eventData.tickCounter = 0;
      }
   }

   private static void processGoodLuckPhase(LevelAccessor world, Player player, SteamProcedure.SteamEventData eventData) {
      if (!eventData.goodLuckSent) {
         eventData.goodLuckSent = true;
         eventData.tickCounter = 0;
      }

      if (eventData.tickCounter >= 150) {
         eventData.stage = 4;
         eventData.tickCounter = 0;
      }
   }

   private static void processFinalPhase(LevelAccessor world, Player player, SteamProcedure.SteamEventData eventData) {
      breakAllSigns(world, player, eventData);
      if (player instanceof LivingEntity) {
         player.m_21195_(MobEffects.f_216964_);
      }

      if (world instanceof Level level) {
         level.m_5594_(null, player.m_20183_(), SoundEvents.f_11880_, SoundSource.MASTER, 2.0F, 0.7F);
      }

      InsideTheSystemModVariables.MapVariables.get(world).Steam = false;
      InsideTheSystemModVariables.MapVariables.get(world).syncData(world);
      eventData.stage = 5;
   }

   private static void finishEvent(LevelAccessor world, Player player) {
      activeEvents.remove(player);
   }

   private static void spawnMessageSign(LevelAccessor world, Player player, String message) {
      if (world instanceof Level level) {
         BlockPos playerPos = player.m_20183_();
         float yaw = player.m_6080_();
         float pitch = player.m_146909_();
         double distance = 3.0;
         double x = -Math.sin(Math.toRadians(yaw)) * Math.cos(Math.toRadians(pitch)) * distance;
         double z = Math.cos(Math.toRadians(yaw)) * Math.cos(Math.toRadians(pitch)) * distance;
         double y = 1.0;
         BlockPos signPos = playerPos.m_7918_((int)x, (int)y, (int)z);
         if (!level.m_8055_(signPos).m_60795_()) {
            signPos = signPos.m_7918_(0, 1, 0);
         }

         if (!level.m_8055_(signPos).m_60795_()) {
            signPos = signPos.m_7918_(1, 0, 0);
         }

         if (level.m_8055_(signPos).m_60795_()) {
            BlockState signState = getSignStateForDirection(yaw);
            level.m_7731_(signPos, signState, 3);
            if (level.m_7702_(signPos) instanceof SignBlockEntity signEntity) {
               String[] lines = splitDialogMessage(message);
               SignText newSignText = new SignText();

               for (int i = 0; i < Math.min(lines.length, 4); i++) {
                  newSignText = newSignText.m_276913_(i, Component.m_237113_(lines[i]));
               }

               SignText finalSignText = newSignText;
               signEntity.m_277073_(signTextObj -> finalSignText, true);
               signEntity.m_6596_();
               level.m_7260_(signPos, level.m_8055_(signPos), level.m_8055_(signPos), 3);
            }

            if (activeEvents.containsKey(player)) {
               activeEvents.get(player).spawnedSigns.add(signPos);
            }
         }
      }
   }

   private static String[] splitDialogMessage(String message) {
      if (message.length() <= 12) {
         return new String[]{message, "", "", ""};
      } else {
         List<String> lines = new ArrayList<>();
         String[] words = message.split(" ");
         String currentLine = "";

         for (String word : words) {
            String testLine = currentLine + (currentLine.isEmpty() ? "" : " ") + word;
            if (testLine.length() <= 12) {
               currentLine = testLine;
            } else if (!currentLine.isEmpty()) {
               lines.add(currentLine);
               currentLine = word;
            } else if (word.length() > 12) {
               lines.add(word.substring(0, 12));
               if (lines.size() < 4) {
                  String remainder = word.substring(12);
                  if (remainder.length() <= 12) {
                     lines.add(remainder);
                  } else {
                     lines.add(remainder.substring(0, 12));
                  }
               }

               currentLine = "";
            } else {
               currentLine = word;
            }

            if (lines.size() >= 4) {
               break;
            }
         }

         if (!currentLine.isEmpty() && lines.size() < 4) {
            lines.add(currentLine);
         }

         while (lines.size() < 4) {
            lines.add("");
         }

         return lines.toArray(new String[4]);
      }
   }

   private static BlockState getSignStateForDirection(float yaw) {
      yaw = (yaw + 180.0F) % 360.0F;
      if (yaw < 0.0F) {
         yaw += 360.0F;
      }

      int rotation = Math.round(yaw / 22.5F) % 16;
      return (BlockState)Blocks.f_50095_.m_49966_().m_61124_(StandingSignBlock.f_56987_, rotation);
   }

   private static void spawnSingleGameSign(LevelAccessor world, Player player, SteamProcedure.SteamEventData eventData, String game) {
      if (world instanceof Level level) {
         BlockPos playerPos = player.m_20183_();
         float yaw = player.m_6080_();
         double baseDistance = 1.5 + Math.random() * 3.0;
         double randomAngle = (Math.random() - 0.5) * 100.0;
         double finalYaw = Math.toRadians(yaw + randomAngle);
         double x = -Math.sin(finalYaw) * baseDistance;
         double z = Math.cos(finalYaw) * baseDistance;
         double y = (Math.random() - 0.5) * 4.0;
         BlockPos signPos = playerPos.m_7918_((int)x, (int)y, (int)z);

         try {
            double angleToPlayer = Math.atan2(playerPos.m_123343_() - signPos.m_123343_(), playerPos.m_123341_() - signPos.m_123341_());
            float signYaw = (float)(Math.toDegrees(angleToPlayer) + 90.0);
            signYaw = (signYaw + 180.0F) % 360.0F;
            if (signYaw < 0.0F) {
               signYaw += 360.0F;
            }

            int rotation = Math.round(signYaw / 22.5F) % 16;
            BlockState signState = (BlockState)Blocks.f_50095_.m_49966_().m_61124_(StandingSignBlock.f_56987_, rotation);
            level.m_7731_(signPos, signState, 3);
            level.m_7260_(signPos, level.m_8055_(signPos), signState, 3);
            if (level.m_7702_(signPos) instanceof SignBlockEntity signEntity) {
               String[] lines = splitGameName(game);
               SignText newSignText = new SignText();

               for (int j = 0; j < Math.min(lines.length, 4); j++) {
                  newSignText = newSignText.m_276913_(j, Component.m_237113_(lines[j]));
               }

               SignText finalSignText = newSignText;
               signEntity.m_277073_(signTextObj -> finalSignText, true);
               signEntity.m_6596_();
               level.m_7260_(signPos, signState, signState, 3);
            }

            eventData.spawnedSigns.add(signPos);
            level.m_5594_(null, signPos, SoundEvents.f_12635_, SoundSource.BLOCKS, 0.5F, 1.5F + (float)Math.random() * 0.5F);
         } catch (Exception var29) {
            System.err.println("Error spawning sign for game " + game + ": " + var29.getMessage());
         }
      }
   }

   private static void breakAllSigns(LevelAccessor world, Player player, SteamProcedure.SteamEventData eventData) {
      if (world instanceof ServerLevel serverLevel) {
         BlockPos playerPos = player.m_20183_();
         if (world instanceof Level level) {
            level.m_5594_(null, playerPos, SoundEvents.f_12563_, SoundSource.MASTER, 1.5F, 0.8F);
         }

         try {
            LightningBolt lightning = (LightningBolt)EntityType.f_20465_.m_20615_(serverLevel);
            if (lightning != null) {
               lightning.m_6027_(playerPos.m_123341_(), playerPos.m_123342_(), playerPos.m_123343_());
               serverLevel.m_7967_(lightning);
               if (player instanceof ServerPlayer serverPlayer) {
                  Component message = Component.m_237113_("Good luck :)").m_6270_(Style.f_131099_.m_131140_(ChatFormatting.DARK_RED).m_131136_(true));
                  serverPlayer.m_213846_(message);
               }
            }
         } catch (Exception var9) {
            System.err.println("Failed to spawn lightning: " + var9.getMessage());
         }

         for (BlockPos signPos : eventData.spawnedSigns) {
            if (world instanceof Level level) {
               BlockState state = level.m_8055_(signPos);
               if (state.m_60734_() instanceof SignBlock) {
                  level.m_5594_(null, signPos, SoundEvents.f_12630_, SoundSource.BLOCKS, 0.8F, 1.0F + (float)Math.random() * 0.5F);
                  level.m_46961_(signPos, false);
               }
            }
         }

         eventData.spawnedSigns.clear();
      }
   }

   private static String[] splitGameName(String gameName) {
      if (gameName.length() <= 12) {
         return new String[]{gameName, "", "", ""};
      } else {
         List<String> lines = new ArrayList<>();
         String[] words = gameName.split(" ");
         String currentLine = "";

         for (String word : words) {
            if ((currentLine + (currentLine.isEmpty() ? "" : " ") + word).length() <= 12) {
               currentLine = currentLine + (currentLine.isEmpty() ? "" : " ") + word;
            } else if (!currentLine.isEmpty()) {
               lines.add(currentLine);
               currentLine = word;
            } else if (word.length() > 12) {
               lines.add(word.substring(0, 12));
               currentLine = "";
            } else {
               currentLine = word;
            }

            if (lines.size() >= 3) {
               if (!currentLine.isEmpty()) {
                  lines.add(currentLine);
               }
               break;
            }
         }

         if (!currentLine.isEmpty() && lines.size() < 4) {
            lines.add(currentLine);
         }

         while (lines.size() < 4) {
            lines.add("");
         }

         return lines.toArray(new String[4]);
      }
   }

   private static List<String> getSteamGames() {
      List<String> games = new ArrayList<>();

      try {
         File steamDir = findSteamDirectory();
         if (steamDir != null) {
            File[] gameDirectories = steamDir.listFiles(File::isDirectory);
            if (gameDirectories != null) {
               for (File gameDir : gameDirectories) {
                  String gameName = gameDir.getName();
                  gameName = gameName.trim();
                  if (!gameName.isEmpty()) {
                     games.add(gameName);
                  }

                  if (games.size() >= 100) {
                     break;
                  }
               }
            }
         }
      } catch (Exception var8) {
         System.err.println("Steam directory search error: " + var8.getMessage());
      }

      if (games.isEmpty()) {
         games.addAll(
            Arrays.asList(
               "Counter-Strike 2",
               "Dota 2",
               "Among Us",
               "Fall Guys",
               "Team Fortress 2",
               "Left 4 Dead 2",
               "Portal 2",
               "Half-Life 2",
               "Garry's Mod",
               "Rust",
               "PUBG",
               "Apex Legends",
               "Dead by Daylight",
               "Terraria",
               "Stardew Valley",
               "The Witcher 3",
               "Cyberpunk 2077",
               "Grand Theft Auto V",
               "Red Dead Redemption 2",
               "Minecraft"
            )
         );
      }

      return games;
   }

   private static File findSteamDirectory() {
      String[] standardPaths = new String[]{
         "C:\\Program Files (x86)\\Steam\\steamapps\\common",
         "C:\\Program Files\\Steam\\steamapps\\common",
         System.getProperty("user.home") + "\\.steam\\steam\\steamapps\\common",
         System.getProperty("user.home") + "\\Library\\Application Support\\Steam\\steamapps\\common",
         "/usr/share/steam/steamapps/common",
         "/opt/steam/steamapps/common"
      };

      for (String path : standardPaths) {
         File dir = new File(path);
         if (dir.exists() && dir.isDirectory()) {
            return dir;
         }
      }

      File steamFromRegistry = findSteamFromRegistry();
      if (steamFromRegistry != null) {
         return steamFromRegistry;
      } else {
         File steamFromEnv = findSteamFromEnvironment();
         if (steamFromEnv != null) {
            return steamFromEnv;
         } else {
            File steamFromDiskSearch = searchAllDisks();
            return steamFromDiskSearch != null ? steamFromDiskSearch : null;
         }
      }
   }

   private static File findSteamFromRegistry() {
      try {
         Process process = Runtime.getRuntime().exec("reg query \"HKEY_LOCAL_MACHINE\\SOFTWARE\\WOW6432Node\\Valve\\Steam\" /v InstallPath");
         BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

         String line;
         while ((line = reader.readLine()) != null) {
            if (line.contains("InstallPath")) {
               String[] parts = line.split("REG_SZ");
               if (parts.length > 1) {
                  String steamPath = parts[1].trim() + "\\steamapps\\common";
                  File steamDir = new File(steamPath);
                  if (steamDir.exists() && steamDir.isDirectory()) {
                     return steamDir;
                  }
               }
            }
         }

         process.waitFor();
         reader.close();
      } catch (Exception var6) {
      }

      return null;
   }

   private static File findSteamFromEnvironment() {
      String[] envVars = new String[]{"STEAM_ROOT", "STEAMROOT", "STEAM_PATH"};

      for (String envVar : envVars) {
         String steamPath = System.getenv(envVar);
         if (steamPath != null) {
            File steamDir = new File(steamPath + "\\steamapps\\common");
            if (steamDir.exists() && steamDir.isDirectory()) {
               return steamDir;
            }

            steamDir = new File(steamPath + "/steamapps/common");
            if (steamDir.exists() && steamDir.isDirectory()) {
               return steamDir;
            }
         }
      }

      return null;
   }

   private static File searchAllDisks() {
      try {
         File[] roots = File.listRoots();

         for (File root : roots) {
            if (root.canRead() && root.getTotalSpace() > 0L) {
               File steamDir = searchForSteamInDirectory(root, 0, 3);
               if (steamDir != null) {
                  return steamDir;
               }
            }
         }
      } catch (Exception var6) {
         System.err.println("Disk search error: " + var6.getMessage());
      }

      return null;
   }

   private static File searchForSteamInDirectory(File directory, int currentDepth, int maxDepth) {
      if (currentDepth <= maxDepth && directory != null && directory.exists() && directory.canRead()) {
         try {
            File steamAppsCommon = new File(directory, "steamapps/common");
            if (!steamAppsCommon.exists()) {
               steamAppsCommon = new File(directory, "steamapps\\common");
            }

            if (steamAppsCommon.exists() && steamAppsCommon.isDirectory()) {
               File[] gameDirectories = steamAppsCommon.listFiles(File::isDirectory);
               if (gameDirectories != null && gameDirectories.length > 0) {
                  return steamAppsCommon;
               }
            }

            String[] steamFolderNames = new String[]{"Steam", "steam", "SteamLibrary", "steamlibrary"};

            for (String steamFolderName : steamFolderNames) {
               File steamFolder = new File(directory, steamFolderName);
               if (steamFolder.exists() && steamFolder.isDirectory()) {
                  File result = searchForSteamInDirectory(steamFolder, currentDepth + 1, maxDepth);
                  if (result != null) {
                     return result;
                  }
               }
            }

            if (currentDepth == 0) {
               File[] subdirs = directory.listFiles(
                  file -> file.isDirectory()
                     && !file.getName().startsWith(".")
                     && !file.getName().equals("System32")
                     && !file.getName().equals("Windows")
                     && !file.getName().equals("ProgramData")
               );
               if (subdirs != null) {
                  for (File subdir : subdirs) {
                     File result = searchForSteamInDirectory(subdir, currentDepth + 1, maxDepth);
                     if (result != null) {
                        return result;
                     }
                  }
               }
            }
         } catch (SecurityException var11) {
         }

         return null;
      } else {
         return null;
      }
   }

   private static class SteamEventData {
      int stage = 0;
      int messageIndex = 0;
      int tickCounter = 0;
      List<BlockPos> spawnedSigns = new ArrayList<>();
      List<String> steamGames = new ArrayList<>();
      boolean chaosStarted = false;
      int chaosTickCounter = 0;
      int currentGameIndex = 0;
      boolean soundPlayed = false;
      boolean goodLuckSent = false;
   }
}
