package net.mcreator.insidethesystem.procedures;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@EventBusSubscriber
public class SkinFolderProcedure {
   private static boolean initialized = false;
   private static final String[] SKIN_FILES = new String[]{
      "default.png",
      "vivilly.png",
      "angry.png",
      "bratishkinoff.png",
      "notvixios.png",
      "aiko.png",
      "lost.png",
      "venom.png",
      "mrhals.png",
      "hangg.png",
      "hurmabom2.png",
      "mrha0s.png",
      "d3nter.png",
      "andeku.png",
      "danilapodpivas.png",
      "mslan.png"
   };

   @SubscribeEvent
   public static void onPlayerLoggedIn(PlayerLoggedInEvent event) {
      if (event.getEntity() instanceof ServerPlayer) {
         ServerPlayer player = (ServerPlayer)event.getEntity();
         execute(player);
      }
   }

   private static void execute(ServerPlayer player) {
      if (!initialized) {
         initialized = true;
         MinecraftServer server = player.m_20194_();
         if (server != null) {
            Path skinsDir = Paths.get("saves").resolve("InsideTheSystemSkins");

            try {
               if (!Files.exists(skinsDir)) {
                  Files.createDirectories(skinsDir);
               }

               copySkinsFromResources(skinsDir);
            } catch (IOException var4) {
               var4.printStackTrace();
            }
         }
      }
   }

   private static void copySkinsFromResources(Path targetDir) throws IOException {
      for (String skinFile : SKIN_FILES) {
         try (InputStream in = SkinFolderProcedure.class.getClassLoader().getResourceAsStream("assets/inside_the_system/textures/entities/" + skinFile)) {
            if (in != null) {
               Path targetFile = targetDir.resolve(skinFile);
               if (!Files.exists(targetFile)) {
                  try (OutputStream out = Files.newOutputStream(targetFile, StandardOpenOption.CREATE)) {
                     byte[] buffer = new byte[8192];

                     int bytesRead;
                     while ((bytesRead = in.read(buffer)) != -1) {
                        out.write(buffer, 0, bytesRead);
                     }
                  }
               }
            }
         } catch (IOException var14) {
            var14.printStackTrace();
         }
      }
   }
}
